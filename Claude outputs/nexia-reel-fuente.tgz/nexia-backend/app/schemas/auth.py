import re

from pydantic import AliasChoices, BaseModel, ConfigDict, EmailStr, Field, field_validator

from app.core.clock import is_valid_timezone
from app.models.business import Business
from app.models.user import User, UserRole


class RegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    full_name: str = Field(
        min_length=1,
        max_length=255,
        validation_alias=AliasChoices("fullName", "full_name"),
    )
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    business_name: str = Field(
        min_length=1,
        max_length=255,
        validation_alias=AliasChoices("businessName", "business_name"),
    )
    phone: str = Field(min_length=1, max_length=32)
    business_kind: str | None = Field(
        default=None,
        max_length=40,
        validation_alias=AliasChoices("businessKind", "business_kind"),
    )
    address: str | None = Field(default=None, max_length=255)
    instagram: str | None = Field(default=None, max_length=255)
    accept_terms: bool = Field(validation_alias=AliasChoices("acceptTerms", "accept_terms"))
    # Si le paga comisión a su equipo: enciende o esconde las comisiones en el panel.
    uses_commissions: bool = Field(default=True, validation_alias=AliasChoices("usesCommissions", "uses_commissions"))
    # La del navegador de la dueña; si no se reconoce, se usa la de la Ciudad de México.
    timezone: str | None = Field(default=None, max_length=64)

    @field_validator("timezone")
    @classmethod
    def _known_timezone(cls, value: str | None) -> str | None:
        return value if value and is_valid_timezone(value) else None

    @field_validator("accept_terms")
    @classmethod
    def _must_accept(cls, value: bool) -> bool:
        if not value:
            raise ValueError("Debes aceptar los términos y el aviso de privacidad")
        return value

    @field_validator("full_name", "business_name")
    @classmethod
    def _not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("No puede ir vacío")
        return value.strip()

    @field_validator("phone")
    @classmethod
    def _ten_digits(cls, value: str) -> str:
        digits = re.sub(r"\D", "", value)
        if len(digits) != 10:
            raise ValueError("El teléfono debe tener 10 dígitos")
        return digits

    @field_validator("instagram")
    @classmethod
    def _instagram_handle(cls, value: str | None) -> str | None:
        """Acepta @usuario, usuario o la URL completa; guarda solo el usuario."""
        if value is None:
            return None
        handle = re.sub(r"^(https?://)?(www\.)?instagram\.com/", "", value.strip(), flags=re.IGNORECASE)
        handle = handle.split("?")[0].strip("/").lstrip("@")
        return handle or None

    @field_validator("address", "business_kind")
    @classmethod
    def _blank_is_none(cls, value: str | None) -> str | None:
        return value.strip() or None if value is not None else None


class ClientRegisterRequest(BaseModel):
    full_name: str = Field(min_length=1, max_length=255)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    slug: str = Field(min_length=1, max_length=255)


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str = Field(min_length=10, max_length=2000)
    password: str = Field(min_length=8, max_length=72)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)


class UserResponse(BaseModel):
    """Session profile. CamelCase fields match the Angular client; snake_case matches the tenant contract."""

    id: int
    email: str
    fullName: str
    role: UserRole
    tenantId: str
    businessName: str | None = None
    business_id: int | None = None
    business_name: str | None = None
    slug: str | None = None


def to_user_response(user: User, business: Business | None) -> UserResponse:
    if user.id is None:
        raise RuntimeError("User id is missing")

    business_name = business.name if business is not None else None
    return UserResponse(
        id=user.id,
        email=user.email,
        fullName=user.full_name,
        role=user.role,
        tenantId=str(user.business_id) if user.business_id is not None else "",
        businessName=business_name,
        business_id=user.business_id,
        business_name=business_name,
        slug=business.slug if business is not None else None,
    )
