from datetime import datetime, time

import json
import re

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.core.alerts import ALERT_KINDS
from app.core.images import IMAGE_TYPES_HINT, is_safe_data_image, is_valid_logo
from app.core.messages import MAX_TEMPLATE_LENGTH, MESSAGE_KEYS
from app.core.clock import DEFAULT_TIMEZONE, is_valid_timezone
from app.core.payment_methods import PAYMENT_METHODS, parse_methods
from app.core.shop_note import MAX_CLOSURES, parse_closures
from app.core.map_link import embed_src


class Closure(BaseModel):
    """Un cierre: un solo día (festivo) o un periodo (vacaciones), ambas fechas incluidas."""

    model_config = ConfigDict(populate_by_name=True)

    start: str = Field(alias="from", pattern=r"^\d{4}-\d{2}-\d{2}$")
    end: str = Field(alias="to", pattern=r"^\d{4}-\d{2}-\d{2}$")
    label: str = Field(default="", max_length=60)

    @model_validator(mode="after")
    def _in_order(self) -> "Closure":
        if self.end < self.start:
            raise ValueError("La fecha final del cierre no puede ser antes que la inicial")
        return self




class BusinessBrandResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    name: str
    logo_url: str | None = None
    primary_color: str
    canvas_color: str | None = None
    phone: str
    email: str | None = None
    slug: str | None = None
    description: str | None = None
    address: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    map_embed: str | None = None
    instagram: str | None = None
    facebook: str | None = None
    website: str | None = None
    deposit_amount: float | None = None
    deposit_percent: int | None = None
    deposit_account: str | None = None
    deposit_hold_hours: int | None = None
    cancel_hours: int | None = None
    loyalty_every: int | None = None
    loyalty_percent: int | None = None
    staff_label: str = "Colaborador"
    min_notice_hours: int = 0
    max_days_ahead: int = 90
    cancel_policy: str | None = None
    resources: str | None = None
    payment_url: str | None = None
    google_review_url: str | None = None
    accent_color: str | None = None
    button_shape: str | None = "pill"
    button_fill: str | None = "solid"
    font_style: str | None = "modern"
    header_style: str | None = "cover"
    bookings_paused: bool = False
    closures: list[dict] = Field(default_factory=list)
    payment_methods: list[str] = Field(default_factory=lambda: list(PAYMENT_METHODS))
    approve_bookings: bool = False
    uses_commissions: bool = True
    spei_check: bool = False
    promo_text: str | None = None
    promo_until: str | None = None
    gallery: list[str] = Field(default_factory=list)
    # Solo en /businesses/me: la página pública lo excluye.
    message_templates: dict[str, str] = Field(default_factory=dict)

    @field_validator("gallery", mode="before")
    @classmethod
    def _gallery_list(cls, value: object) -> list[str]:
        return gallery_list(value)

    @field_validator("closures", mode="before")
    @classmethod
    def _closure_list(cls, value: object) -> list[dict]:
        return parse_closures(value)

    @field_validator("payment_methods", mode="before")
    @classmethod
    def _method_list(cls, value: object) -> list[str]:
        return parse_methods(value)

    @field_validator("approve_bookings", mode="before")
    @classmethod
    def _approve_flag(cls, value: object) -> bool:
        return bool(value)

    @field_validator("message_templates", mode="before")
    @classmethod
    def _templates_dict(cls, value: object) -> dict[str, str]:
        return templates_dict(value)
    # Horario general (de lo que trabaja el equipo), para mostrarlo en la página.
    hours: list[str] = []



def templates_dict(value: object) -> dict[str, str]:
    if isinstance(value, dict):
        return {key: text for key, text in value.items() if key in MESSAGE_KEYS and isinstance(text, str)}
    try:
        parsed = json.loads(value) if isinstance(value, str) and value else {}
    except ValueError:
        return {}
    return templates_dict(parsed) if isinstance(parsed, dict) else {}


def gallery_list(value: object) -> list[str]:
    """La columna guarda JSON; la API siempre responde una lista."""
    if isinstance(value, list):
        return [item for item in value if isinstance(item, str)]
    try:
        parsed = json.loads(value) if isinstance(value, str) and value else []
    except ValueError:
        return []
    return [item for item in parsed if isinstance(item, str)] if isinstance(parsed, list) else []


def _checked_logo(value: str | None) -> str | None:
    if value is None or not value.strip():
        return value
    if not is_valid_logo(value):
        raise ValueError(f"El logo debe ser una imagen {IMAGE_TYPES_HINT}")
    return value


class BusinessProfileUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    phone: str | None = Field(default=None, max_length=32)
    logo_url: str | None = Field(default=None, max_length=180000)
    description: str | None = Field(default=None, max_length=500)
    address: str | None = Field(default=None, max_length=255)
    instagram: str | None = Field(default=None, max_length=255)
    facebook: str | None = Field(default=None, max_length=255)
    website: str | None = Field(default=None, max_length=255)
    primary_color: str | None = Field(default=None, pattern=r"^#(?:[0-9a-fA-F]{6})$")
    canvas_color: str | None = Field(default=None, pattern=r"^#(?:[0-9a-fA-F]{6})$")

    @field_validator("logo_url")
    @classmethod
    def _safe_logo(cls, value: str | None) -> str | None:
        return _checked_logo(value)


class BusinessSettingsUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    # Datos del negocio y apariencia: se guardan junto con lo demás, en una sola petición.
    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=500)
    business_kind: str | None = Field(default=None, max_length=40)
    logo_url: str | None = Field(default=None, max_length=180000)
    primary_color: str | None = Field(default=None, pattern=r"^#(?:[0-9a-fA-F]{6})$")
    canvas_color: str | None = Field(default=None, pattern=r"^#(?:[0-9a-fA-F]{6})$")
    address: str | None = Field(default=None, max_length=255)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    map_embed: str | None = Field(default=None, max_length=1500)
    phone: str | None = Field(default=None, max_length=32)
    instagram: str | None = Field(default=None, max_length=255)
    facebook: str | None = Field(default=None, max_length=255)
    cancel_hours: int | None = Field(default=None, ge=0, le=168)
    deposit_amount: float | None = Field(default=None, ge=0)
    deposit_percent: int | None = Field(default=None, ge=1, le=100)
    deposit_account: str | None = Field(default=None, max_length=120)
    deposit_hold_hours: int | None = Field(default=None, ge=1, le=72)
    buffer_minutes: int | None = Field(default=None, ge=0, le=120)
    staff_label: str | None = Field(default=None, max_length=40)
    min_notice_hours: int | None = Field(default=None, ge=0, le=168)
    max_days_ahead: int | None = Field(default=None, ge=1, le=365)
    cancel_policy: str | None = Field(default=None, max_length=500)
    # Además de los recursos lleva las fotos, la promoción y el cierre (JSON); las fotos pesan.
    resources: str | None = Field(default=None, max_length=1_000_000)
    payment_url: str | None = Field(default=None, max_length=255)
    google_review_url: str | None = Field(default=None, max_length=500, pattern=r"^(https://.+)?$")
    accent_color: str | None = Field(default=None, pattern=r"^(#[0-9a-fA-F]{6})?$")
    button_shape: str | None = Field(default=None, pattern=r"^(pill|rounded|square)$")
    button_fill: str | None = Field(default=None, pattern=r"^(solid|outline)$")
    font_style: str | None = Field(default=None, pattern=r"^(modern|elegant|warm)$")
    header_style: str | None = Field(default=None, pattern=r"^(cover|color|plain)$")
    privacy_notice: str | None = Field(default=None, max_length=10000)
    loyalty_every: int | None = Field(default=None, ge=2, le=50)
    loyalty_percent: int | None = Field(default=None, ge=1, le=100)
    coupons: str | None = Field(default=None, max_length=5000)
    timezone: str | None = Field(default=None, max_length=64)
    email_alerts: list[str] | None = None
    bookings_paused: bool | None = None
    closures: list[Closure] | None = Field(default=None, max_length=MAX_CLOSURES)
    payment_methods: list[str] | None = None
    approve_bookings: bool | None = None
    uses_commissions: bool | None = None
    auto_reminders: bool | None = None
    reminder_hours: int | None = Field(default=None, ge=2, le=72)
    auto_return: bool | None = None
    promo_text: str | None = Field(default=None, max_length=80)
    promo_until: str | None = Field(default=None, pattern=r"^(\d{4}-\d{2}-\d{2})?$")
    gallery: list[str] | None = Field(default=None, max_length=3)
    message_templates: dict[str, str] | None = None

    @field_validator("logo_url")
    @classmethod
    def _safe_logo(cls, value: str | None) -> str | None:
        return _checked_logo(value)

    @field_validator("message_templates")
    @classmethod
    def _known_templates(cls, value: dict[str, str] | None) -> dict[str, str] | None:
        if value is None:
            return None
        if any(key not in MESSAGE_KEYS for key in value):
            raise ValueError("Mensaje desconocido")
        if any(len(text) > MAX_TEMPLATE_LENGTH for text in value.values()):
            raise ValueError(f"Cada mensaje puede tener hasta {MAX_TEMPLATE_LENGTH} caracteres")
        return {key: text.strip() for key, text in value.items() if text.strip()}

    @field_validator("gallery")
    @classmethod
    def _small_images(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return None
        if any(not is_safe_data_image(item) for item in value) or sum(len(item) for item in value) > 180_000:
            raise ValueError(f"Las fotos deben ser {IMAGE_TYPES_HINT} y pesar poco (hasta 3)")
        return value

    @field_validator("payment_methods")
    @classmethod
    def _known_methods(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return None
        if not value or any(item not in PAYMENT_METHODS for item in value):
            raise ValueError("Elige al menos un método de pago: efectivo, transferencia o tarjeta")
        return value

    @field_validator("email_alerts")
    @classmethod
    def _known_alerts(cls, value: list[str] | None) -> list[str] | None:
        if value is not None and any(kind not in ALERT_KINDS for kind in value):
            raise ValueError("Tipo de aviso desconocido")
        return value

    @field_validator("phone")
    @classmethod
    def _ten_digits(cls, value: str | None) -> str | None:
        if not value or not value.strip():
            return value
        digits = re.sub(r"\D", "", value)
        if len(digits) != 10:
            raise ValueError("El teléfono debe tener 10 dígitos")
        return digits

    @field_validator("payment_url")
    @classmethod
    def _https_link(cls, value: str | None) -> str | None:
        if value and value.strip() and not value.strip().startswith(("https://", "http://")):
            raise ValueError("El enlace de pago debe empezar con https://")
        return value

    @field_validator("timezone")
    @classmethod
    def _known_timezone(cls, value: str | None) -> str | None:
        if value is not None and not is_valid_timezone(value):
            raise ValueError("Zona horaria desconocida")
        return value

    @field_validator("map_embed")
    @classmethod
    def _google_embed(cls, value: str | None) -> str | None:
        if not value or not value.strip():
            return None
        src = embed_src(value)
        if src is None:
            raise ValueError("Pega el código de \"Insertar un mapa\" de Google Maps")
        return src

    @model_validator(mode="after")
    def _both_coordinates(self) -> "BusinessSettingsUpdate":
        sent = {"latitude", "longitude"} & self.model_fields_set
        if sent and (len(sent) == 1 or (self.latitude is None) != (self.longitude is None)):
            raise ValueError("La ubicación necesita latitud y longitud juntas")
        return self


class BusinessHourUpdate(BaseModel):
    day_of_week: int = Field(ge=0, le=6)
    open_time: time
    close_time: time
    is_closed: bool = False

    @field_validator("open_time", "close_time", mode="before")
    @classmethod
    def parse_clock(cls, value: object) -> object:
        if isinstance(value, str):
            try:
                return datetime.strptime(value, "%H:%M").time()
            except ValueError as error:
                raise ValueError("Usa el formato HH:MM") from error
        return value

    @model_validator(mode="after")
    def close_after_open(self) -> "BusinessHourUpdate":
        if not self.is_closed and self.close_time <= self.open_time:
            raise ValueError("La hora de cierre debe ser posterior a la de apertura")
        return self


class BusinessHourRead(BaseModel):
    id: int
    day_of_week: int
    open_time: time
    close_time: time
    is_closed: bool


class BusinessSettingsRead(BaseModel):
    id: int
    name: str
    slug: str
    description: str | None = None
    business_kind: str | None = None
    primary_color: str | None = None
    canvas_color: str | None = None
    logo_url: str | None = None
    phone: str
    email: str
    address: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    map_embed: str | None = None
    instagram: str | None = None
    facebook: str | None = None
    cancel_hours: int | None = None
    deposit_amount: float | None = None
    deposit_percent: int | None = None
    deposit_account: str | None = None
    deposit_hold_hours: int | None = None
    buffer_minutes: int = 0
    staff_label: str = "Colaborador"
    min_notice_hours: int = 0
    max_days_ahead: int = 90
    cancel_policy: str | None = None
    resources: str | None = None
    payment_url: str | None = None
    google_review_url: str | None = None
    accent_color: str | None = None
    button_shape: str | None = "pill"
    button_fill: str | None = "solid"
    font_style: str | None = "modern"
    header_style: str | None = "cover"
    privacy_notice: str | None = None
    loyalty_every: int | None = None
    loyalty_percent: int | None = None
    coupons: str | None = None
    timezone: str = DEFAULT_TIMEZONE
    email_alerts: list[str] = Field(default_factory=list)
    bookings_paused: bool = False
    closures: list[dict] = Field(default_factory=list)
    payment_methods: list[str] = Field(default_factory=lambda: list(PAYMENT_METHODS))
    approve_bookings: bool = False
    uses_commissions: bool = True
    auto_reminders: bool = False
    reminder_hours: int = 24
    auto_return: bool = False
    # Si el servidor tiene la API de WhatsApp conectada (sin ella, lo automático no sale).
    whatsapp_ready: bool = False
    spei_check: bool = False
    promo_text: str | None = None
    promo_until: str | None = None
    gallery: list[str] = Field(default_factory=list)
    message_templates: dict[str, str] = Field(default_factory=dict)
    hours: list[BusinessHourRead] = Field(default_factory=list)
