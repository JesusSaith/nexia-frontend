from pydantic import BaseModel, Field

from app.schemas.appointment import AppointmentRead as AppointmentResponse


class TopServiceItem(BaseModel):
    service_name: str
    total_appointments: int
    total_revenue: float


class StaffOccupancyItem(BaseModel):
    staff_name: str
    total_appointments: int


class WeekTrendPoint(BaseModel):
    date: str
    count: int
    revenue: float


class DashboardSummary(BaseModel):
    today_appointments_count: int = 0
    today_revenue: float = 0
    week_appointments_count: int = 0
    upcoming_today: list[AppointmentResponse] = Field(default_factory=list)
    week_trend: list[WeekTrendPoint] = Field(default_factory=list)
    month_trend: list[WeekTrendPoint] = Field(default_factory=list)


class DashboardStatsResponse(BaseModel):
    total_today: int = 0
    total_month: int = 0
    revenue_today: float = 0
    revenue_month: float = 0
    top_services: list[TopServiceItem] = Field(default_factory=list)
    staff_occupancy: list[StaffOccupancyItem] = Field(default_factory=list)
