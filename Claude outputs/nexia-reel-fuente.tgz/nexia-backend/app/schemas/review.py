from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from app.core.images import IMAGE_TYPES_HINT, is_safe_data_image


class ReviewCreate(BaseModel):
    client_name: str = Field(min_length=1, max_length=255)
    rating: int = Field(ge=1, le=5)
    comment: str = Field(min_length=1, max_length=1000)
    photo_url: str | None = None
    # Enlace de su cita (el mismo de /manage/<token>): solo quien tuvo una cita puede opinar, una vez por cita.
    token: str = Field(min_length=10, max_length=36)

    @field_validator("client_name", "comment")
    @classmethod
    def strip_text(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Este campo es obligatorio")
        return cleaned

    @field_validator("photo_url")
    @classmethod
    def photo(cls, value: str | None) -> str | None:
        if value is None or value.strip() == "":
            return None
        if not is_safe_data_image(value) or len(value) > 180000:
            raise ValueError(f"La foto debe ser {IMAGE_TYPES_HINT} y pesar poco")
        return value


class ReviewRead(BaseModel):
    id: int
    client_name: str
    rating: int
    comment: str
    photo_url: str | None
    reply: str | None = None
    created_at: datetime
