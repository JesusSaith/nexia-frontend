from pydantic import BaseModel


class BusinessStatusUpdate(BaseModel):
    is_active: bool


class PlatformBusiness(BaseModel):
    id: int
    name: str
    slug: str
    staff_count: int
    appointment_count: int
    is_active: bool
