from datetime import date, datetime, time

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.core.images import IMAGE_TYPES_HINT, is_safe_data_image
from app.models.appointment import AppointmentStatus


def _blank_to_none(value: object) -> object:
    if isinstance(value, str) and not value.strip():
        return None
    return value


class AppointmentCreate(BaseModel):
    service_id: int
    # Opción del servicio (variante) por su nombre; cambia precio y duración.
    variant: str | None = Field(default=None, max_length=60)
    staff_id: int
    starts_at: datetime
    client_name: str = Field(min_length=1, max_length=255)
    client_phone: str = Field(min_length=1, max_length=32)
    client_email: EmailStr | None = None
    notes: str | None = Field(default=None, max_length=2000)
    extra_service_ids: list[int] = Field(default_factory=list)
    resource_name: str | None = Field(default=None, max_length=80)
    answers: str | None = Field(default=None, max_length=2000)
    use_package: bool = False
    reference_photos: list[str] = Field(default_factory=list, max_length=3)
    # Campo trampa: la página lo deja vacío y oculto; los bots que llenan todo lo delatan.
    website: str | None = None
    coupon: str | None = Field(default=None, max_length=40)

    @field_validator("client_email", "notes", mode="before")
    @classmethod
    def empty_optional(cls, value: object) -> object:
        return _blank_to_none(value)

    @field_validator("reference_photos")
    @classmethod
    def only_small_images(cls, value: list[str]) -> list[str]:
        for photo in value:
            if not is_safe_data_image(photo) or len(photo) > 180000:
                raise ValueError(f"Cada foto debe ser {IMAGE_TYPES_HINT} de menos de 180 KB")
        return value


class AdminAppointmentCreate(AppointmentCreate):
    quoted_price: float | None = Field(default=None, ge=0)
    waive_deposit: bool = False


class AppointmentStatusUpdate(BaseModel):
    status: AppointmentStatus
    # Al completar: lo que realmente se cobró (total, incluye anticipo) y cómo.
    final_price: float | None = Field(default=None, ge=0)
    payment_method: str | None = Field(default=None, pattern=r"^(efectivo|transferencia|tarjeta|paquete)$")
    tip: float | None = Field(default=None, ge=0)
    visit_note: str | None = Field(default=None, max_length=2000)


class AppointmentReschedule(BaseModel):
    new_date: date
    new_time: time
    staff_id: int | None = None


class PublicAppointmentRead(BaseModel):
    client_name: str = ""
    business_name: str
    business_slug: str
    logo_url: str | None = None
    primary_color: str | None = None
    service_id: int
    service_name: str
    staff_id: int
    staff_name: str
    starts_at: str
    ends_at: str | None = None
    status: AppointmentStatus
    is_past: bool
    is_cancelled: bool
    changes_locked: bool = False
    deposit_amount: float | None = None
    deposit_account: str | None = None
    payment_proof: str | None = None
    client_confirmed: bool = False
    quoted_price: float | None = None
    variable_price: bool = False
    price_accepted: bool = False
    cancel_policy: str | None = None
    payment_url: str | None = None
    # Para invitar a reseñar en Google a quien califica con 4 o 5 estrellas.
    google_review_url: str | None = None
    # Para "Cómo llegar" en la página de la cita.
    address: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    map_embed: str | None = None
    needs_approval: bool = False
    # Se puede confirmar el anticipo con la clave de rastreo (Banxico) en vez de la captura.
    spei_check: bool = False
    paid_claim: bool = False


class AvailabilitySlot(BaseModel):
    starts_at: str
    staff_id: int | None = None


class AppointmentRead(BaseModel):
    id: int
    client_name: str
    client_phone: str | None
    client_email: str | None
    service_id: int
    service_name: str
    staff_id: int
    staff_name: str
    starts_at: str
    status: AppointmentStatus
    notes: str | None = None
    cancel_token: str | None = None
    deposit_amount: float | None = None
    payment_proof: str | None = None
    quoted_price: float | None = None
    client_confirmed: bool = False
    price_accepted: bool = False
    created_at: str | None = None
    resource_name: str | None = None
    extra_label: str | None = None
    answers: str | None = None
    photo_count: int = 0
    payment_method: str | None = None
    tip: float | None = None
    visit_note: str | None = None
    discount_percent: int | None = None
    needs_approval: bool = False
    paid_claim: bool = False
