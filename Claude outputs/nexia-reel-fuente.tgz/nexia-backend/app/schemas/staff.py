from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


def _blank_to_none(value: object) -> object:
    if isinstance(value, str) and not value.strip():
        return None
    return value


class StaffCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    full_name: str = Field(min_length=1, max_length=255)
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=32)
    role_title: str = Field(min_length=1, max_length=255)
    is_active: bool = True

    @field_validator("email", "phone", mode="before")
    @classmethod
    def empty_optional(cls, value: object) -> object:
        return _blank_to_none(value)


class StaffUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=32)
    role_title: str | None = Field(default=None, min_length=1, max_length=255)
    is_active: bool | None = None
    commission_percent: int | None = Field(default=None, ge=0, le=100)
    goal: float | None = Field(default=None, ge=0)
    color: str | None = Field(default=None, pattern=r"^(#[0-9a-fA-F]{6})?$")
    tier_amount: float | None = Field(default=None, ge=0)
    tier_percent: int | None = Field(default=None, ge=0, le=100)
    avatar_url: str | None = Field(default=None, max_length=180000)
    bio: str | None = Field(default=None, max_length=2000)

    @field_validator("email", "phone", "avatar_url", "bio", mode="before")
    @classmethod
    def empty_optional(cls, value: object) -> object:
        return _blank_to_none(value)


class StaffAccountCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)


class StaffServicesUpdate(BaseModel):
    service_ids: list[int]


class StaffProfileUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    phone: str | None = Field(default=None, max_length=32)
    avatar_url: str | None = Field(default=None, max_length=180000)
    bio: str | None = Field(default=None, max_length=2000)

    @field_validator("phone", "avatar_url", "bio", mode="before")
    @classmethod
    def empty_optional(cls, value: object) -> object:
        return _blank_to_none(value)


class StaffResponse(BaseModel):
    id: int
    business_id: int
    full_name: str
    email: str | None
    phone: str | None
    role_title: str
    is_active: bool
    user_id: int | None = None
    avatar_url: str | None = None
    bio: str | None = None
    slot_times: str | None = None
    commission_percent: int = 0
    goal: float | None = None
    color: str | None = None
    tier_amount: float | None = None
    tier_percent: int | None = None
    service_ids: list[int] = Field(default_factory=list)


StaffRead = StaffResponse


class StaffPublic(BaseModel):
    id: int
    full_name: str
    role_title: str
    avatar_url: str | None = None
    bio: str | None = None
    service_ids: list[int] = Field(default_factory=list)
