from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def _parse_clock(value: str) -> datetime:
    try:
        return datetime.strptime(value, "%H:%M")
    except ValueError as error:
        raise ValueError("Usa el formato HH:MM") from error


class ScheduleItem(BaseModel):
    day_of_week: int = Field(ge=0, le=6)
    start_time: str
    end_time: str
    is_active: bool = True
    slot_times: str | None = None
    break_start: str | None = None
    break_end: str | None = None

    @field_validator("start_time", "end_time")
    @classmethod
    def clock(cls, value: str) -> str:
        _parse_clock(value)
        return value

    @field_validator("break_start", "break_end", "slot_times", mode="before")
    @classmethod
    def blank(cls, value: str | None) -> str | None:
        if value is None or not str(value).strip():
            return None
        return str(value).strip()

    @field_validator("break_start", "break_end")
    @classmethod
    def break_clock(cls, value: str | None) -> str | None:
        if value is None:
            return None
        _parse_clock(value[:5])
        return value[:5]

    @model_validator(mode="after")
    def end_after_start(self) -> "ScheduleItem":
        if _parse_clock(self.end_time) <= _parse_clock(self.start_time):
            raise ValueError("La hora de fin debe ser posterior a la de inicio")
        if (self.break_start is None) != (self.break_end is None):
            raise ValueError("El descanso necesita hora de inicio y de fin")
        if self.break_start and self.break_end and _parse_clock(self.break_end) <= _parse_clock(self.break_start):
            raise ValueError("El descanso debe terminar después de empezar")
        return self


class StaffScheduleUpdate(BaseModel):
    schedules: list[ScheduleItem]
    slot_times: str | None = None

    @model_validator(mode="after")
    def one_window_per_day(self) -> "StaffScheduleUpdate":
        days = [item.day_of_week for item in self.schedules]
        if len(days) != len(set(days)):
            raise ValueError("Cada día de la semana solo puede aparecer una vez")
        return self


class ScheduleResponse(ScheduleItem):
    model_config = ConfigDict(from_attributes=True)

    id: int
    staff_id: int
