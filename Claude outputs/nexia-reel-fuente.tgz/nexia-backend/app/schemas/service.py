import json

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.core.images import IMAGE_TYPES_HINT, is_safe_data_image


class Variant(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    price: float = Field(ge=0)
    duration_minutes: int = Field(gt=0, le=1440)


def parse_variants(value: object) -> object:
    """En la base es texto JSON; en la API, una lista."""
    if isinstance(value, str):
        try:
            return json.loads(value) or []
        except ValueError:
            return []
    return value or []


class CategoryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str


class CategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ServiceCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str = Field(min_length=1, max_length=255)
    category: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=2000)
    price: float = Field(ge=0)
    deposit_amount: float | None = Field(default=None, ge=0)
    duration_minutes: int = Field(gt=0, le=1440)
    is_active: bool = True
    variable_price: bool = False
    image_url: str | None = None
    questions: str | None = Field(default=None, max_length=1000)
    capacity: int = Field(default=1, ge=1, le=100)
    return_days: int | None = Field(default=None, ge=7, le=365)
    supply_cost: float | None = Field(default=None, ge=0)
    sort_order: int | None = Field(default=None, ge=0)
    featured: bool | None = None
    cleanup_minutes: int | None = Field(default=None, ge=0, le=240)
    wait_start: int | None = Field(default=None, ge=0, le=1440)
    wait_minutes: int | None = Field(default=None, ge=0, le=600)
    variants: list[Variant] | None = Field(default=None, max_length=12)

    @field_validator("image_url")
    @classmethod
    def image(cls, value: str | None) -> str | None:
        if value is None or value.strip() == "":
            return None
        if not is_safe_data_image(value) or len(value) > 180000:
            raise ValueError(f"La foto debe ser {IMAGE_TYPES_HINT} y pesar poco")
        return value


class ServiceUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str | None = Field(default=None, min_length=1, max_length=255)
    category: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=2000)
    price: float | None = Field(default=None, ge=0)
    deposit_amount: float | None = Field(default=None, ge=0)
    duration_minutes: int | None = Field(default=None, gt=0, le=1440)
    is_active: bool | None = None
    variable_price: bool | None = None
    image_url: str | None = None
    questions: str | None = Field(default=None, max_length=1000)
    capacity: int | None = Field(default=None, ge=1, le=100)
    return_days: int | None = Field(default=None, ge=7, le=365)
    supply_cost: float | None = Field(default=None, ge=0)
    sort_order: int | None = Field(default=None, ge=0)
    featured: bool | None = None
    cleanup_minutes: int | None = Field(default=None, ge=0, le=240)
    wait_start: int | None = Field(default=None, ge=0, le=1440)
    wait_minutes: int | None = Field(default=None, ge=0, le=600)
    variants: list[Variant] | None = Field(default=None, max_length=12)

    @field_validator("image_url")
    @classmethod
    def image(cls, value: str | None) -> str | None:
        if value is None or value.strip() == "":
            return None
        if not is_safe_data_image(value) or len(value) > 180000:
            raise ValueError(f"La foto debe ser {IMAGE_TYPES_HINT} y pesar poco")
        return value


class ServiceRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    business_id: int
    name: str
    category: str | None = None
    description: str | None
    price: float
    deposit_amount: float | None = None
    duration_minutes: int
    is_active: bool
    variable_price: bool = False
    image_url: str | None = None
    questions: str | None = None
    capacity: int = 1
    return_days: int | None = None
    supply_cost: float | None = None
    sort_order: int = 0
    featured: bool = False
    cleanup_minutes: int = 0
    wait_start: int | None = None
    wait_minutes: int = 0
    variants: list[Variant] = []

    _variants = field_validator("variants", mode="before")(classmethod(lambda cls, value: parse_variants(value)))


class ServicePublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: str | None = None
    description: str | None
    price: float
    deposit_amount: float | None = None
    duration_minutes: int
    variable_price: bool = False
    image_url: str | None = None
    questions: str | None = None
    capacity: int = 1
    featured: bool = False
    variants: list[Variant] = []

    _variants = field_validator("variants", mode="before")(classmethod(lambda cls, value: parse_variants(value)))
