from sqlalchemy import inspect
from sqlmodel import SQLModel

from app.db.database import engine


def init_db() -> None:
    """Register every model and create missing tables. Safe on SQLite and PostgreSQL."""
    from app.models.appointment import Appointment
    from app.models.client import Client, ClientContact  # noqa: F401
    from app.models.review import Review  # noqa: F401
    from app.models.business import Business  # noqa: F401
    from app.models.schedule import Schedule  # noqa: F401
    from app.models.service import Service  # noqa: F401
    from app.models.service_category import ServiceCategory  # noqa: F401
    from app.models.staff import Staff  # noqa: F401
    from app.models.staff_service import StaffService  # noqa: F401
    from app.models.notice import Notice  # noqa: F401
    from app.models.package import ClientPackage  # noqa: F401
    from app.models.product import CommissionPay, Expense, ExpensePayment, Product, Sale, StockMove  # noqa: F401
    from app.models.cash import CashCount, CashMove  # noqa: F401
    from app.models.standing_block import StandingBlock  # noqa: F401
    from app.models.time_block import TimeBlock  # noqa: F401
    from app.models.waitlist import Waitlist  # noqa: F401
    from app.models.special_hours import SpecialHours  # noqa: F401
    from app.models.user import User  # noqa: F401

    SQLModel.metadata.create_all(engine)
    # Columnas nuevas primero: los pasos de abajo leen filas completas y fallarían si aún no existen.
    _ensure_appointment_source()
    _add_column("services", "supply_cost", "FLOAT")
    _add_column("reviews", "appointment_id", "INTEGER")
    _add_column("staff_members", "goal", "FLOAT")
    _add_column("staff_members", "color", "VARCHAR(9)")
    _add_column("staff_members", "tier_amount", "FLOAT")
    _add_column("staff_members", "tier_percent", "INTEGER")
    _add_column("businesses", "monthly_sent_on", "VARCHAR(7)")
    _add_column("businesses", "google_review_url", "VARCHAR(500)")
    _add_column("businesses", "accent_color", "VARCHAR(9)")
    _add_column("businesses", "button_shape", "VARCHAR(10) DEFAULT 'pill'")
    _add_column("businesses", "button_fill", "VARCHAR(10) DEFAULT 'solid'")
    _add_column("businesses", "font_style", "VARCHAR(10) DEFAULT 'modern'")
    _add_column("businesses", "header_style", "VARCHAR(10) DEFAULT 'cover'")
    _add_column("businesses", "old_slugs", "VARCHAR(1000)")
    # Los negocios que ya existían siguen con comisiones encendidas, como hasta ahora.
    _add_column("businesses", "uses_commissions", "BOOLEAN DEFAULT TRUE")
    _add_column("sales", "method", "VARCHAR(20)")
    _add_column("cash_counts", "opening", "FLOAT DEFAULT 0")
    _add_column("cash_counts", "closed", "BOOLEAN DEFAULT FALSE")
    _add_column("cash_counts", "closed_by", "VARCHAR(255)")
    _add_column("cash_counts", "closed_at", "TIMESTAMP")
    _add_column("businesses", "latitude", "FLOAT")
    _add_column("businesses", "map_embed", "VARCHAR(800)")
    _add_column("businesses", "longitude", "FLOAT")
    _add_column("services", "sort_order", "INTEGER DEFAULT 0")
    _add_column("services", "featured", "BOOLEAN DEFAULT 0")
    _add_column("services", "cleanup_minutes", "INTEGER DEFAULT 0")
    _add_column("services", "wait_start", "INTEGER")
    _add_column("services", "wait_minutes", "INTEGER DEFAULT 0")
    _add_column("services", "variants", "VARCHAR(4000)")
    _replace_preliminary_appointments(Appointment)
    _ensure_appointment_notes()
    _ensure_appointment_cancel_token()
    _ensure_staff_profile_columns()
    _ensure_business_created_at()
    _ensure_business_canvas_color()
    _ensure_business_profile_columns()
    _ensure_user_terms_accepted()
    _ensure_super_admin()
    _ensure_client_internal_notes()
    _ensure_client_birthday()
    _ensure_client_tags()
    _ensure_business_cancel_hours()
    _ensure_business_deposit()
    _ensure_deposit_followup()
    _ensure_visit_plus()
    _unpack_shop_notes()
    _move_closures()
    _merge_duplicate_clients()


def _add_column(table: str, column: str, ddl: str) -> None:
    inspector = inspect(engine)
    if inspector.has_table(table) and column not in {c["name"] for c in inspector.get_columns(table)}:
        with engine.begin() as connection:
            connection.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def _ensure_appointment_source() -> None:
    inspector = inspect(engine)
    if inspector.has_table("appointments") and "source" not in {c["name"] for c in inspector.get_columns("appointments")}:
        with engine.begin() as connection:
            connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN source VARCHAR(10)")


def _merge_duplicate_clients() -> None:
    """Fichas repetidas por el mismo teléfono quedan en una sola (antes se unían al leer la lista)."""
    from sqlmodel import Session

    from app.models.client import merge_duplicates

    with Session(engine) as session:
        merge_duplicates(session)


def _replace_preliminary_appointments(appointment_model: type[SQLModel]) -> None:
    """The first appointments table had no staff, service, or end time."""
    inspector = inspect(engine)
    if not inspector.has_table("appointments"):
        return
    columns = {column["name"] for column in inspector.get_columns("appointments")}
    required = {"staff_id", "service_id", "ends_at", "client_phone"}
    if required <= columns:
        return
    appointment_model.__table__.drop(engine, checkfirst=True)  # type: ignore[attr-defined]
    appointment_model.__table__.create(engine, checkfirst=True)  # type: ignore[attr-defined]


def _ensure_appointment_notes() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("appointments"):
        return
    columns = {column["name"] for column in inspector.get_columns("appointments")}
    if "notes" in columns:
        return
    with engine.begin() as connection:
        connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN notes VARCHAR(2000)")


def _ensure_appointment_cancel_token() -> None:
    import uuid

    inspector = inspect(engine)
    if not inspector.has_table("appointments"):
        return
    columns = {column["name"] for column in inspector.get_columns("appointments")}
    with engine.begin() as connection:
        if "cancel_token" not in columns:
            connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN cancel_token VARCHAR(36)")
        missing = connection.exec_driver_sql(
            "SELECT id FROM appointments WHERE cancel_token IS NULL OR cancel_token = ''"
        ).fetchall()
        for (appointment_id,) in missing:
            connection.exec_driver_sql(
                "UPDATE appointments SET cancel_token = ? WHERE id = ?",
                (str(uuid.uuid4()), appointment_id),
            )
        connection.exec_driver_sql(
            "CREATE UNIQUE INDEX IF NOT EXISTS ix_appointments_cancel_token ON appointments (cancel_token)"
        )


def _ensure_staff_profile_columns() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("staff_members"):
        return
    columns = {column["name"] for column in inspector.get_columns("staff_members")}
    statements = []
    if "user_id" not in columns:
        statements.append("ALTER TABLE staff_members ADD COLUMN user_id INTEGER")
    if "avatar_url" not in columns:
        statements.append("ALTER TABLE staff_members ADD COLUMN avatar_url VARCHAR(2048)")
    if "bio" not in columns:
        statements.append("ALTER TABLE staff_members ADD COLUMN bio VARCHAR(2000)")
    if not statements:
        return
    with engine.begin() as connection:
        for statement in statements:
            connection.exec_driver_sql(statement)
        connection.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_staff_members_user_id ON staff_members (user_id)"
        )


def _ensure_business_created_at() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("businesses"):
        return
    columns = {column["name"] for column in inspector.get_columns("businesses")}
    if "created_at" in columns:
        return
    from datetime import datetime

    stamp = datetime.now().replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S")
    with engine.begin() as connection:
        connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN created_at DATETIME")
        connection.exec_driver_sql(
            "UPDATE businesses SET created_at = ? WHERE created_at IS NULL",
            (stamp,),
        )


def _ensure_business_canvas_color() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("businesses"):
        return
    columns = {column["name"] for column in inspector.get_columns("businesses")}
    if "canvas_color" in columns:
        return
    with engine.begin() as connection:
        connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN canvas_color VARCHAR(16)")


def _ensure_business_profile_columns() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("businesses"):
        return
    columns = {column["name"] for column in inspector.get_columns("businesses")}
    statements = [
        f"ALTER TABLE businesses ADD COLUMN {name} {kind}"
        for name, kind in (
            ("description", "VARCHAR(500)"),
            ("address", "VARCHAR(255)"),
            ("instagram", "VARCHAR(255)"),
            ("facebook", "VARCHAR(255)"),
            ("website", "VARCHAR(255)"),
            ("business_kind", "VARCHAR(40)"),
            ("timezone", "VARCHAR(64) DEFAULT 'America/Mexico_City'"),
            ("email_alerts", "VARCHAR(255)"),
            ("summary_sent_on", "VARCHAR(10)"),
            ("link_shared", "BOOLEAN DEFAULT FALSE"),
            ("bookings_paused", "BOOLEAN DEFAULT FALSE"),
            ("closed_from", "VARCHAR(10)"),
            ("closed_to", "VARCHAR(10)"),
            ("promo_text", "VARCHAR(80)"),
            ("promo_until", "VARCHAR(10)"),
            ("gallery", "TEXT"),
            ("message_templates", "TEXT"),
            ("closures", "TEXT"),
            ("payment_methods", "VARCHAR(120)"),
            ("approve_bookings", "BOOLEAN DEFAULT FALSE"),
            ("auto_reminders", "BOOLEAN DEFAULT FALSE"),
            ("reminder_hours", "INTEGER DEFAULT 24"),
            ("auto_return", "BOOLEAN DEFAULT FALSE"),
        )
        if name not in columns
    ]
    if not statements:
        return
    with engine.begin() as connection:
        for statement in statements:
            connection.exec_driver_sql(statement)


def _ensure_super_admin() -> None:
    """Crea la cuenta de plataforma solo si SUPERADMIN_EMAIL y SUPERADMIN_PASSWORD están en el entorno.

    Sin ellas no se crea ninguna: no hay una cuenta ni una contraseña por defecto.
    """
    from sqlalchemy.exc import IntegrityError
    from sqlmodel import Session, select

    from app.core.config import settings
    from app.core.security import hash_password
    from app.models.user import User, UserRole

    email = settings.SUPERADMIN_EMAIL.strip().lower()
    password = settings.SUPERADMIN_PASSWORD
    if not email or not password:
        return
    if len(password) < 12:
        raise RuntimeError("SUPERADMIN_PASSWORD debe tener al menos 12 caracteres")

    with Session(engine) as session:
        existing = session.exec(select(User).where(User.email == email)).first()
        if existing is not None:
            return
        session.add(
            User(
                email=email,
                hashed_password=hash_password(password),
                role=UserRole.super_admin,
                full_name="Super Administrador",
                business_id=None,
            )
        )
        try:
            session.commit()
        except IntegrityError:
            session.rollback()


def _ensure_business_cancel_hours() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("businesses"):
        return
    columns = {column["name"] for column in inspector.get_columns("businesses")}
    if "cancel_hours" in columns:
        return
    with engine.begin() as connection:
        connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN cancel_hours INTEGER")


def _ensure_business_deposit() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("businesses"):
        return
    columns = {column["name"] for column in inspector.get_columns("businesses")}
    statements = []
    if "deposit_amount" not in columns:
        statements.append("ALTER TABLE businesses ADD COLUMN deposit_amount FLOAT")
    if "deposit_account" not in columns:
        statements.append("ALTER TABLE businesses ADD COLUMN deposit_account VARCHAR(120)")
    if not statements:
        return
    with engine.begin() as connection:
        for statement in statements:
            connection.exec_driver_sql(statement)


def _ensure_deposit_followup() -> None:
    inspector = inspect(engine)
    with engine.begin() as connection:
        if inspector.has_table("appointments"):
            columns = {column["name"] for column in inspector.get_columns("appointments")}
            if "created_at" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN created_at DATETIME")
            if "deposit_amount" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN deposit_amount FLOAT")
            if "payment_proof" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN payment_proof TEXT")
            connection.exec_driver_sql("UPDATE appointments SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL")
        if inspector.has_table("businesses"):
            columns = {column["name"] for column in inspector.get_columns("businesses")}
            if "deposit_hold_hours" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN deposit_hold_hours INTEGER")
        if inspector.has_table("services"):
            columns = {column["name"] for column in inspector.get_columns("services")}
            if "deposit_amount" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN deposit_amount FLOAT")


def _ensure_visit_plus() -> None:
    inspector = inspect(engine)
    with engine.begin() as connection:
        if inspector.has_table("services"):
            columns = {column["name"] for column in inspector.get_columns("services")}
            if "variable_price" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN variable_price BOOLEAN DEFAULT FALSE")
            if "image_url" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN image_url TEXT")
            if "return_days" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN return_days INTEGER")
            if "questions" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN questions VARCHAR(1000)")
            if "capacity" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN capacity INTEGER DEFAULT 1")
            if "category" not in columns:
                connection.exec_driver_sql("ALTER TABLE services ADD COLUMN category VARCHAR(80)")
        if inspector.has_table("reviews"):
            columns = {column["name"] for column in inspector.get_columns("reviews")}
            if "reply" not in columns:
                connection.exec_driver_sql("ALTER TABLE reviews ADD COLUMN reply VARCHAR(500)")
        if inspector.has_table("appointments"):
            columns = {column["name"] for column in inspector.get_columns("appointments")}
            if "quoted_price" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN quoted_price FLOAT")
            if "client_confirmed" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN client_confirmed BOOLEAN DEFAULT FALSE")
            if "price_accepted" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN price_accepted BOOLEAN DEFAULT FALSE")
        if inspector.has_table("businesses"):
            columns = {column["name"] for column in inspector.get_columns("businesses")}
            if "deposit_percent" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN deposit_percent INTEGER")
            if "buffer_minutes" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN buffer_minutes INTEGER DEFAULT 0")
            if "staff_label" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN staff_label VARCHAR(40) DEFAULT 'Colaborador'")
            if "min_notice_hours" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN min_notice_hours INTEGER DEFAULT 0")
            if "max_days_ahead" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN max_days_ahead INTEGER DEFAULT 90")
            if "cancel_policy" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN cancel_policy VARCHAR(500)")
            if "resources" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN resources VARCHAR(255)")
            if "payment_url" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN payment_url VARCHAR(255)")
            for name, kind in (("loyalty_every", "INTEGER"), ("loyalty_percent", "INTEGER"), ("coupons", "TEXT")):
                if name not in columns:
                    connection.exec_driver_sql(f"ALTER TABLE businesses ADD COLUMN {name} {kind}")
            if "demo_ids" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN demo_ids TEXT")
            if "privacy_notice" not in columns:
                connection.exec_driver_sql("ALTER TABLE businesses ADD COLUMN privacy_notice TEXT")
        if inspector.has_table("appointments"):
            columns = {column["name"] for column in inspector.get_columns("appointments")}
            if "resource_name" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN resource_name VARCHAR(80)")
            if "extra_label" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN extra_label VARCHAR(255)")
            if "answers" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN answers VARCHAR(2000)")
            if "use_package" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN use_package BOOLEAN DEFAULT FALSE")
            for name, kind in (("tip", "FLOAT"), ("visit_note", "TEXT"), ("discount_percent", "INTEGER"), ("needs_approval", "BOOLEAN DEFAULT FALSE"),
                               ("reminder_sent_at", "TIMESTAMP"), ("return_invited", "BOOLEAN DEFAULT FALSE"), ("spei_tracking", "VARCHAR(30)"),
                               ("paid_claim", "BOOLEAN DEFAULT FALSE")):
                if name not in columns:
                    connection.exec_driver_sql(f"ALTER TABLE appointments ADD COLUMN {name} {kind}")
            if "payment_method" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN payment_method VARCHAR(20)")
            if "reference_photos" not in columns:
                connection.exec_driver_sql("ALTER TABLE appointments ADD COLUMN reference_photos TEXT")
        if inspector.has_table("staff_members"):
            columns = {column["name"] for column in inspector.get_columns("staff_members")}
            if "slot_times" not in columns:
                connection.exec_driver_sql("ALTER TABLE staff_members ADD COLUMN slot_times VARCHAR(80)")
            if "commission_percent" not in columns:
                connection.exec_driver_sql("ALTER TABLE staff_members ADD COLUMN commission_percent INTEGER DEFAULT 0")
        if inspector.has_table("schedules"):
            columns = {column["name"] for column in inspector.get_columns("schedules")}
            if "slot_times" not in columns:
                connection.exec_driver_sql("ALTER TABLE schedules ADD COLUMN slot_times VARCHAR(120)")
            if "break_start" not in columns:
                connection.exec_driver_sql("ALTER TABLE schedules ADD COLUMN break_start VARCHAR(5)")
            if "break_end" not in columns:
                connection.exec_driver_sql("ALTER TABLE schedules ADD COLUMN break_end VARCHAR(5)")
        if inspector.has_table("products"):
            columns = {column["name"] for column in inspector.get_columns("products")}
            if "cost" not in columns:
                connection.exec_driver_sql("ALTER TABLE products ADD COLUMN cost FLOAT DEFAULT 0")
        if inspector.has_table("stock_moves"):
            columns = {column["name"] for column in inspector.get_columns("stock_moves")}
            if "amount" not in columns:
                connection.exec_driver_sql("ALTER TABLE stock_moves ADD COLUMN amount FLOAT DEFAULT 0")
            if "iva" not in columns:
                connection.exec_driver_sql("ALTER TABLE stock_moves ADD COLUMN iva FLOAT DEFAULT 0")
        if inspector.has_table("expenses"):
            columns = {column["name"] for column in inspector.get_columns("expenses")}
            if "cadence" not in columns:
                connection.exec_driver_sql("ALTER TABLE expenses ADD COLUMN cadence VARCHAR(8)")
            if "category" not in columns:
                connection.exec_driver_sql("ALTER TABLE expenses ADD COLUMN category VARCHAR(24)")
            if "pay_day" not in columns:
                connection.exec_driver_sql("ALTER TABLE expenses ADD COLUMN pay_day INTEGER")


def _ensure_client_birthday() -> None:
    inspector = inspect(engine)
    if inspector.has_table("clients") and "birthday" not in {c["name"] for c in inspector.get_columns("clients")}:
        with engine.begin() as connection:
            connection.exec_driver_sql("ALTER TABLE clients ADD COLUMN birthday VARCHAR(10)")


def _ensure_client_tags() -> None:
    inspector = inspect(engine)
    if inspector.has_table("clients") and "tags" not in {c["name"] for c in inspector.get_columns("clients")}:
        with engine.begin() as connection:
            connection.exec_driver_sql("ALTER TABLE clients ADD COLUMN tags VARCHAR(500)")


def _ensure_client_internal_notes() -> None:
    inspector = inspect(engine)
    if not inspector.has_table("clients"):
        return
    columns = {column["name"] for column in inspector.get_columns("clients")}
    if "internal_notes" in columns:
        return
    with engine.begin() as connection:
        connection.exec_driver_sql("ALTER TABLE clients ADD COLUMN internal_notes VARCHAR(2000)")


def _ensure_user_terms_accepted() -> None:
    inspector = inspect(engine)
    if inspector.has_table("users") and "terms_accepted_at" not in {c["name"] for c in inspector.get_columns("users")}:
        with engine.begin() as connection:
            # TIMESTAMP vale tanto en SQLite como en PostgreSQL.
            connection.exec_driver_sql("ALTER TABLE users ADD COLUMN terms_accepted_at TIMESTAMP")


def _unpack_shop_notes() -> None:
    """Pasa la pausa, el cierre, las fotos y la promoción del texto de `resources` a sus columnas."""
    import json

    from sqlmodel import Session, select

    from app.core.shop_note import MARK, unpack_resources
    from app.models.business import Business

    with Session(engine) as session:
        rows = session.exec(select(Business).where(Business.resources.contains(MARK))).all()  # type: ignore[union-attr]
        for business in rows:
            text, note = unpack_resources(business.resources)
            business.resources = text
            business.bookings_paused = bool(note.get("pause"))
            business.closed_from = note.get("from") or None
            business.closed_to = note.get("to") or None
            business.promo_text = (note.get("promo") or "")[:80] or None
            business.promo_until = note.get("until") or None
            photos = [item for item in note.get("photos") or [] if isinstance(item, str)][:3]
            business.gallery = json.dumps(photos) if photos else None
            session.add(business)
        session.commit()


def _move_closures() -> None:
    """El cierre único (closed_from/closed_to) pasa a ser el primero de la lista `closures`."""
    from sqlmodel import Session, select

    from app.core.shop_note import pack_closures
    from app.models.business import Business

    with Session(engine) as session:
        rows = session.exec(select(Business).where(Business.closed_from.is_not(None))).all()  # type: ignore[union-attr]
        for business in rows:
            if business.closed_from and business.closed_to and not business.closures:
                business.closures = pack_closures([{"from": business.closed_from, "to": business.closed_to, "label": "Vacaciones"}])
            business.closed_from = business.closed_to = None
            session.add(business)
        session.commit()


if __name__ == "__main__":
    init_db()
