import uuid
from pathlib import Path

LOGO_DIR = Path("uploads") / "logos"
_ALLOWED = {".png": ".png", ".jpg": ".jpg", ".jpeg": ".jpg", ".webp": ".webp"}
_MAX_BYTES = 2 * 1024 * 1024


def save_logo(content: bytes, filename: str) -> str:
    suffix = _ALLOWED.get(Path(filename or "").suffix.lower())
    if suffix is None:
        raise ValueError("Usa una imagen PNG, JPG o WEBP")
    if not content or len(content) > _MAX_BYTES:
        raise ValueError("La imagen debe pesar menos de 2 MB")
    LOGO_DIR.mkdir(parents=True, exist_ok=True)
    name = f"{uuid.uuid4().hex}{suffix}"
    (LOGO_DIR / name).write_bytes(content)
    return f"/uploads/logos/{name}"
