from datetime import date, datetime, time, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field, field_validator
from sqlmodel import Session, select

from app.core.agenda_scope import ensure_own_staff, own_staff_id
from app.core.clock import local_today
from app.core.booking import as_local_naive
from app.db.database import get_session
from app.models.business import Business
from app.models.staff import Staff
from app.models.standing_block import StandingBlock
from app.models.time_block import TimeBlock
from app.routers.auth import BusinessUserDep

router = APIRouter(prefix="/blocks", tags=["blocks"])
SessionDep = Annotated[Session, Depends(get_session)]


class BlockCreate(BaseModel):
    staff_id: int
    starts_at: datetime
    ends_at: datetime
    note: str | None = Field(default=None, max_length=255)

    @field_validator("note", mode="before")
    @classmethod
    def blank(cls, value: object) -> object:
        if isinstance(value, str) and not value.strip():
            return None
        return value


class BlockRead(BaseModel):
    id: int
    staff_id: int
    staff_name: str
    starts_at: datetime
    ends_at: datetime
    note: str | None
    rule_id: int | None = None


class StandingCreate(BaseModel):
    staff_id: int
    start_time: str
    end_time: str
    note: str | None = Field(default=None, max_length=255)
    weekdays: str = "0,1,2,3,4"


def _business_id(user: BusinessUserDep) -> int:
    if user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso para administrar este negocio")
    return user.business_id


@router.get("", response_model=list[BlockRead])
def list_blocks(
    session: SessionDep,
    current_user: BusinessUserDep,
    start_date: date,
    end_date: date,
    staff_id: int | None = None,
) -> list[BlockRead]:
    business_id = _business_id(current_user)
    mine = own_staff_id(session, current_user)
    if mine is not None:
        staff_id = mine  # el personal solo ve sus propios bloqueos
    start = datetime.combine(start_date, time.min)
    end = datetime.combine(end_date, time.min) + timedelta(days=1)
    statement = select(TimeBlock, Staff.full_name).join(Staff, Staff.id == TimeBlock.staff_id).where(
        TimeBlock.business_id == business_id,
        TimeBlock.starts_at < end,
        TimeBlock.ends_at > start,
    )
    if staff_id is not None:
        statement = statement.where(TimeBlock.staff_id == staff_id)
    rows = session.exec(statement.order_by(TimeBlock.starts_at)).all()
    listed = [
        BlockRead(id=block.id, staff_id=block.staff_id, staff_name=name, starts_at=block.starts_at, ends_at=block.ends_at, note=block.note)  # type: ignore[arg-type]
        for block, name in rows
        if block.id is not None
    ]
    rules = session.exec(select(StandingBlock, Staff.full_name).join(Staff, Staff.id == StandingBlock.staff_id).where(StandingBlock.business_id == business_id)).all()
    cursor = start_date
    while cursor <= end_date:
        for rule, name in rules:
            if staff_id is not None and rule.staff_id != staff_id:
                continue
            if str(cursor.weekday()) not in rule.weekdays.split(","):
                continue
            if rule.id is None:
                continue
            start_at = datetime.combine(cursor, time.fromisoformat(rule.start_time))
            end_at = datetime.combine(cursor, time.fromisoformat(rule.end_time))
            listed.append(
                BlockRead(
                    id=-(rule.id * 1000 + cursor.toordinal() % 1000),
                    staff_id=rule.staff_id,
                    staff_name=name,
                    starts_at=start_at,
                    ends_at=end_at,
                    note=rule.note,
                    rule_id=rule.id,
                )
            )
        cursor += timedelta(days=1)
    return listed


@router.post("", response_model=BlockRead, status_code=status.HTTP_201_CREATED)
def create_block(body: BlockCreate, session: SessionDep, current_user: BusinessUserDep) -> BlockRead:
    business_id = _business_id(current_user)
    ensure_own_staff(session, current_user, body.staff_id)
    member = session.get(Staff, body.staff_id)
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")
    starts_at = as_local_naive(body.starts_at)
    ends_at = as_local_naive(body.ends_at)
    if ends_at <= starts_at:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="La hora de fin debe ser posterior")
    block = TimeBlock(business_id=business_id, staff_id=body.staff_id, starts_at=starts_at, ends_at=ends_at, note=body.note.strip() if body.note else None)
    session.add(block)
    session.commit()
    session.refresh(block)
    return BlockRead(id=block.id, staff_id=block.staff_id, staff_name=member.full_name, starts_at=block.starts_at, ends_at=block.ends_at, note=block.note)  # type: ignore[arg-type]


@router.post("/standing", response_model=BlockRead, status_code=status.HTTP_201_CREATED)
def create_standing(body: StandingCreate, session: SessionDep, current_user: BusinessUserDep) -> BlockRead:
    business_id = _business_id(current_user)
    ensure_own_staff(session, current_user, body.staff_id)
    member = session.get(Staff, body.staff_id)
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")
    if body.end_time <= body.start_time:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="La hora de fin debe ser posterior")
    rule = StandingBlock(
        business_id=business_id,
        staff_id=body.staff_id,
        weekdays=body.weekdays,
        start_time=body.start_time[:5],
        end_time=body.end_time[:5],
        note=body.note.strip() if body.note else None,
    )
    session.add(rule)
    session.commit()
    session.refresh(rule)
    today = local_today(session.get(Business, business_id))
    start_at = datetime.combine(today, time.fromisoformat(rule.start_time))
    end_at = datetime.combine(today, time.fromisoformat(rule.end_time))
    return BlockRead(id=-(rule.id or 0), staff_id=body.staff_id, staff_name=member.full_name, starts_at=start_at, ends_at=end_at, note=rule.note, rule_id=rule.id)


@router.delete("/standing/{rule_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_standing(rule_id: int, session: SessionDep, current_user: BusinessUserDep) -> Response:
    business_id = _business_id(current_user)
    rule = session.get(StandingBlock, rule_id)
    mine = own_staff_id(session, current_user)
    if rule is None or rule.business_id != business_id or (mine is not None and rule.staff_id != mine):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bloqueo no encontrado")
    session.delete(rule)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


def delete_block(block_id: int, session: Session, current_user: BusinessUserDep) -> Response:
    business_id = _business_id(current_user)
    block = session.get(TimeBlock, block_id)
    mine = own_staff_id(session, current_user)
    if block is None or block.business_id != business_id or (mine is not None and block.staff_id != mine):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bloqueo no encontrado")
    session.delete(block)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.delete("/{block_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_block_route(block_id: int, session: SessionDep, current_user: BusinessUserDep) -> Response:
    return delete_block(block_id, session, current_user)


agenda_router = APIRouter(prefix="/agenda/blocks", tags=["blocks"])


@agenda_router.delete("/{block_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_agenda_block(block_id: int, session: SessionDep, current_user: BusinessUserDep) -> Response:
    return delete_block(block_id, session, current_user)
