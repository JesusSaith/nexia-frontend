from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.db.database import get_session
from app.core.clock import local_now
from app.core.returns import due_clients
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.client import Client, ClientContact, phone_key
from app.models.package import ClientPackage
from app.models.service import Service
from app.models.staff import Staff
from app.routers.auth import BusinessUserDep, ManagerDep

router = APIRouter(prefix="/clients", tags=["clients"])

SessionDep = Annotated[Session, Depends(get_session)]


class ClientRead(BaseModel):
    id: int
    full_name: str
    phone: str
    email: str | None
    notes: str | None
    birthday: str | None = None
    visit_count: int = 0
    total_spent: float = 0
    cancel_count: int = 0
    no_show_count: int = 0
    last_visit: str | None = None
    tags: list[str] = []
    # Próxima cita agendada (o esperando anticipo), en hora local del negocio.
    next_visit: str | None = None
    # Último mensaje que la dueña le mandó desde Nexia (AAAA-MM-DDTHH:MM) y de qué tipo.
    last_contact_at: str | None = None
    last_contact_kind: str | None = None


class ClientCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=255)
    phone: str = Field(min_length=10, max_length=32)
    email: str | None = Field(default=None, max_length=255)


class ClientVisit(BaseModel):
    id: int | None = None
    starts_at: datetime
    service_id: int | None = None
    service_name: str
    staff_id: int | None = None
    staff_name: str
    price: float
    status: str
    visit_note: str | None = None


class ClientDetail(ClientRead):
    internal_notes: str | None
    visit_count: int
    no_show_count: int
    total_spent: float
    visits: list[ClientVisit]
    # Los últimos mensajes que se le mandaron, del más reciente al más viejo.
    contacts: list[dict] = []


class ContactBody(BaseModel):
    kind: str = Field(pattern=r"^(invitar|volver|felicitar|otro)$")


class ClientNotesUpdate(BaseModel):
    internal_notes: str | None = Field(default=None, max_length=2000)
    # Cumpleaños AAAA-MM-DD; vacío o null lo borra.
    birthday: str | None = Field(default=None, max_length=10, pattern=r"^(\d{4}-\d{2}-\d{2})?$")
    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    phone: str | None = Field(default=None, min_length=10, max_length=32)
    tags: list[str] | None = Field(default=None, max_length=10)


class ClientImportRow(BaseModel):
    full_name: str = Field(min_length=1, max_length=255)
    phone: str = Field(min_length=1, max_length=32)
    email: str | None = Field(default=None, max_length=255)
    birthday: str | None = Field(default=None, max_length=10)


class ClientImport(BaseModel):
    rows: list[ClientImportRow] = Field(max_length=5000)


def split_tags(value: str | None) -> list[str]:
    return [tag for tag in (part.strip() for part in (value or "").split(",")) if tag]


def join_tags(tags: list[str]) -> str | None:
    clean: list[str] = []
    for tag in tags:
        tag = tag.replace(",", " ").strip()[:30]
        if tag and tag.lower() not in {item.lower() for item in clean}:
            clean.append(tag)
    return ",".join(clean[:10]) or None


def _clean_phone(value: str) -> str:
    """10 dígitos; si pegan +52 se quita."""
    digits = "".join(char for char in value if char.isdigit())
    if len(digits) == 12 and digits.startswith("52"):
        digits = digits[2:]
    if len(digits) != 10:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="El teléfono debe tener 10 dígitos")
    return digits


def _phone_taken(session: Session, business_id: int, phone: str, skip: int | None = None) -> bool:
    key = phone_key(phone)
    return any(
        phone_key(row.phone) == key and row.id != skip
        for row in session.exec(select(Client).where(Client.business_id == business_id)).all()
    )


@router.get("", response_model=list[ClientRead])
def list_clients(session: SessionDep, current_user: BusinessUserDep) -> list[ClientRead]:
    if current_user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso para administrar este negocio")
    business_id = current_user.business_id
    clients = list(session.exec(select(Client).where(Client.business_id == business_id).order_by(Client.full_name)).all())
    prices = {
        item.id: item.price
        for item in session.exec(select(Service).where(Service.business_id == business_id)).all()
        if item.id is not None
    }
    now = local_now(session.get(Business, business_id))
    # Solo las columnas que hacen falta: con miles de citas, cargar filas completas es lo que más pesa.
    visits = session.exec(
        select(Appointment.client_phone, Appointment.status, Appointment.starts_at, Appointment.quoted_price, Appointment.service_id).where(
            Appointment.business_id == business_id
        )
    ).all()
    done: dict[str, tuple[int, float, int, int]] = {}
    last_seen: dict[str, str] = {}
    upcoming: dict[str, datetime] = {}
    for phone, state, starts_at, quoted, service_id in visits:
        key = phone_key(phone)
        count, total, cancelled, missed = done.get(key, (0, 0.0, 0, 0))
        if state == AppointmentStatus.completed:
            amount = quoted if quoted is not None else prices.get(service_id, 0)
            done[key] = (count + 1, total + float(amount), cancelled, missed)
            day = starts_at.date().isoformat()
            if day > last_seen.get(key, ""):
                last_seen[key] = day
        elif state == AppointmentStatus.cancelled:
            done[key] = (count, total, cancelled + 1, missed)
        elif state == AppointmentStatus.no_show:
            done[key] = (count, total, cancelled, missed + 1)
        elif state in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit) and starts_at >= now:
            if key not in upcoming or starts_at < upcoming[key]:
                upcoming[key] = starts_at
    # Fichas repetidas con el mismo teléfono se muestran como una sola (la más antigua),
    # sin borrar nada: una lectura no debe cambiar datos.
    grouped: dict[str, list[Client]] = {}
    for client in clients:
        grouped.setdefault(phone_key(client.phone), []).append(client)
    latest: dict[str, ClientContact] = {}
    for contact in session.exec(
        select(ClientContact).where(ClientContact.business_id == business_id).order_by(ClientContact.created_at)  # type: ignore[arg-type]
    ).all():
        latest[contact.phone_key] = contact
    rows: list[ClientRead] = []
    for key, group in grouped.items():
        keep = min(group, key=lambda item: item.id or 0)
        count, total, cancelled, missed = done.get(key, (0, 0.0, 0, 0))
        next_at = upcoming.get(key)
        rows.append(
            ClientRead(
                id=keep.id or 0,
                full_name=keep.full_name,
                phone=keep.phone,
                email=keep.email or next((item.email for item in group if item.email), None),
                notes=keep.notes,
                birthday=keep.birthday or next((item.birthday for item in group if item.birthday), None),
                visit_count=count,
                total_spent=round(total, 2),
                cancel_count=cancelled,
                no_show_count=missed,
                tags=split_tags(keep.tags),
                last_visit=last_seen.get(key),
                next_visit=next_at.isoformat() if next_at else None,
                last_contact_at=latest[key].created_at.isoformat(timespec="minutes") if key in latest else None,
                last_contact_kind=latest[key].kind if key in latest else None,
            )
        )
    rows.sort(key=lambda item: item.full_name.lower())
    return rows


def _owned(session: Session, user: BusinessUserDep, client_id: int) -> Client:
    if user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso para administrar este negocio")
    client = session.get(Client, client_id)
    if client is None or client.business_id != user.business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cliente no encontrado")
    return client


def _detail(session: Session, client: Client) -> ClientDetail:
    key = phone_key(client.phone)
    rows = [
        row
        for row in session.exec(
            select(Appointment, Service.name, Service.price, Staff.full_name)
            .join(Service, Service.id == Appointment.service_id)
            .join(Staff, Staff.id == Appointment.staff_id)
            .where(Appointment.business_id == client.business_id)
            .order_by(Appointment.starts_at.desc())
        ).all()
        if phone_key(row[0].client_phone) == key
    ]
    visits = [
        ClientVisit(
            id=item.id,
            visit_note=item.visit_note,
            starts_at=item.starts_at,
            service_id=item.service_id,
            service_name=service,
            staff_id=item.staff_id,
            staff_name=member,
            price=float(item.quoted_price if item.quoted_price is not None else price),
            status=item.status.value,
        )
        for item, service, price, member in rows
    ]
    spent = 0.0
    done = 0
    for item, _service, price, _member in rows:
        if item.status != AppointmentStatus.completed:
            continue
        done += 1
        spent += item.quoted_price if item.quoted_price is not None else float(price)
    missed = sum(1 for row in rows if row[0].status == AppointmentStatus.no_show)
    return ClientDetail(
        id=client.id,  # type: ignore[arg-type]
        full_name=client.full_name,
        phone=client.phone,
        email=client.email,
        notes=client.notes,
        birthday=client.birthday,
        internal_notes=client.internal_notes,
        tags=split_tags(client.tags),
        visit_count=done,
        no_show_count=missed,
        total_spent=round(spent, 2),
        visits=visits,
        contacts=[
            {"kind": item.kind, "at": item.created_at.isoformat(timespec="minutes"), "by": item.created_by}
            for item in session.exec(
                select(ClientContact)
                .where(ClientContact.business_id == client.business_id, ClientContact.phone_key == key)
                .order_by(ClientContact.created_at.desc())  # type: ignore[attr-defined]
                .limit(10)
            ).all()
        ],
    )


@router.get("/due")
def list_due_clients(session: SessionDep, current_user: BusinessUserDep) -> list[dict]:
    """"Te toca": clientas a las que ya les toca volver, con un horario sugerido (app/core/returns.py)."""
    business = session.get(Business, _business_of(current_user))
    return due_clients(session, business) if business else []


@router.post("/due/{appointment_id}/invited", status_code=status.HTTP_204_NO_CONTENT)
def mark_invited(appointment_id: int, session: SessionDep, current_user: BusinessUserDep) -> None:
    """La dueña ya le escribió: deja de aparecer como "por invitar" hasta su siguiente visita."""
    appointment = session.get(Appointment, appointment_id)
    if appointment is None or appointment.business_id != _business_of(current_user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    appointment.return_invited = True
    session.add(appointment)
    if appointment.client_phone:
        session.add(ClientContact(business_id=appointment.business_id, phone_key=phone_key(appointment.client_phone), kind="volver", created_by=current_user.full_name))
    session.commit()


def _business_of(user: BusinessUserDep) -> int:
    if user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso para administrar este negocio")
    return user.business_id


@router.post("/{client_id}/contacts", response_model=ClientDetail, status_code=status.HTTP_201_CREATED)
def log_contact(client_id: int, body: ContactBody, session: SessionDep, current_user: BusinessUserDep) -> ClientDetail:
    """La dueña le acaba de escribir (invitarlo, felicitarlo…): queda anotado."""
    client = _owned(session, current_user, client_id)
    session.add(ClientContact(business_id=client.business_id, phone_key=phone_key(client.phone), kind=body.kind, created_by=current_user.full_name))
    session.commit()
    return _detail(session, client)


@router.post("", response_model=ClientDetail, status_code=status.HTTP_201_CREATED)
def create_client(body: ClientCreate, session: SessionDep, current_user: BusinessUserDep) -> ClientDetail:
    """Agregar a mano a alguien que aún no ha reservado."""
    business_id = _business_of(current_user)
    phone = _clean_phone(body.phone)
    if _phone_taken(session, business_id, phone):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ya tienes un cliente con ese teléfono")
    client = Client(business_id=business_id, full_name=body.full_name.strip(), phone=phone, email=(body.email or "").strip() or None)
    session.add(client)
    session.commit()
    session.refresh(client)
    return _detail(session, client)


@router.post("/import")
def import_clients(body: ClientImport, session: SessionDep, current_user: ManagerDep) -> dict:
    """Alta en lote desde un CSV: salta teléfonos inválidos o que ya existen."""
    business_id = _business_of(current_user)
    known = {phone_key(row.phone) for row in session.exec(select(Client).where(Client.business_id == business_id)).all()}
    created = skipped = 0
    for row in body.rows:
        digits = "".join(char for char in row.phone if char.isdigit())
        if len(digits) == 12 and digits.startswith("52"):
            digits = digits[2:]
        if len(digits) != 10 or phone_key(digits) in known:
            skipped += 1
            continue
        birthday = row.birthday if row.birthday and len(row.birthday) == 10 and row.birthday[4] == "-" else None
        session.add(Client(business_id=business_id, full_name=row.full_name.strip(), phone=digits, email=(row.email or "").strip() or None, birthday=birthday))
        known.add(phone_key(digits))
        created += 1
    session.commit()
    return {"created": created, "skipped": skipped}


@router.delete("/{client_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_client(client_id: int, session: SessionDep, current_user: ManagerDep) -> None:
    """
    Borrar a pedido de la persona (derechos ARCO): se borra la ficha y sus paquetes, y sus citas
    pasadas quedan anónimas para no perder los ingresos en Reportes. Con citas por venir no se puede.
    """
    client = _owned(session, current_user, client_id)
    key = phone_key(client.phone)
    business = session.get(Business, client.business_id)
    now = local_now(business)
    visits = [
        row
        for row in session.exec(select(Appointment).where(Appointment.business_id == client.business_id)).all()
        if phone_key(row.client_phone) == key
    ]
    if any(row.starts_at >= now and row.status in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit) for row in visits):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Tiene citas por venir. Cancélalas antes de borrar sus datos.")
    for row in visits:
        row.client_name = "Cliente eliminado"
        row.client_phone = ""
        row.client_email = None
        row.notes = None
        row.visit_note = None
        session.add(row)
    for pack in session.exec(select(ClientPackage).where(ClientPackage.business_id == client.business_id)).all():
        if phone_key(pack.client_phone) == key:
            session.delete(pack)
    for contact in session.exec(select(ClientContact).where(ClientContact.business_id == client.business_id, ClientContact.phone_key == key)).all():
        session.delete(contact)
    for twin in session.exec(select(Client).where(Client.business_id == client.business_id)).all():
        if phone_key(twin.phone) == key:
            session.delete(twin)
    session.commit()


@router.get("/{client_id}", response_model=ClientDetail)
def read_client(client_id: int, session: SessionDep, current_user: BusinessUserDep) -> ClientDetail:
    return _detail(session, _owned(session, current_user, client_id))


@router.patch("/{client_id}", response_model=ClientDetail)
def update_client_notes(
    client_id: int,
    body: ClientNotesUpdate,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> ClientDetail:
    client = _owned(session, current_user, client_id)
    fields = body.model_fields_set
    # Sin campos explícitos se conserva el comportamiento anterior (solo notas internas).
    if "internal_notes" in fields or not fields:
        client.internal_notes = body.internal_notes.strip() if body.internal_notes else None
    if "birthday" in fields:
        client.birthday = body.birthday or None
    if "tags" in fields:
        client.tags = join_tags(body.tags or [])
    if "full_name" in fields and body.full_name:
        client.full_name = body.full_name.strip()
    if "phone" in fields and body.phone:
        phone = _clean_phone(body.phone)
        if _phone_taken(session, client.business_id, phone, skip=client.id):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese teléfono ya es de otro cliente")
        for contact in session.exec(
            select(ClientContact).where(ClientContact.business_id == client.business_id, ClientContact.phone_key == phone_key(client.phone))
        ).all():
            contact.phone_key = phone_key(phone)
            session.add(contact)
        client.phone = phone
    session.add(client)
    session.commit()
    session.refresh(client)
    return _detail(session, client)
