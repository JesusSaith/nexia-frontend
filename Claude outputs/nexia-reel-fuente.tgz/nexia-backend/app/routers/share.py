from html import escape
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session

from app.core.origins import app_origin
from app.db.database import get_session
from app.routers.businesses import _active_business

router = APIRouter(tags=["share"])


@router.get("/s/{slug}", response_class=HTMLResponse, include_in_schema=False)
def share_booking_link(slug: str, request: Request, session: Session = Depends(get_session)) -> HTMLResponse:
    """Enlace para compartir: WhatsApp e Instagram leen aquí logo y nombre; la persona sigue a la reserva.

    La app web arma su contenido en el navegador y los generadores de vista previa no ejecutan
    JavaScript, por eso estas etiquetas se sirven desde el backend.
    """
    business = _active_business(session, slug)
    # ?app= lo agrega la app en local (cualquier puerto); solo se respeta si es de confianza.
    params = [(key, value) for key, value in request.query_params.multi_items() if key != "app"]
    query = f"?{urlencode(params)}" if params else ""
    booking = f"{app_origin(request, request.query_params.get('app'))}/{business.slug}/book{query}"
    image = str(request.url_for("read_logo", slug=business.slug)) if business.logo_url else ""
    title = escape(f"{business.name} · Reserva tu cita en línea")
    from app.core.booking import business_hours

    hours = business_hours(session, business.id)  # type: ignore[arg-type]
    base = business.description or "Elige servicio, día y hora en segundos. Sin llamadas ni esperas."
    description = escape(f"{base} Horario: {', '.join(hours)}." if hours else base)
    target = escape(booking, quote=True)
    image_tags = (
        f'<meta property="og:image" content="{escape(image, quote=True)}">'
        f'<meta name="twitter:image" content="{escape(image, quote=True)}">'
        if image
        else ""
    )
    page = f"""<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{description}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{escape(business.name)}">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{target}">
<meta property="og:locale" content="es_MX">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{description}">
{image_tags}
<link rel="canonical" href="{target}">
<meta http-equiv="refresh" content="0;url={target}">
</head>
<body style="font-family:system-ui,sans-serif;text-align:center;padding:48px 16px">
<p>Abriendo las reservas de {escape(business.name)}…</p>
<p><a href="{target}">Toca aquí si no se abre sola</a></p>
<script>location.replace({json_string(booking)});</script>
</body>
</html>"""
    return HTMLResponse(page, headers={"Cache-Control": "public, max-age=600"})


def json_string(value: str) -> str:
    import json

    # Evita que un "</script>" dentro del valor cierre la etiqueta.
    return json.dumps(value).replace("</", "<\\/")
