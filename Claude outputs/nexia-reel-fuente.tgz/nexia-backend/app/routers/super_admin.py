from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlmodel import Session, select

from app.core.dependencies import get_current_super_admin
from app.db.database import get_session
from app.models.appointment import Appointment
from app.models.business import Business
from app.models.staff import Staff
from app.models.user import User
from app.schemas.super_admin import BusinessStatusUpdate, PlatformBusiness

router = APIRouter(prefix="/super-admin", tags=["super-admin"])

SessionDep = Annotated[Session, Depends(get_session)]
SuperAdminDep = Annotated[User, Depends(get_current_super_admin)]


def _count_by_business(session: Session, model: type[Staff] | type[Appointment]) -> dict[int, int]:
    rows = session.exec(select(model.business_id, func.count(model.id)).group_by(model.business_id)).all()
    return {int(business_id): int(total) for business_id, total in rows}


def _to_platform_business(
    business: Business,
    staff_counts: dict[int, int],
    appointment_counts: dict[int, int],
) -> PlatformBusiness:
    if business.id is None:
        raise RuntimeError("Business id is missing")
    return PlatformBusiness(
        id=business.id,
        name=business.name,
        slug=business.slug,
        staff_count=staff_counts.get(business.id, 0),
        appointment_count=appointment_counts.get(business.id, 0),
        is_active=business.is_active,
    )


@router.get("/businesses", response_model=list[PlatformBusiness])
def list_platform_businesses(session: SessionDep, _: SuperAdminDep) -> list[PlatformBusiness]:
    businesses = session.exec(select(Business).order_by(Business.id)).all()
    staff_counts = _count_by_business(session, Staff)
    appointment_counts = _count_by_business(session, Appointment)
    return [_to_platform_business(business, staff_counts, appointment_counts) for business in businesses]


@router.put("/businesses/{business_id}/status", response_model=PlatformBusiness)
def update_business_status(
    business_id: int,
    body: BusinessStatusUpdate,
    session: SessionDep,
    _: SuperAdminDep,
) -> PlatformBusiness:
    business = session.get(Business, business_id)
    if business is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    business.is_active = body.is_active
    session.add(business)
    session.commit()
    session.refresh(business)
    staff_counts = _count_by_business(session, Staff)
    appointment_counts = _count_by_business(session, Appointment)
    return _to_platform_business(business, staff_counts, appointment_counts)
