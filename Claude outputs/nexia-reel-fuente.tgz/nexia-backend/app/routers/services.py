import json
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, delete, select

from app.db.database import get_session
from app.models.appointment import Appointment
from app.models.service import Service
from app.models.staff_service import StaffService
from app.models.service_category import ServiceCategory
from app.models.user import User
from app.routers.auth import BusinessUserDep, ManagerDep
from app.schemas.service import CategoryCreate, CategoryRead, ServiceCreate, ServiceRead, ServiceUpdate

router = APIRouter(prefix="/services", tags=["services"])

SessionDep = Annotated[Session, Depends(get_session)]


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return user.business_id


def _owned_service(session: Session, service_id: int, business_id: int) -> Service:
    service = session.get(Service, service_id)
    if service is None or service.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Servicio no encontrado")
    return service


class OrderBody(BaseModel):
    ids: list[int] = Field(max_length=500)


class RaiseBody(BaseModel):
    percent: float = Field(gt=-90, le=300)
    category: str | None = None


class CategoryRename(BaseModel):
    name: str = Field(min_length=1, max_length=80)


def _pack_variants(variants: list | None) -> str | None:
    rows = [item.model_dump() if hasattr(item, "model_dump") else item for item in (variants or [])]
    return json.dumps(rows, ensure_ascii=False) if rows else None


def _next_order(session: Session, business_id: int) -> int:
    rows = session.exec(select(Service.sort_order).where(Service.business_id == business_id)).all()
    return max([row or 0 for row in rows], default=0) + 1


@router.get("/categories", response_model=list[CategoryRead])
def list_categories(session: SessionDep, current_user: BusinessUserDep) -> list[ServiceCategory]:
    business_id = _business_id(current_user)
    rows = _category_rows(session, business_id)
    known = {row.name for row in rows}
    used = session.exec(
        select(Service.category).where(Service.business_id == business_id, Service.category.is_not(None))
    ).all()
    added = False
    for name in used:
        if name and name not in known:
            session.add(ServiceCategory(business_id=business_id, name=name))
            known.add(name)
            added = True
    if added:
        session.commit()
        rows = _category_rows(session, business_id)
    return rows


@router.post("/categories", response_model=CategoryRead, status_code=status.HTTP_201_CREATED)
def create_category(body: CategoryCreate, session: SessionDep, current_user: ManagerDep) -> ServiceCategory:
    business_id = _business_id(current_user)
    name = body.name.strip()
    existing = session.exec(
        select(ServiceCategory).where(ServiceCategory.business_id == business_id, ServiceCategory.name == name)
    ).first()
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa categoría ya existe")
    row = ServiceCategory(business_id=business_id, name=name)
    session.add(row)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa categoría ya existe") from None
    session.refresh(row)
    return row


def _category_rows(session: Session, business_id: int) -> list[ServiceCategory]:
    return list(
        session.exec(
            select(ServiceCategory).where(ServiceCategory.business_id == business_id).order_by(ServiceCategory.name)
        ).all()
    )


@router.get("/", response_model=list[ServiceRead])
def list_services(session: SessionDep, current_user: BusinessUserDep) -> list[Service]:
    statement = (
        select(Service)
        .where(Service.business_id == current_user.business_id)
        .order_by(Service.sort_order, Service.name)
    )
    return list(session.exec(statement).all())


@router.post("/", response_model=ServiceRead, status_code=status.HTTP_201_CREATED)
def create_service(body: ServiceCreate, session: SessionDep, current_user: ManagerDep) -> Service:
    service = Service(
        business_id=_business_id(current_user),
        name=body.name.strip(),
        category=body.category.strip() if body.category else None,
        description=body.description.strip() if body.description else None,
        price=body.price,
        deposit_amount=body.deposit_amount,
        duration_minutes=body.duration_minutes,
        is_active=body.is_active,
        variable_price=body.variable_price,
        image_url=body.image_url,
        questions=body.questions.strip() if body.questions else None,
        capacity=body.capacity,
        return_days=body.return_days,
        supply_cost=body.supply_cost,
        featured=bool(body.featured),
        cleanup_minutes=body.cleanup_minutes or 0,
        wait_start=body.wait_start,
        wait_minutes=body.wait_minutes or 0,
        variants=_pack_variants(body.variants),
        sort_order=_next_order(session, _business_id(current_user)),
    )
    session.add(service)
    session.commit()
    session.refresh(service)
    return service


@router.put("/order", status_code=status.HTTP_204_NO_CONTENT)
def order_services(body: OrderBody, session: SessionDep, current_user: ManagerDep) -> Response:
    """Orden en el que aparecen en la página de reservas."""
    business_id = _business_id(current_user)
    for index, service_id in enumerate(body.ids):
        service = session.get(Service, service_id)
        if service and service.business_id == business_id:
            service.sort_order = index + 1
            session.add(service)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/raise", response_model=list[ServiceRead])
def raise_prices(body: RaiseBody, session: SessionDep, current_user: ManagerDep) -> list[Service]:
    """Sube (o baja) en % el precio de todos los servicios, o los de una categoría. Redondea a pesos."""
    business_id = _business_id(current_user)
    rows = session.exec(select(Service).where(Service.business_id == business_id)).all()
    changed = []
    for service in rows:
        if body.category and service.category != body.category:
            continue
        service.price = round(service.price * (1 + body.percent / 100))
        if service.variants:
            items = json.loads(service.variants)
            for item in items:
                item["price"] = round(item["price"] * (1 + body.percent / 100))
            service.variants = json.dumps(items, ensure_ascii=False)
        session.add(service)
        changed.append(service)
    session.commit()
    for service in changed:
        session.refresh(service)
    return changed


@router.put("/{service_id}", response_model=ServiceRead)
def update_service(
    service_id: int,
    body: ServiceUpdate,
    session: SessionDep,
    current_user: ManagerDep,
) -> Service:
    service = _owned_service(session, service_id, _business_id(current_user))
    changes = body.model_dump(exclude_unset=True)
    if "name" in changes and isinstance(changes["name"], str):
        changes["name"] = changes["name"].strip()
    if "description" in changes and isinstance(changes["description"], str):
        changes["description"] = changes["description"].strip() or None
    if "category" in changes and isinstance(changes["category"], str):
        changes["category"] = changes["category"].strip() or None
    if "variants" in changes:
        changes["variants"] = _pack_variants(body.variants)
    for key in ("cleanup_minutes", "wait_minutes", "sort_order"):
        if key in changes and changes[key] is None:
            changes[key] = 0
    service.sqlmodel_update(changes)
    session.add(service)
    session.commit()
    session.refresh(service)
    return service


@router.delete("/{service_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_service(service_id: int, session: SessionDep, current_user: ManagerDep, permanent: bool = False) -> Response:
    """Sin `permanent` lo pausa (como antes). Con `permanent` lo borra, si no tiene citas; con citas, pide pausarlo."""
    service = _owned_service(session, service_id, _business_id(current_user))
    if not permanent:
        service.is_active = False
        session.add(service)
        session.commit()
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    used = session.exec(select(Appointment.id).where(Appointment.service_id == service_id)).first()
    if used is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Tiene citas registradas: páusalo en lugar de borrarlo para no perder tu historial.")
    # Primero las asignaciones a colaboradoras: si el servicio se borra antes, falla la llave foránea.
    session.exec(delete(StaffService).where(StaffService.service_id == service_id))  # type: ignore[call-overload]
    session.flush()
    session.delete(service)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{service_id}/duplicate", response_model=ServiceRead, status_code=status.HTTP_201_CREATED)
def duplicate_service(service_id: int, session: SessionDep, current_user: ManagerDep) -> Service:
    """Copia con "(copia)" y pausada, para ajustarla antes de que la vean. Copia también quién la hace."""
    business_id = _business_id(current_user)
    original = _owned_service(session, service_id, business_id)
    data = original.model_dump(exclude={"id"})
    copy = Service(**{**data, "name": f"{original.name} (copia)"[:255], "is_active": False, "featured": False, "sort_order": original.sort_order})
    session.add(copy)
    session.flush()
    for link in session.exec(select(StaffService).where(StaffService.service_id == service_id)).all():
        session.add(StaffService(staff_id=link.staff_id, service_id=copy.id, business_id=business_id))
    session.commit()
    session.refresh(copy)
    return copy


@router.put("/categories/{category_id}", response_model=CategoryRead)
def rename_category(category_id: int, body: CategoryRename, session: SessionDep, current_user: ManagerDep) -> ServiceCategory:
    business_id = _business_id(current_user)
    row = session.get(ServiceCategory, category_id)
    if row is None or row.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Categoría no encontrada")
    name = body.name.strip()
    if name != row.name and session.exec(select(ServiceCategory).where(ServiceCategory.business_id == business_id, ServiceCategory.name == name)).first():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa categoría ya existe")
    for service in session.exec(select(Service).where(Service.business_id == business_id, Service.category == row.name)).all():
        service.category = name
        session.add(service)
    row.name = name
    session.add(row)
    session.commit()
    session.refresh(row)
    return row


@router.delete("/categories/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_category(category_id: int, session: SessionDep, current_user: ManagerDep) -> Response:
    """Borra la categoría; sus servicios quedan sin categoría (no se borran)."""
    business_id = _business_id(current_user)
    row = session.get(ServiceCategory, category_id)
    if row is None or row.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Categoría no encontrada")
    for service in session.exec(select(Service).where(Service.business_id == business_id, Service.category == row.name)).all():
        service.category = None
        session.add(service)
    session.delete(row)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
