from datetime import datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlmodel import Session, select

from app.core.alerts import queue_alert
from app.core.clock import local_now
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.notice import Notice
from app.routers.auth import BusinessUserDep

router = APIRouter(prefix="/notices", tags=["notices"])
SessionDep = Annotated[Session, Depends(get_session)]


class NoticeRead(BaseModel):
    id: int
    message: str
    created_at: datetime


_MONTHS = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")


def visit_when(moment: datetime) -> str:
    return f"{day_of(moment)} a las {moment.strftime('%H:%M')}"


def day_of(moment: datetime) -> str:
    return f"el {moment.day} {_MONTHS[moment.month - 1]}"


def add_notice(session: Session, business_id: int, message: str, kind: str | None = None) -> None:
    """Aviso en Inicio; con `kind` también puede llegar por correo (ver app/core/alerts.py)."""
    session.add(Notice(business_id=business_id, message=message[:255]))
    if kind:
        queue_alert(session, business_id, kind, message)


@router.get("", response_model=list[NoticeRead])
def list_notices(session: SessionDep, current_user: BusinessUserDep) -> list[NoticeRead]:
    if current_user.business_id is None:
        return []
    # Solo lectura: avisar de anticipos vencidos lo hace `sweep_deposits` en segundo plano (ver app/main.py).
    rows = session.exec(
        select(Notice)
        .where(Notice.business_id == current_user.business_id)
        .order_by(Notice.created_at.desc())
        .limit(200)
    ).all()
    return [NoticeRead(id=row.id, message=row.message, created_at=row.created_at) for row in rows if row.id is not None]


def warn_deposits(session: Session, business_id: int) -> None:
    """Avisa a la dueña de los anticipos que siguen sin pagarse pasado el tiempo (una sola vez por cita)."""
    business = session.get(Business, business_id)
    hours = business.deposit_hold_hours if business and business.deposit_hold_hours else 3
    limit = local_now(business) - timedelta(hours=hours)
    waiting = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.awaiting_deposit,
            Appointment.created_at <= limit,
        )
    ).all()
    if not waiting:
        return
    known = {
        row.message
        for row in session.exec(select(Notice).where(Notice.business_id == business_id)).all()
    }
    added = False
    for item in waiting:
        key = f"anticipo #{item.id}"
        if any(key in text for text in known):
            continue
        add_notice(session, business_id, f"Se acabó el tiempo del anticipo de {item.client_name}. Sigue sin pagarse. {key}", "deposit_expired")
        added = True
    if added:
        session.commit()
