from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.db.database import get_session
from datetime import date

from pydantic import BaseModel, Field

from app.models.schedule import Schedule
from app.models.special_hours import SpecialHours
from app.models.staff import Staff
from app.models.user import User
from app.routers.auth import BusinessUserDep, ManagerDep
from app.schemas.schedule import ScheduleResponse, StaffScheduleUpdate

router = APIRouter(prefix="/schedules", tags=["schedules"])

SessionDep = Annotated[Session, Depends(get_session)]


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return user.business_id


def _owned_staff(session: Session, staff_id: int, business_id: int) -> Staff:
    member = session.get(Staff, staff_id)
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integrante no encontrado")
    return member


def _rows_for_staff(session: Session, business_id: int, staff_id: int) -> list[Schedule]:
    statement = (
        select(Schedule)
        .where(Schedule.business_id == business_id, Schedule.staff_id == staff_id)
        .order_by(Schedule.day_of_week)
    )
    return list(session.exec(statement).all())


@router.get("/staff/{staff_id}", response_model=list[ScheduleResponse])
def read_staff_schedule(staff_id: int, session: SessionDep, current_user: BusinessUserDep) -> list[Schedule]:
    business_id = _business_id(current_user)
    _owned_staff(session, staff_id, business_id)
    return _rows_for_staff(session, business_id, staff_id)


@router.put("/staff/{staff_id}", response_model=list[ScheduleResponse])
def replace_staff_schedule(
    staff_id: int,
    body: StaffScheduleUpdate,
    session: SessionDep,
    current_user: ManagerDep,
) -> list[Schedule]:
    business_id = _business_id(current_user)
    member = _owned_staff(session, staff_id, business_id)
    if "slot_times" in body.model_fields_set:
        member.slot_times = (body.slot_times or "").strip() or None
        session.add(member)

    existing = {row.day_of_week: row for row in _rows_for_staff(session, business_id, staff_id)}
    incoming_days = {item.day_of_week for item in body.schedules}

    for day, row in existing.items():
        if day not in incoming_days:
            session.delete(row)

    for item in body.schedules:
        row = existing.get(item.day_of_week)
        if row is None:
            row = Schedule(business_id=business_id, staff_id=staff_id, day_of_week=item.day_of_week)
            session.add(row)
        row.start_time = item.start_time
        row.end_time = item.end_time
        row.is_active = item.is_active
        row.slot_times = item.slot_times
        row.break_start = item.break_start
        row.break_end = item.break_end

    session.commit()
    return _rows_for_staff(session, business_id, staff_id)


class SpecialBody(BaseModel):
    staff_id: int | None = None
    date_from: date
    date_to: date
    start_time: str = Field(default="09:00", pattern=r"^\d{2}:\d{2}$")
    end_time: str = Field(default="18:00", pattern=r"^\d{2}:\d{2}$")
    closed: bool = False
    note: str | None = Field(default=None, max_length=80)


@router.get("/special", response_model=list[SpecialHours])
def list_special(session: SessionDep, current_user: BusinessUserDep) -> list[SpecialHours]:
    """Días o periodos con horario especial que aún no terminan."""
    from app.core.clock import local_today
    from app.models.business import Business

    business_id = _business_id(current_user)
    today = local_today(session.get(Business, business_id))
    return list(
        session.exec(
            select(SpecialHours).where(SpecialHours.business_id == business_id, SpecialHours.date_to >= today).order_by(SpecialHours.date_from)
        ).all()
    )


@router.post("/special", response_model=SpecialHours, status_code=status.HTTP_201_CREATED)
def add_special(body: SpecialBody, session: SessionDep, current_user: ManagerDep) -> SpecialHours:
    business_id = _business_id(current_user)
    if body.staff_id is not None:
        _owned_staff(session, body.staff_id, business_id)
    if body.date_to < body.date_from:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="La fecha final no puede ser antes de la inicial")
    if not body.closed and body.end_time <= body.start_time:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="La hora de cierre debe ser después de la de apertura")
    row = SpecialHours(business_id=business_id, **body.model_dump())
    session.add(row)
    session.commit()
    session.refresh(row)
    return row


@router.delete("/special/{special_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_special(special_id: int, session: SessionDep, current_user: ManagerDep) -> None:
    row = session.get(SpecialHours, special_id)
    if row is None or row.business_id != _business_id(current_user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No encontrado")
    session.delete(row)
    session.commit()
