from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field
from sqlmodel import Session, select

from app.db.database import get_session
from app.models.package import ClientPackage
from app.models.user import User
from app.routers.auth import BusinessUserDep, ManagerDep

router = APIRouter(prefix="/packages", tags=["packages"])
SessionDep = Annotated[Session, Depends(get_session)]


class PackageBody(BaseModel):
    client_name: str = Field(min_length=1, max_length=255)
    client_phone: str = Field(min_length=1, max_length=32)
    visits: int = Field(ge=1, le=100)


class PackageRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    client_name: str
    client_phone: str
    label: str
    total: int
    remaining: int


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso")
    return user.business_id


@router.get("", response_model=list[PackageRead])
def list_packages(session: SessionDep, current_user: BusinessUserDep) -> list[ClientPackage]:
    business_id = _business_id(current_user)
    return list(session.exec(select(ClientPackage).where(ClientPackage.business_id == business_id).order_by(ClientPackage.id.desc())).all())


@router.post("", response_model=PackageRead, status_code=status.HTTP_201_CREATED)
def create_package(body: PackageBody, session: SessionDep, current_user: BusinessUserDep) -> ClientPackage:
    row = ClientPackage(
        business_id=_business_id(current_user),
        client_name=body.client_name.strip(),
        client_phone=body.client_phone.strip(),
        label=f"{body.visits} visitas",
        total=body.visits,
        remaining=body.visits,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return row


class PackageUpdate(BaseModel):
    remaining: int = Field(ge=0, le=100)


def _owned(session: Session, user: User, package_id: int) -> ClientPackage:
    row = session.get(ClientPackage, package_id)
    if row is None or row.business_id != _business_id(user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Paquete no encontrado")
    return row


@router.patch("/{package_id}", response_model=PackageRead)
def update_package(package_id: int, body: PackageUpdate, session: SessionDep, current_user: BusinessUserDep) -> ClientPackage:
    """Corregir cuántas visitas le quedan (no puede pasar del total)."""
    row = _owned(session, current_user, package_id)
    row.remaining = min(body.remaining, row.total)
    session.add(row)
    session.commit()
    session.refresh(row)
    return row


@router.delete("/{package_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_package(package_id: int, session: SessionDep, current_user: ManagerDep) -> None:
    session.delete(_owned(session, current_user, package_id))
    session.commit()
