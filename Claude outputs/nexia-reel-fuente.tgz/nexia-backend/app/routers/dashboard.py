from collections import defaultdict
from datetime import date, datetime, time, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel import Session, select

from app.core.clock import local_now, local_today
from app.models.business import Business
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.service import Service
from app.models.staff import Staff
from app.models.user import User, UserRole
from app.routers.auth import BusinessUserDep
from app.routers.businesses import to_appointment_read
from app.schemas.dashboard import (
    DashboardStatsResponse,
    DashboardSummary,
    StaffOccupancyItem,
    TopServiceItem,
    WeekTrendPoint,
)

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

SessionDep = Annotated[Session, Depends(get_session)]


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return user.business_id


def _month_bounds(day: date) -> tuple[datetime, datetime]:
    start = datetime.combine(date(day.year, day.month, 1), time.min)
    if day.month == 12:
        next_month = date(day.year + 1, 1, 1)
    else:
        next_month = date(day.year, day.month + 1, 1)
    return start, datetime.combine(next_month, time.min)


def _staff_scope(session: Session, user: User, business_id: int) -> int | None:
    """None means every staff member. An int limits the summary to that collaborator."""
    if user.role != UserRole.staff:
        return None
    member = session.exec(
        select(Staff).where(Staff.user_id == user.id, Staff.business_id == business_id)
    ).first()
    return member.id if member is not None else 0


@router.get("/summary", response_model=DashboardSummary, tags=["Dashboard"])
def read_dashboard_summary(session: SessionDep, current_user: BusinessUserDep) -> DashboardSummary:
    business_id = _business_id(current_user)
    staff_id = _staff_scope(session, current_user, business_id)
    business = session.get(Business, business_id)
    today = local_today(business)
    day_start = datetime.combine(today, time.min)
    day_end = day_start + timedelta(days=1)
    week_start = day_start - timedelta(days=6)
    month_start = datetime.combine(date(today.year, today.month, 1), time.min)
    now = local_now(business)

    statement = (
        select(Appointment, Service, Staff)
        .join(Service, Service.id == Appointment.service_id)
        .join(Staff, Staff.id == Appointment.staff_id)
        .where(
            Appointment.business_id == business_id,
            Service.business_id == business_id,
            Staff.business_id == business_id,
            Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
            Appointment.starts_at >= min(week_start, month_start),
            Appointment.starts_at < day_end,
        )
        .order_by(Appointment.starts_at)
    )
    if staff_id is not None:
        statement = statement.where(Appointment.staff_id == staff_id)

    rows = session.exec(statement).all()
    buckets = {
        (today - timedelta(days=offset)).isoformat(): [0, 0.0]
        for offset in range(6, -1, -1)
    }
    month_buckets = {
        date(today.year, today.month, day).isoformat(): [0, 0.0]
        for day in range(1, today.day + 1)
    }
    today_count = 0
    today_revenue = 0.0
    upcoming_rows: list[tuple[Appointment, Service, Staff]] = []

    for appointment, service, member in rows:
        amount = 0.0 if appointment.status == AppointmentStatus.awaiting_deposit else float(appointment.quoted_price if appointment.quoted_price is not None else service.price)
        day_key = appointment.starts_at.date().isoformat()
        # La serie cuenta citas agendadas, pero el ingreso solo de las cobradas (completadas),
        # para que la cifra grande cuadre con "Resultado → Ingresos".
        earned = amount if appointment.status == AppointmentStatus.completed else 0.0
        if day_key in buckets:
            buckets[day_key][0] += 1
            buckets[day_key][1] += earned
        if day_key in month_buckets:
            month_buckets[day_key][0] += 1
            month_buckets[day_key][1] += earned
        if day_start <= appointment.starts_at < day_end:
            today_count += 1
            today_revenue += amount
            if appointment.starts_at >= now and len(upcoming_rows) < 5:
                upcoming_rows.append((appointment, service, member))

    return DashboardSummary(
        today_appointments_count=today_count,
        today_revenue=round(today_revenue, 2),
        week_appointments_count=sum(int(count) for count, _revenue in buckets.values()),
        upcoming_today=[to_appointment_read(appointment, service, member) for appointment, service, member in upcoming_rows],
        week_trend=[
            WeekTrendPoint(date=day, count=int(count), revenue=round(revenue, 2))
            for day, (count, revenue) in buckets.items()
        ],
        month_trend=[
            WeekTrendPoint(date=day, count=int(count), revenue=round(revenue, 2))
            for day, (count, revenue) in month_buckets.items()
        ],
    )


@router.get("/stats", response_model=DashboardStatsResponse)
def read_dashboard_stats(
    session: SessionDep,
    current_user: BusinessUserDep,
    day: Annotated[date | None, Query(alias="date")] = None,
) -> DashboardStatsResponse:
    business_id = _business_id(current_user)
    selected = day or local_today(session.get(Business, business_id))
    day_start = datetime.combine(selected, time.min)
    day_end = day_start + timedelta(days=1)
    month_start, month_end = _month_bounds(selected)

    rows = session.exec(
        select(Appointment.starts_at, Service.name, Service.price, Staff.full_name)
        .join(Service, Service.id == Appointment.service_id)
        .join(Staff, Staff.id == Appointment.staff_id)
        .where(
            Appointment.business_id == business_id,
            Service.business_id == business_id,
            Staff.business_id == business_id,
            Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
            Appointment.starts_at >= month_start,
            Appointment.starts_at < month_end,
        )
    ).all()

    service_counts: dict[str, list[float]] = defaultdict(lambda: [0, 0.0])
    staff_counts: dict[str, int] = defaultdict(int)
    total_today = 0
    revenue_today = 0.0
    revenue_month = 0.0

    for starts_at, service_name, price, staff_name in rows:
        amount = float(price)
        revenue_month += amount
        bucket = service_counts[service_name]
        bucket[0] += 1
        bucket[1] += amount
        staff_counts[staff_name] += 1
        if day_start <= starts_at < day_end:
            total_today += 1
            revenue_today += amount

    top_services = [
        TopServiceItem(
            service_name=name,
            total_appointments=int(count),
            total_revenue=round(revenue, 2),
        )
        for name, (count, revenue) in sorted(
            service_counts.items(),
            key=lambda item: (-item[1][0], -item[1][1], item[0]),
        )[:5]
    ]
    staff_occupancy = [
        StaffOccupancyItem(staff_name=name, total_appointments=count)
        for name, count in sorted(staff_counts.items(), key=lambda item: (-item[1], item[0]))
    ]

    return DashboardStatsResponse(
        total_today=total_today,
        total_month=len(rows),
        revenue_today=round(revenue_today, 2),
        revenue_month=round(revenue_month, 2),
        top_services=top_services,
        staff_occupancy=staff_occupancy,
    )
