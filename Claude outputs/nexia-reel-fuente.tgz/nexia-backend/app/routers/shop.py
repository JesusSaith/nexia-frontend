import calendar
import math
from datetime import date, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, ConfigDict, Field
from sqlmodel import Session, col, select

from app.core.clock import local_now, local_today
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.core.payment_methods import PAYMENT_METHODS
from app.models.cash import CashCount, CashMove
from app.models.client import Client, ClientContact, phone_key
from app.models.product import CommissionPay, Expense, ExpensePayment, Product, Sale, StockMove
from app.models.schedule import Schedule
from app.models.service import Service
from app.models.staff import Staff
from app.models.user import User
from app.routers.auth import BusinessUserDep, ManagerDep

router = APIRouter(prefix="/shop", tags=["shop"])
SessionDep = Annotated[Session, Depends(get_session)]


class ProductBody(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    price: float = Field(ge=0)
    stock: int = Field(ge=0, le=100000)
    cost: float = Field(default=0, ge=0)
    iva: bool = False


class ProductRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    price: float
    cost: float = 0
    stock: int


class SellBody(BaseModel):
    qty: int = Field(ge=1, le=1000)
    price: float | None = Field(default=None, ge=0)
    # Cómo se cobró; sin dato se cuenta como efectivo (así era antes).
    method: str | None = Field(default=None, pattern=r"^(efectivo|transferencia|tarjeta)$")


class InBody(BaseModel):
    qty: int = Field(ge=1, le=1000)
    cost: float = Field(default=0, ge=0)
    iva: bool = False


class CommissionRow(BaseModel):
    staff_id: int
    staff_name: str
    percent: int
    income: float
    commission: float
    visits: int = 0
    ticket: float = 0
    free_hours: float = 0
    # Horas de trabajo del periodo según su horario; ocupación = (abiertas − libres) / abiertas.
    open_hours: float = 0
    # Ocupación hasta hoy (0–100).
    occupancy: int = 0
    paid: float = 0
    # Propinas de sus citas completadas; ya van sumadas en `commission` (lo que se le debe).
    tips: float = 0
    # Faltas y cancelaciones de sus citas del periodo, y cuántas de sus clientas ya habían venido antes.
    no_shows: int = 0
    cancels: int = 0
    clients: int = 0
    returning: int = 0
    # Meta del mes (si la tiene) y si ya alcanzó su comisión escalonada.
    goal: float | None = None
    tier_reached: bool = False


class ExpenseBody(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    amount: float = Field(ge=0)
    kind: str = Field(pattern="^(fixed|variable)$")
    cadence: str | None = Field(default=None, pattern="^(month|week|day)$")
    # Día de pago: 1 a 31 (mensual) o 0 a 6, lunes a domingo (semanal). Sin dato, el día en que se registra.
    pay_day: int | None = Field(default=None, ge=0, le=31)
    category: str | None = Field(default=None, pattern="^(renta|nomina|insumos|servicios|publicidad|otros)$")


class ExpenseRead(BaseModel):
    id: int
    name: str
    amount: float
    base: float = 0
    kind: str
    cadence: str | None = None
    category: str | None = None
    # Día en que se registró (AAAA-MM-DD).
    day: str | None = None
    # Gasto fijo: día de pago, cuántas veces cae en el periodo del reporte (amount = base × veces) y el siguiente pago.
    pay_day: int | None = None
    times: int = 0
    next_due: str | None = None
    # Pagos de este gasto que se marcaron con "Ya pagué" y caen en el periodo: [{due, paid_on}].
    paid_marks: list[dict] = []


class MoveRead(BaseModel):
    id: int
    product_name: str
    kind: str
    qty: int
    amount: float = 0
    iva: float = 0


class ReportRead(BaseModel):
    service_income: float
    product_income: float
    total: float
    expense_fixed: float
    expense_variable: float
    commission_total: float
    # Propinas del periodo: se entregan a cada colaboradora, no son ingreso ni gasto del negocio.
    tips_total: float = 0
    product_cost: float = 0
    profit: float
    completed_count: int = 0
    average_ticket: float = 0
    missed_count: int = 0
    missed_amount: float = 0
    deposit_count: int = 0
    deposit_due: float = 0
    proofs_pending: int = 0
    no_shows: list[str] = []
    deposits_expired: int = 0
    top_name: str = ""
    top_count: int = 0
    top_income: float = 0
    # Citas cobradas por método (efectivo, transferencia, tarjeta, paquete, sin_registrar).
    by_method: dict[str, float] = {}
    # Qué tanto se llenó el horario de trabajo (0–100), clientas nuevas vs. que regresan,
    # los 5 servicios que más dejaron y cuántas citas hubo por día de la semana (0 = lunes) y hora.
    occupancy: int = 0
    # Lo que ya está agendado de aquí al fin del periodo (citas por venir, a su precio).
    expected_income: float = 0
    expected_count: int = 0
    # Gastos del periodo por categoría, y cuánto hay que ingresar para cubrir gastos y comisiones.
    by_category: dict[str, float] = {}
    break_even: float = 0
    break_even_visits: int = 0
    new_clients: int = 0
    returning_clients: int = 0
    top_services: list[dict] = []
    busy_hours: list[dict] = []
    # Por servicio: citas, ingreso, comisión, horas y lo que deja por hora (sin insumos).
    service_stats: list[dict] = []
    # Citas del periodo que no se cumplieron, sobre todas las que debían ocurrir.
    cancelled_count: int = 0
    no_show_count: int = 0
    # Citas cobradas que salieron con su siguiente cita ya agendada.
    rebooked: int = 0
    # Gasto promedio de una clienta en toda su historia (citas cobradas).
    client_value: float = 0
    # Cupones y premios usados en citas cobradas, y el descuento que se dio.
    discount_count: int = 0
    discount_amount: float = 0
    # Origen de las citas creadas en el periodo: página, dueña o sin dato (citas viejas).
    by_source: dict[str, int] = {}
    # Días entre que reservan y la cita (mediana), en reservas desde la página.
    lead_days: float | None = None
    # Ingresos de los últimos 12 meses, para ver la tendencia.
    months: list[dict] = []
    # Cobrado por día del periodo (para dibujar la gráfica de este periodo y la del anterior).
    daily: list[dict] = []
    # Productos con pocas piezas (5 o menos).
    low_stock: list[dict] = []
    # Gastos fijos que caen después del periodo dentro de ese mismo mes (lo que "falta pagar") y los pagos de los próximos 30 días.
    fixed_pending: float = 0
    upcoming_fixed: list[dict] = []
    # Citas del periodo que ya pasaron y siguen sin cobrar ni cerrar: el dinero que falta por cobrar (precio menos anticipo).
    uncollected_count: int = 0
    uncollected_amount: float = 0
    uncollected: list[dict] = []
    # A quién cuidar (de hoy, no del periodo): clientes que dejaron de venir y clientes que cancelan o faltan seguido.
    clients_missing: int = 0
    clients_cancelling: int = 0
    # Invitaciones a volver mandadas en el periodo: a cuántos clientes, cuántos ya regresaron o tienen cita, y lo que dejaron.
    winback_sent: int = 0
    winback_returned: int = 0
    winback_booked: int = 0
    winback_revenue: float = 0
    expenses: list[ExpenseRead]
    staff: list[CommissionRow]


class PayBody(BaseModel):
    staff_id: int
    start: str
    end: str
    amount: float = Field(ge=0)
    paid: bool


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes permiso")
    return user.business_id


@router.get("/products", response_model=list[ProductRead])
def list_products(session: SessionDep, current_user: BusinessUserDep) -> list[Product]:
    business_id = _business_id(current_user)
    return list(
        session.exec(
            select(Product).where(Product.business_id == business_id, Product.is_active == True)  # noqa: E712
        ).all()
    )


@router.post("/products", response_model=ProductRead, status_code=status.HTTP_201_CREATED)
def create_product(body: ProductBody, session: SessionDep, current_user: ManagerDep) -> Product:
    product = Product(
        business_id=_business_id(current_user),
        name=body.name.strip(),
        price=body.price,
        cost=round(body.cost / body.stock, 2) if body.stock else 0,
        stock=body.stock,
    )
    session.add(product)
    session.flush()
    if body.stock:
        session.add(
            StockMove(
                business_id=product.business_id,
                product_id=product.id or 0,
                product_name=product.name,
                kind="in",
                qty=body.stock,
                amount=body.cost,
                iva=round(body.cost * 0.16, 2) if body.iva else 0,
            )
        )
    session.commit()
    session.refresh(product)
    return product


@router.post("/products/{product_id}/sell", response_model=ProductRead)
def sell_product(
    product_id: int,
    body: SellBody,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> Product:
    business_id = _business_id(current_user)
    product = session.get(Product, product_id)
    if product is None or product.business_id != business_id or not product.is_active:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Producto no encontrado")
    if product.stock < body.qty:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="No hay suficiente existencia")
    unit = product.price if body.price is None else body.price
    product.price = unit
    product.stock -= body.qty
    session.add(product)
    sold = round(unit * body.qty, 2)
    session.add(
        Sale(
            business_id=business_id,
            product_id=product_id,
            product_name=product.name,
            qty=body.qty,
            total=sold,
            method=body.method,
        )
    )
    session.add(
        StockMove(
            business_id=business_id,
            product_id=product_id,
            product_name=product.name,
            kind="out",
            qty=body.qty,
            amount=sold,
        )
    )
    session.commit()
    session.refresh(product)
    return product


@router.get("/report", response_model=ReportRead)
def sales_report(
    session: SessionDep,
    current_user: ManagerDep,
    start: str,
    end: str,
) -> ReportRead:
    business_id = _business_id(current_user)
    start_at = datetime.fromisoformat(start)
    end_at = datetime.fromisoformat(f"{end}T23:59:59")
    visits = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.completed,
            Appointment.starts_at >= start_at,
            Appointment.starts_at <= end_at,
        )
    ).all()
    catalog = list(session.exec(select(Service).where(Service.business_id == business_id)).all())
    prices = {item.id: item.price for item in catalog if item.id is not None}
    service_names = {item.id: item.name for item in catalog if item.id is not None}
    people = {
        item.id: item
        for item in session.exec(select(Staff).where(Staff.business_id == business_id)).all()
        if item.id is not None
    }
    # Sin comisiones (se elige al registrarse o en Configuración), nadie cobra porcentaje aunque lo tenga guardado.
    business = session.get(Business, business_id)
    pays = business is None or business.uses_commissions is not False
    earned: dict[int, float] = {}
    visit_count: dict[int, int] = {}
    by_service: dict[int, tuple[int, float]] = {}
    service_income = 0.0
    by_method: dict[str, float] = {}
    tips_of: dict[int, float] = {}
    for visit in visits:
        amount = visit.quoted_price if visit.quoted_price is not None else prices.get(visit.service_id, 0)
        service_income += amount
        method = visit.payment_method or "sin_registrar"
        by_method[method] = round(by_method.get(method, 0) + amount, 2)
        earned[visit.staff_id] = earned.get(visit.staff_id, 0) + amount
        if visit.tip:
            tips_of[visit.staff_id] = tips_of.get(visit.staff_id, 0) + visit.tip
        visit_count[visit.staff_id] = visit_count.get(visit.staff_id, 0) + 1
        count, money = by_service.get(visit.service_id, (0, 0.0))
        by_service[visit.service_id] = (count + 1, money + amount)
    top_id = max(by_service, key=lambda key: (by_service[key][0], by_service[key][1]), default=None)
    top_count, top_income = by_service.get(top_id, (0, 0.0)) if top_id is not None else (0, 0.0)
    top_name = service_names.get(top_id, "") if top_id is not None else ""
    sales = session.exec(
        select(Sale).where(Sale.business_id == business_id, Sale.created_at >= start_at, Sale.created_at <= end_at)
    ).all()
    product_income = round(sum(item.total for item in sales), 2)
    service_income = round(service_income, 2)
    bills = []
    pending_fixed = 0.0
    upcoming: list[dict] = []
    today = local_today(business) if business else start_at.date()
    month_end = date(end_at.year, end_at.month, calendar.monthrange(end_at.year, end_at.month)[1])
    marks: dict[int, dict[str, str]] = {}
    for mark in session.exec(select(ExpensePayment).where(ExpensePayment.business_id == business_id)).all():
        marks.setdefault(mark.expense_id, {})[mark.due] = mark.paid_on
    for item in session.exec(select(Expense).where(Expense.business_id == business_id)).all():
        if item.kind == "fixed":
            if item.created_at > end_at:
                continue
            cadence = item.cadence or "month"
            paid = marks.get(item.id or 0, {})
            # Un pago cuenta el día que se marcó como pagado; sin marca, el día que tocaba. Se busca en una ventana
            # más ancha porque un pago de otro mes puede haberse hecho dentro de este periodo.
            counted = []
            for due in _pay_dates(item, start_at.date() - timedelta(days=62), end_at.date() + timedelta(days=62)):
                effective = date.fromisoformat(paid[due.isoformat()]) if due.isoformat() in paid else due
                if start_at.date() <= effective <= end_at.date():
                    counted.append(due)
            times = len(counted)
            if end_at.date() >= today:
                pending_fixed += item.amount * sum(
                    1 for due in _pay_dates(item, end_at.date() + timedelta(days=1), month_end) if due.isoformat() not in paid
                )
            following = [due for due in _pay_dates(item, today + timedelta(days=1), today + timedelta(days=30)) if due.isoformat() not in paid]
            if following:
                upcoming.append({"id": item.id, "name": item.name, "amount": item.amount, "date": following[0].isoformat()})
            amount = round(item.amount * times, 2)
            bills.append(
                ExpenseRead(
                    id=item.id or 0, name=item.name, amount=amount, base=item.amount, kind=item.kind, cadence=cadence,
                    category=item.category, day=item.created_at.date().isoformat(), pay_day=_pay_day(item), times=times,
                    next_due=(following[0].isoformat() if following else None),
                    paid_marks=[{"due": due.isoformat(), "paid_on": paid[due.isoformat()]} for due in counted if due.isoformat() in paid],
                )
            )
        elif start_at <= item.created_at <= end_at:
            bills.append(
                ExpenseRead(id=item.id or 0, name=item.name, amount=item.amount, base=item.amount, kind=item.kind, cadence=item.cadence, category=item.category, day=item.created_at.date().isoformat())
            )
    upcoming.sort(key=lambda row: row["date"])
    expense_fixed = round(sum(item.amount for item in bills if item.kind == "fixed"), 2)
    expense_variable = round(sum(item.amount for item in bills if item.kind != "fixed"), 2)
    paid_rows = session.exec(
        select(CommissionPay).where(
            CommissionPay.business_id == business_id,
            CommissionPay.period_start <= end,
            CommissionPay.period_end >= start,
        )
    ).all()
    # Antes solo contaba un pago con el periodo exacto: al recorrerse la semana "reaparecía" la deuda.
    # Un pago de un periodo más largo se reparte por días entre los periodos que cubre: así, un pago parcial del mes
    # no aparece completo en cada una de sus semanas.
    paid_of: dict[int, float] = {}
    window_start, window_end = date.fromisoformat(start), date.fromisoformat(end)
    for item in paid_rows:
        pay_start, pay_end = date.fromisoformat(item.period_start), date.fromisoformat(item.period_end)
        overlap = (min(pay_end, window_end) - max(pay_start, window_start)).days + 1
        if overlap <= 0:
            continue
        share = overlap / ((pay_end - pay_start).days + 1)
        paid_of[item.staff_id] = paid_of.get(item.staff_id, 0) + item.amount * min(share, 1)
    free_of, open_of = _free_hours(session, business_id, start_at, end_at)
    rows = []
    for staff_id, member in people.items():
        if not member.is_active and staff_id not in earned:
            continue
        income = earned.get(staff_id, 0)
        visits_n = visit_count.get(staff_id, 0)
        percent = (member.commission_percent or 0) if pays else 0
        reached = pays and bool(member.tier_amount and member.tier_percent and income >= member.tier_amount)
        if reached:
            percent = member.tier_percent or percent
        tips = round(tips_of.get(staff_id, 0), 2)
        # Lo que se le debe: su comisión más las propinas que le dejaron.
        owed = round(income * percent / 100 + tips, 2)
        rows.append(
            CommissionRow(
                staff_id=staff_id,
                staff_name=member.full_name,
                percent=percent,
                income=round(income, 2),
                commission=owed,
                visits=visits_n,
                ticket=round(income / visits_n, 2) if visits_n else 0,
                free_hours=free_of.get(staff_id, 0),
                open_hours=open_of.get(staff_id, 0),
                paid=round(min(owed, paid_of.get(staff_id, 0)), 2),
                tips=tips,
                goal=member.goal,
                tier_reached=reached,
            )
        )
    rows.sort(key=lambda item: item.income, reverse=True)
    tips_total = round(sum(item.tips for item in rows), 2)
    # Las propinas no salen de la ganancia: la clienta las paga aparte de lo cobrado.
    commission_total = round(sum(item.commission for item in rows) - tips_total, 2)
    purchases = session.exec(
        select(StockMove).where(
            StockMove.business_id == business_id,
            StockMove.kind == "in",
            StockMove.created_at >= start_at,
            StockMove.created_at <= end_at,
        )
    ).all()
    product_cost = round(sum(item.amount + item.iva for item in purchases), 2)
    total = round(service_income + product_income, 2)
    missed_count = 0
    missed_amount = 0.0
    deposit_count = 0
    deposit_due = 0.0
    proofs_pending = 0
    no_shows: list[str] = []
    pending = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.starts_at >= start_at,
            Appointment.starts_at <= end_at,
            Appointment.status.in_([AppointmentStatus.cancelled, AppointmentStatus.no_show, AppointmentStatus.awaiting_deposit]),
        )
    ).all()
    for item in pending:
        price = item.quoted_price if item.quoted_price is not None else prices.get(item.service_id, 0)
        if item.status == AppointmentStatus.awaiting_deposit:
            deposit_count += 1
            deposit_due += item.deposit_amount or 0
            if item.payment_proof:
                proofs_pending += 1
        else:
            missed_count += 1
            missed_amount += price
            if item.status == AppointmentStatus.no_show:
                no_shows.append(item.client_name)
    completed_count = len(visits)
    now_local = local_now(business)
    stuck = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.scheduled,
            Appointment.starts_at >= start_at,
            Appointment.starts_at <= end_at,
            Appointment.ends_at <= now_local,
        ).order_by(col(Appointment.starts_at).desc())
    ).all()
    uncollected_rows = []
    uncollected_amount = 0.0
    for item in stuck:
        price = item.quoted_price if item.quoted_price is not None else prices.get(item.service_id, 0)
        left = max(price - (item.deposit_amount or 0), 0)
        uncollected_amount += left
        uncollected_rows.append({"id": item.id, "name": item.client_name, "date": item.starts_at.isoformat(), "amount": round(left, 2)})
    # Ocupación solo hasta hoy: los días que faltan del periodo aún no se llenan y la bajarían.
    until = min(end_at, local_now(session.get(Business, business_id)).replace(hour=23, minute=59, second=59))
    free_now, open_now = _free_hours(session, business_id, start_at, until) if until >= start_at else ({}, {})
    open_total = sum(open_now.values())
    occupancy = round((open_total - sum(free_now.values())) / open_total * 100) if open_total else 0
    for item in rows:
        hours = open_now.get(item.staff_id, 0)
        item.occupancy = max(0, min(100, round((hours - free_now.get(item.staff_id, 0)) / hours * 100))) if hours else 0
    new_clients, returning_clients = _new_and_returning(session, business_id, visits, start_at)
    watch = _clients_to_watch(session, business_id, now_local)
    top_services = [
        {"name": service_names.get(service_id, "Servicio"), "count": count, "income": round(money, 2)}
        for service_id, (count, money) in sorted(by_service.items(), key=lambda pair: pair[1][1], reverse=True)[:5]
    ]
    heat: dict[tuple[int, int], int] = {}
    for visit in visits:
        key = (visit.starts_at.weekday(), visit.starts_at.hour)
        heat[key] = heat.get(key, 0) + 1
    expected_income, expected_count = _expected(session, business_id, prices, end_at)
    by_category: dict[str, float] = {}
    for bill in bills:
        key = bill.category or "otros"
        by_category[key] = round(by_category.get(key, 0) + bill.amount, 2)
    # Punto de equilibrio: lo que hay que ingresar para que la utilidad sea 0. Debe restar lo mismo que `profit`:
    # gastos, compras de producto y lo que se lleva el equipo de cada peso que entra.
    commission_share = min(commission_total / total, 0.9) if total > 0 else 0
    break_even = round((expense_fixed + expense_variable + product_cost) / (1 - commission_share), 2)
    # Ticket para traducirlo a citas: el real del periodo o, sin cobros aún, el precio promedio del catálogo.
    ticket = total / len(visits) if visits else (sum(prices.values()) / len(prices) if prices else 0)
    extra = _insights(session, business_id, visits, pending, prices, people, catalog, start_at, end_at, rows, pays)
    return ReportRead(
        **extra,
        expected_income=expected_income,
        expected_count=expected_count,
        by_category=by_category,
        break_even=break_even,
        break_even_visits=math.ceil(break_even / ticket) if ticket > 0 and break_even > 0 else 0,
        occupancy=max(0, min(100, occupancy)),
        new_clients=new_clients,
        returning_clients=returning_clients,
        top_services=top_services,
        busy_hours=[{"day": day, "hour": hour, "count": count} for (day, hour), count in sorted(heat.items())],
        by_method=by_method,
        service_income=service_income,
        product_income=product_income,
        total=total,
        expense_fixed=expense_fixed,
        expense_variable=expense_variable,
        commission_total=commission_total,
        tips_total=tips_total,
        product_cost=product_cost,
        profit=round(total - expense_fixed - expense_variable - commission_total - product_cost, 2),
        completed_count=completed_count,
        average_ticket=round(service_income / completed_count, 2) if completed_count else 0,
        missed_count=missed_count,
        missed_amount=round(missed_amount, 2),
        deposit_count=deposit_count,
        deposit_due=round(deposit_due, 2),
        proofs_pending=proofs_pending,
        no_shows=no_shows,
        deposits_expired=_expired_deposits(session, business_id),
        top_name=top_name,
        top_count=top_count,
        top_income=round(top_income, 2),
        fixed_pending=round(pending_fixed, 2),
        upcoming_fixed=upcoming[:6],
        **_winback(session, business_id, start_at, end_at, prices, now_local),
        clients_missing=watch[0],
        clients_cancelling=watch[1],
        uncollected_count=len(stuck),
        uncollected_amount=round(uncollected_amount, 2),
        uncollected=uncollected_rows[:5],
        expenses=bills,
        staff=rows,
    )


def _pay_day(item: Expense) -> int:
    """Día de pago de un gasto fijo; sin dato, el día en que se registró."""
    if item.pay_day is not None:
        return item.pay_day
    return item.created_at.weekday() if item.cadence == "week" else item.created_at.day


def _pay_dates(item: Expense, start: date, end: date) -> list[date]:
    """Fechas en que se paga un gasto fijo dentro de [start, end]: el dinero sale completo, una vez por pago.

    Mensual: el día `pay_day` de cada mes (un 31 cae el último día de los meses cortos); semanal: ese día de la semana;
    por día: todos los días. Cuenta desde el inicio del mes (o semana) en que se registró, para que el pago de ese
    mes entre aunque la fecha ya hubiera pasado.
    """
    created = item.created_at.date()
    cadence = item.cadence or "month"
    if cadence == "day":
        first = max(start, created)
    elif cadence == "week":
        first = max(start, created - timedelta(days=created.weekday()))
    else:
        first = max(start, created.replace(day=1))
    dates: list[date] = []
    if first > end:
        return dates
    if cadence == "month":
        year, month = first.year, first.month
        while (year, month) <= (end.year, end.month):
            due = date(year, month, min(max(_pay_day(item), 1), calendar.monthrange(year, month)[1]))
            if first <= due <= end:
                dates.append(due)
            year, month = (year + 1, 1) if month == 12 else (year, month + 1)
        return dates
    day = first
    while day <= end:
        if cadence == "day" or day.weekday() == _pay_day(item):
            dates.append(day)
        day += timedelta(days=1)
    return dates


def _insights(session, business_id, visits, pending, prices, people, catalog, start_at, end_at, rows, pays=True) -> dict:
    """Métricas para decidir: por servicio, faltas, re-reserva, valor de clienta, descuentos, origen y tendencia."""
    durations = {item.id: item.duration_minutes for item in catalog}
    supplies = {item.id: item.supply_cost or 0 for item in catalog}
    names = {item.id: item.name for item in catalog}
    percent_of = {staff_id: (member.commission_percent or 0) if pays else 0 for staff_id, member in people.items()}
    per_service: dict[int, dict] = {}
    discount_count = 0
    discount_amount = 0.0
    for visit in visits:
        amount = visit.quoted_price if visit.quoted_price is not None else prices.get(visit.service_id, 0)
        row = per_service.setdefault(visit.service_id, {"count": 0, "income": 0.0, "commission": 0.0, "minutes": 0, "supplies": 0.0})
        row["supplies"] += supplies.get(visit.service_id, 0)
        row["count"] += 1
        row["income"] += amount
        row["commission"] += amount * percent_of.get(visit.staff_id, 0) / 100
        row["minutes"] += durations.get(visit.service_id, 60) or 60
        if visit.discount_percent:
            discount_count += 1
            base = prices.get(visit.service_id, 0)
            discount_amount += base * visit.discount_percent / 100
    service_stats = []
    for service_id, row in per_service.items():
        hours = row["minutes"] / 60
        profit = row["income"] - row["commission"] - row["supplies"]
        service_stats.append({
            "name": names.get(service_id, "Servicio"), "count": row["count"], "income": round(row["income"], 2),
            "commission": round(row["commission"], 2), "supplies": round(row["supplies"], 2), "profit": round(profit, 2),
            "hours": round(hours, 1), "per_hour": round(profit / hours, 2) if hours else 0,
        })
    service_stats.sort(key=lambda item: item["per_hour"], reverse=True)

    cancelled = [item for item in pending if item.status == AppointmentStatus.cancelled]
    missed = [item for item in pending if item.status == AppointmentStatus.no_show]
    by_staff_rows = {row.staff_id: row for row in rows}
    for item in cancelled:
        if item.staff_id in by_staff_rows:
            by_staff_rows[item.staff_id].cancels += 1
    for item in missed:
        if item.staff_id in by_staff_rows:
            by_staff_rows[item.staff_id].no_shows += 1

    # Historia completa por teléfono (solo columnas): re-reserva, clientas que regresan y valor de una clienta.
    history = session.exec(
        select(Appointment.client_phone, Appointment.starts_at, Appointment.status, Appointment.quoted_price, Appointment.service_id).where(
            Appointment.business_id == business_id
        )
    ).all()
    starts_of: dict[str, list] = {}
    spent_of: dict[str, float] = {}
    first_done: dict[str, object] = {}
    for phone, starts_at, state, quoted, service_id in history:
        key = phone_key(phone)
        if not key:
            continue
        if state not in (AppointmentStatus.cancelled, AppointmentStatus.no_show):
            starts_of.setdefault(key, []).append(starts_at)
        if state == AppointmentStatus.completed:
            spent_of[key] = spent_of.get(key, 0) + (quoted if quoted is not None else prices.get(service_id, 0))
            if key not in first_done or starts_at < first_done[key]:
                first_done[key] = starts_at
    rebooked = sum(1 for visit in visits if any(when > visit.starts_at for when in starts_of.get(phone_key(visit.client_phone), [])))
    client_value = round(sum(spent_of.values()) / len(spent_of), 2) if spent_of else 0
    seen: dict[int, set] = {}
    for visit in visits:
        seen.setdefault(visit.staff_id, set()).add(phone_key(visit.client_phone))
    for staff_id, phones in seen.items():
        if staff_id in by_staff_rows:
            by_staff_rows[staff_id].clients = len(phones)
            by_staff_rows[staff_id].returning = sum(1 for key in phones if first_done.get(key) and first_done[key] < start_at)

    created = session.exec(
        select(Appointment.source, Appointment.created_at, Appointment.starts_at).where(
            Appointment.business_id == business_id, Appointment.created_at >= start_at, Appointment.created_at <= end_at
        )
    ).all()
    by_source: dict[str, int] = {}
    leads = []
    for source, created_at, starts_at in created:
        key = source or "sin_dato"
        by_source[key] = by_source.get(key, 0) + 1
        if source == "page":
            leads.append(max(0.0, (starts_at - created_at).total_seconds() / 86400))
    leads.sort()
    lead_days = round(leads[len(leads) // 2], 1) if leads else None

    since = (end_at.replace(day=1) - timedelta(days=330)).replace(day=1, hour=0, minute=0, second=0)
    totals: dict[str, float] = {}
    for phone, starts_at, state, quoted, service_id in history:
        if state == AppointmentStatus.completed and since <= starts_at <= end_at:
            key = starts_at.strftime("%Y-%m")
            totals[key] = totals.get(key, 0) + (quoted if quoted is not None else prices.get(service_id, 0))
    months = []
    cursor = since
    while cursor <= end_at:
        key = cursor.strftime("%Y-%m")
        months.append({"month": key, "total": round(totals.get(key, 0), 2)})
        cursor = (cursor + timedelta(days=32)).replace(day=1)

    daily: dict[str, list] = {}
    for visit in visits:
        key = visit.starts_at.date().isoformat()
        amount = visit.quoted_price if visit.quoted_price is not None else prices.get(visit.service_id, 0)
        slot = daily.setdefault(key, [0.0, 0])
        slot[0] += amount
        slot[1] += 1
    days_out = []
    cursor_day = start_at.date()
    while cursor_day <= end_at.date():
        total, count = daily.get(cursor_day.isoformat(), [0.0, 0])
        days_out.append({"date": cursor_day.isoformat(), "total": round(total, 2), "count": count})
        cursor_day += timedelta(days=1)
    low_stock = [
        {"name": item.name, "stock": item.stock}
        for item in session.exec(select(Product).where(Product.business_id == business_id)).all()
        if getattr(item, "is_active", True) and item.stock <= 5
    ]
    return {
        "daily": days_out,
        "low_stock": low_stock,
        "service_stats": service_stats,
        "cancelled_count": len(cancelled),
        "no_show_count": len(missed),
        "rebooked": rebooked,
        "client_value": client_value,
        "discount_count": discount_count,
        "discount_amount": round(discount_amount, 2),
        "by_source": by_source,
        "lead_days": lead_days,
        "months": months,
    }


def _minutes(value: str) -> int:
    hour, minute = value.split(":")
    return int(hour) * 60 + int(minute)


def _expected(session: Session, business_id: int, prices: dict[int, float], end_at: datetime) -> tuple[float, int]:
    """Citas por venir (agendadas o esperando anticipo) de ahora al fin del periodo, a su precio."""
    now = local_now(session.get(Business, business_id))
    if end_at <= now:
        return 0, 0
    rows = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.starts_at >= now,
            Appointment.starts_at <= end_at,
            Appointment.status.in_([AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit]),  # type: ignore[attr-defined]
        )
    ).all()
    amount = sum(row.quoted_price if row.quoted_price is not None else prices.get(row.service_id, 0) for row in rows)
    return round(amount, 2), len(rows)


def _winback(session: Session, business_id: int, start_at: datetime, end_at: datetime, prices: dict[int, float], now: datetime) -> dict:
    """De los clientes a los que se invitó a volver en el periodo, cuántos regresaron después del mensaje y cuánto dejaron."""
    sent: dict[str, datetime] = {}
    for contact in session.exec(
        select(ClientContact).where(
            ClientContact.business_id == business_id,
            ClientContact.kind.in_(["invitar", "volver"]),  # type: ignore[attr-defined]
            ClientContact.created_at >= start_at,
            ClientContact.created_at <= end_at,
        ).order_by(ClientContact.created_at)  # type: ignore[arg-type]
    ).all():
        sent.setdefault(contact.phone_key, contact.created_at)  # cuenta desde el primer mensaje del periodo
    if not sent:
        return {"winback_sent": 0, "winback_returned": 0, "winback_booked": 0, "winback_revenue": 0}
    returned: set[str] = set()
    booked: set[str] = set()
    revenue = 0.0
    for phone, state, starts_at, quoted, service_id in session.exec(
        select(Appointment.client_phone, Appointment.status, Appointment.starts_at, Appointment.quoted_price, Appointment.service_id).where(
            Appointment.business_id == business_id, Appointment.starts_at >= start_at
        )
    ).all():
        key = phone_key(phone)
        if key not in sent or starts_at < sent[key]:
            continue
        if state == AppointmentStatus.completed:
            returned.add(key)
            revenue += quoted if quoted is not None else prices.get(service_id, 0)
        elif state in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit) and starts_at >= now:
            booked.add(key)
    return {
        "winback_sent": len(sent),
        "winback_returned": len(returned),
        "winback_booked": len(booked - returned),
        "winback_revenue": round(revenue, 2),
    }


AWAY_DAYS = 45  # los mismos días que usa Clientes para "Dejaron de venir"


def _clients_to_watch(session: Session, business_id: int, now: datetime) -> tuple[int, int]:
    """(clientes que dejaron de venir, clientes que cancelan o faltan seguido), con las reglas de la lista de Clientes."""
    known = {phone_key(phone) for phone in session.exec(select(Client.phone).where(Client.business_id == business_id)).all()}
    rows = session.exec(
        select(Appointment.client_phone, Appointment.status, Appointment.starts_at).where(Appointment.business_id == business_id)
    ).all()
    last_seen: dict[str, date] = {}
    upcoming: set[str] = set()
    lost: dict[str, int] = {}
    for phone, state, starts_at in rows:
        key = phone_key(phone)
        if key not in known:
            continue
        if state == AppointmentStatus.completed:
            if starts_at.date() > last_seen.get(key, date.min):
                last_seen[key] = starts_at.date()
        elif state in (AppointmentStatus.cancelled, AppointmentStatus.no_show):
            lost[key] = lost.get(key, 0) + 1
        elif state in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit) and starts_at >= now:
            upcoming.add(key)
    cut = now.date() - timedelta(days=AWAY_DAYS)
    missing = sum(1 for key, day in last_seen.items() if day < cut and key not in upcoming)
    return missing, sum(1 for count in lost.values() if count >= 2)


def _new_and_returning(session: Session, business_id: int, visits: list[Appointment], start_at: datetime) -> tuple[int, int]:
    """Clientas distintas del periodo: nuevas si no tenían ninguna cita completada antes."""
    phones = {phone_key(visit.client_phone) for visit in visits}
    if not phones:
        return 0, 0
    before = {
        phone_key(row)
        for row in session.exec(
            select(Appointment.client_phone).where(
                Appointment.business_id == business_id,
                Appointment.status == AppointmentStatus.completed,
                Appointment.starts_at < start_at,
            )
        ).all()
    }
    returning = len(phones & before)
    return len(phones) - returning, returning


def _free_hours(session: Session, business_id: int, start_at: datetime, end_at: datetime) -> tuple[dict[int, float], dict[int, float]]:
    """Horas libres y horas de trabajo de cada colaboradora en el periodo."""
    windows: dict[tuple[int, int], int] = {}
    for item in session.exec(select(Schedule).where(Schedule.business_id == business_id, Schedule.is_active == True)).all():  # noqa: E712
        span = _minutes(item.end_time) - _minutes(item.start_time)
        if item.break_start and item.break_end:
            span -= max(0, _minutes(item.break_end) - _minutes(item.break_start))
        windows[(item.staff_id, item.day_of_week)] = max(0, span)
    booked: dict[tuple[int, object], int] = {}
    busy = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.starts_at >= start_at,
            Appointment.starts_at <= end_at,
            Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
        )
    ).all()
    for item in busy:
        key = (item.staff_id, item.starts_at.date())
        booked[key] = booked.get(key, 0) + max(0, int((item.ends_at - item.starts_at).total_seconds() // 60))
    free: dict[int, float] = {}
    opened: dict[int, float] = {}
    day = start_at.date()
    last = end_at.date()
    while day <= last:
        for (staff_id, weekday), open_minutes in windows.items():
            if weekday != day.weekday():
                continue
            left = max(0, open_minutes - booked.get((staff_id, day), 0))
            free[staff_id] = free.get(staff_id, 0) + left / 60
            opened[staff_id] = opened.get(staff_id, 0) + open_minutes / 60
        day += timedelta(days=1)
    return {staff_id: round(hours, 1) for staff_id, hours in free.items()}, {staff_id: round(hours, 1) for staff_id, hours in opened.items()}


def _expired_deposits(session: Session, business_id: int) -> int:
    business = session.get(Business, business_id)
    hours = business.deposit_hold_hours if business and business.deposit_hold_hours else 3
    limit = local_now(business) - timedelta(hours=hours)
    rows = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.awaiting_deposit,
            Appointment.created_at <= limit,
        )
    ).all()
    return len(rows)


@router.post("/commissions", status_code=status.HTTP_204_NO_CONTENT)
def mark_commission(body: PayBody, session: SessionDep, current_user: ManagerDep) -> Response:
    business_id = _business_id(current_user)
    member = session.get(Staff, body.staff_id)
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")
    current = session.exec(
        select(CommissionPay).where(
            CommissionPay.business_id == business_id,
            CommissionPay.staff_id == body.staff_id,
            CommissionPay.period_start == body.start,
            CommissionPay.period_end == body.end,
        )
    ).first()
    if body.paid:
        # `amount` es lo que se entrega ahora: un segundo pago del mismo periodo se suma al primero, no lo reemplaza.
        if current is None:
            session.add(
                CommissionPay(
                    business_id=business_id,
                    staff_id=body.staff_id,
                    period_start=body.start,
                    period_end=body.end,
                    amount=body.amount,
                )
            )
        else:
            current.amount = round(current.amount + body.amount, 2)
            session.add(current)
    else:
        # "Quitar pagos": borra los de esta persona dentro del periodo que se está viendo.
        for row in session.exec(
            select(CommissionPay).where(
                CommissionPay.business_id == business_id,
                CommissionPay.staff_id == body.staff_id,
                CommissionPay.period_start >= body.start,
                CommissionPay.period_end <= body.end,
            )
        ).all():
            session.delete(row)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


def _checked_pay_day(body: ExpenseBody) -> int | None:
    """Día de pago válido según la frecuencia: 1 a 31 si es mensual, 0 a 6 si es semanal; nada si no es fijo o es diario."""
    if body.kind != "fixed" or body.cadence == "day" or body.pay_day is None:
        return None
    low, high = (0, 6) if body.cadence == "week" else (1, 31)
    if not low <= body.pay_day <= high:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Elige un día de pago válido")
    return body.pay_day


@router.post("/expenses", response_model=ExpenseRead, status_code=status.HTTP_201_CREATED)
def add_expense(body: ExpenseBody, session: SessionDep, current_user: ManagerDep) -> Expense:
    if body.kind == "fixed" and body.cadence not in ("month", "week", "day"):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="El gasto fijo necesita periodo")
    expense = Expense(
        business_id=_business_id(current_user),
        name=body.name.strip(),
        amount=body.amount,
        kind=body.kind,
        cadence=body.cadence if body.kind == "fixed" else None,
        pay_day=_checked_pay_day(body),
        category=body.category,
    )
    session.add(expense)
    session.commit()
    session.refresh(expense)
    return expense


@router.put("/expenses/{expense_id}", response_model=ExpenseRead)
def update_expense(
    expense_id: int,
    body: ExpenseBody,
    session: SessionDep,
    current_user: ManagerDep,
) -> Expense:
    if body.kind == "fixed" and body.cadence not in ("month", "week", "day"):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="El gasto fijo necesita periodo")
    expense = session.get(Expense, expense_id)
    if expense is None or expense.business_id != _business_id(current_user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Gasto no encontrado")
    expense.name = body.name.strip()
    expense.amount = body.amount
    expense.kind = body.kind
    expense.cadence = body.cadence if body.kind == "fixed" else None
    expense.pay_day = _checked_pay_day(body)
    expense.category = body.category
    session.add(expense)
    session.commit()
    session.refresh(expense)
    return expense


@router.delete("/expenses/{expense_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_expense(expense_id: int, session: SessionDep, current_user: ManagerDep) -> Response:
    expense = session.get(Expense, expense_id)
    if expense is None or expense.business_id != _business_id(current_user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Gasto no encontrado")
    for mark in session.exec(select(ExpensePayment).where(ExpensePayment.expense_id == expense_id)).all():
        session.delete(mark)
    # Un movimiento de caja que lo había creado se queda, pero ya no apunta a un gasto borrado.
    for move in session.exec(select(CashMove).where(CashMove.expense_id == expense_id)).all():
        move.expense_id = None
        session.add(move)
    session.delete(expense)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


class PaidBody(BaseModel):
    due: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")


def _fixed_expense(session: Session, expense_id: int, business_id: int) -> Expense:
    expense = session.get(Expense, expense_id)
    if expense is None or expense.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Gasto no encontrado")
    if expense.kind != "fixed":
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Solo los gastos fijos tienen pagos que marcar")
    return expense


@router.post("/expenses/{expense_id}/paid", status_code=status.HTTP_201_CREATED)
def mark_expense_paid(expense_id: int, body: PaidBody, session: SessionDep, current_user: ManagerDep) -> dict:
    """"Ya pagué": el pago que tocaba en esa fecha pasa a contar hoy, que es cuando salió el dinero."""
    business_id = _business_id(current_user)
    expense = _fixed_expense(session, expense_id, business_id)
    _checked_day(body.due)
    due = date.fromisoformat(body.due)
    if due not in _pay_dates(expense, due, due):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Ese gasto no se paga en esa fecha")
    existing = session.exec(
        select(ExpensePayment).where(ExpensePayment.expense_id == expense_id, ExpensePayment.due == body.due)
    ).first()
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese pago ya está marcado como pagado")
    paid_on = local_today(session.get(Business, business_id)).isoformat()
    session.add(ExpensePayment(business_id=business_id, expense_id=expense_id, due=body.due, paid_on=paid_on))
    session.commit()
    return {"due": body.due, "paid_on": paid_on}


@router.delete("/expenses/{expense_id}/paid", status_code=status.HTTP_204_NO_CONTENT)
def unmark_expense_paid(expense_id: int, due: str, session: SessionDep, current_user: ManagerDep) -> Response:
    business_id = _business_id(current_user)
    _fixed_expense(session, expense_id, business_id)
    _checked_day(due)
    mark = session.exec(select(ExpensePayment).where(ExpensePayment.expense_id == expense_id, ExpensePayment.due == due)).first()
    if mark is not None:
        session.delete(mark)
        session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


class CashBody(BaseModel):
    day: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    counted: float = Field(ge=0, le=10_000_000)
    note: str | None = Field(default=None, max_length=500)
    # Fondo con el que abrió la caja. Vacío = el que ya tenía guardado ese día.
    opening: float | None = Field(default=None, ge=0, le=10_000_000)


class CashMoveBody(BaseModel):
    day: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    kind: str = Field(pattern=r"^(in|out)$")
    amount: float = Field(gt=0, le=10_000_000)
    reason: str = Field(min_length=1, max_length=255)
    # Solo para salidas: que también quede como gasto en Reportes.
    as_expense: bool = False


class CashReopenBody(BaseModel):
    day: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")


def _checked_day(day: str) -> str:
    try:
        date.fromisoformat(day)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Elige una fecha válida") from None
    return day


def _cash_saved(session: Session, business_id: int, day: str) -> CashCount | None:
    return session.exec(select(CashCount).where(CashCount.business_id == business_id, CashCount.day == day)).first()


def _ensure_open(session: Session, business_id: int, day: str) -> None:
    saved = _cash_saved(session, business_id, day)
    if saved is not None and saved.closed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Ese corte ya está cerrado. Ábrelo de nuevo para cambiarlo.",
        )


@router.get("/cash/range")
def read_cash_range(start: str, end: str, session: SessionDep, current_user: ManagerDep) -> list[dict]:
    """Los cortes de caja guardados entre dos fechas (para el Excel y el PDF de Reportes)."""
    business_id = _business_id(current_user)
    _checked_day(start)
    _checked_day(end)
    rows = session.exec(
        select(CashCount)
        .where(CashCount.business_id == business_id, CashCount.day >= start, CashCount.day <= end)
        .order_by(col(CashCount.day))
    ).all()
    return [_cash_row(row) for row in rows]


@router.get("/cash")
def read_cash(day: str, session: SessionDep, current_user: ManagerDep) -> dict:
    """Corte de caja de un día: lo cobrado por método (servicios, propinas y productos), los movimientos de caja, el fondo, el efectivo esperado y el corte guardado."""
    business_id = _business_id(current_user)
    _checked_day(day)
    summary = _day_summary(session, business_id, day)
    saved = _cash_saved(session, business_id, day)
    history = session.exec(
        select(CashCount).where(CashCount.business_id == business_id).order_by(col(CashCount.day).desc()).limit(10)
    ).all()
    previous = session.exec(
        select(CashCount).where(CashCount.business_id == business_id, CashCount.day < day).order_by(col(CashCount.day).desc())
    ).first()
    moves = session.exec(
        select(CashMove).where(CashMove.business_id == business_id, CashMove.day == day).order_by(col(CashMove.id))
    ).all()
    # El fondo es el que la dueña guardó; el de ayer solo se sugiere (la pantalla lo propone y ella lo confirma).
    opening = saved.opening if saved is not None else 0
    moves_in = round(sum(item.amount for item in moves if item.kind == "in"), 2)
    moves_out = round(sum(item.amount for item in moves if item.kind == "out"), 2)
    expected = round(opening + summary["cash"]["total"] + moves_in - moves_out, 2)
    return {
        "day": day,
        "by_method": summary["by_method"],
        "cash_parts": summary["cash"],
        "opening": opening,
        "suggested_opening": previous.counted if previous is not None else 0,
        "moves": [_move_row(item) for item in moves],
        "moves_in": moves_in,
        "moves_out": moves_out,
        "expected_cash": expected,
        "count": _cash_row(saved) if saved else None,
        "history": [_cash_row(row) for row in history],
    }


@router.put("/cash")
def save_cash(body: CashBody, session: SessionDep, current_user: ManagerDep) -> dict:
    """Guarda y cierra el corte del día. Un corte cerrado no se edita hasta reabrirlo."""
    business_id = _business_id(current_user)
    _checked_day(body.day)
    business = session.get(Business, business_id)
    if body.day > local_today(business).isoformat():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Ese día todavía no llega.")
    _ensure_open(session, business_id, body.day)
    row = _cash_saved(session, business_id, body.day)
    if row is None:
        row = CashCount(business_id=business_id, day=body.day)
    if body.opening is not None:
        row.opening = round(body.opening, 2)
    session.add(row)
    session.flush()
    # El esperado se calcula con el fondo ya guardado y se congela al cerrar: es lo que queda como constancia.
    row.expected = read_cash(body.day, session, current_user)["expected_cash"]
    row.counted = round(body.counted, 2)
    row.note = (body.note or "").strip() or None
    row.closed = True
    row.closed_by = current_user.full_name
    row.closed_at = local_now(business)
    session.add(row)
    session.commit()
    return read_cash(body.day, session, current_user)


@router.post("/cash/reopen")
def reopen_cash(body: CashReopenBody, session: SessionDep, current_user: ManagerDep) -> dict:
    business_id = _business_id(current_user)
    _checked_day(body.day)
    row = _cash_saved(session, business_id, body.day)
    if row is not None and row.closed:
        row.closed = False
        session.add(row)
        session.commit()
    return read_cash(body.day, session, current_user)


@router.post("/cash/moves", status_code=status.HTTP_201_CREATED)
def add_cash_move(body: CashMoveBody, session: SessionDep, current_user: ManagerDep) -> dict:
    """Mete o saca dinero del cajón. Una salida puede quedar también como gasto del día en Reportes."""
    business_id = _business_id(current_user)
    _checked_day(body.day)
    _ensure_open(session, business_id, body.day)
    reason = body.reason.strip()
    if not reason:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Escribe para qué fue")
    expense_id = None
    if body.as_expense and body.kind == "out":
        expense = Expense(
            business_id=business_id,
            name=reason,
            amount=round(body.amount, 2),
            kind="variable",
            created_at=datetime.fromisoformat(body.day) + timedelta(hours=12),
        )
        session.add(expense)
        session.flush()
        expense_id = expense.id
    session.add(
        CashMove(
            business_id=business_id,
            day=body.day,
            kind=body.kind,
            amount=round(body.amount, 2),
            reason=reason,
            expense_id=expense_id,
            created_by=current_user.full_name,
        )
    )
    session.commit()
    return read_cash(body.day, session, current_user)


@router.delete("/cash/moves/{move_id}")
def delete_cash_move(move_id: int, session: SessionDep, current_user: ManagerDep) -> dict:
    business_id = _business_id(current_user)
    move = session.get(CashMove, move_id)
    if move is None or move.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movimiento no encontrado")
    _ensure_open(session, business_id, move.day)
    day = move.day
    if move.expense_id is not None:
        expense = session.get(Expense, move.expense_id)
        if expense is not None and expense.business_id == business_id:
            session.delete(expense)
    session.delete(move)
    session.commit()
    return read_cash(day, session, current_user)


def _day_summary(session: Session, business_id: int, day: str) -> dict:
    """Lo cobrado ese día por método y, aparte, qué parte del efectivo es de servicios, propinas y productos."""
    start = datetime.fromisoformat(day)
    end = start + timedelta(days=1)
    rows = session.exec(
        select(Appointment).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.completed,
            Appointment.starts_at >= start,
            Appointment.starts_at < end,
        )
    ).all()
    prices = {item.id: item.price for item in session.exec(select(Service).where(Service.business_id == business_id)).all()}
    by_method: dict[str, float] = {}
    cash = {"services": 0.0, "tips": 0.0, "products": 0.0}

    def add(method: str, part: str, amount: float) -> None:
        if amount <= 0:
            return
        by_method[method] = round(by_method.get(method, 0) + amount, 2)
        if method == "efectivo":
            cash[part] = round(cash[part] + amount, 2)

    for row in rows:
        amount = row.quoted_price if row.quoted_price is not None else prices.get(row.service_id, 0)
        # El anticipo ya se pagó por transferencia antes de la cita: en el cajón solo entra lo que faltaba.
        method = row.payment_method or "sin_registrar"
        add(method, "services", max(amount - (row.deposit_amount or 0), 0))
        # La propina se cobra junto con la cita, por el mismo método.
        add(method, "tips", row.tip or 0)
    sales = session.exec(
        select(Sale).where(Sale.business_id == business_id, Sale.created_at >= start, Sale.created_at < end)
    ).all()
    for sale in sales:
        method = sale.method if sale.method in PAYMENT_METHODS else "efectivo"
        add(method, "products", sale.total)
    cash["total"] = round(cash["services"] + cash["tips"] + cash["products"], 2)
    return {"by_method": by_method, "cash": cash}


def _move_row(row: CashMove) -> dict:
    return {
        "id": row.id,
        "kind": row.kind,
        "amount": row.amount,
        "reason": row.reason,
        "as_expense": row.expense_id is not None,
        "created_by": row.created_by,
    }


def _cash_row(row: CashCount) -> dict:
    return {
        "day": row.day,
        "expected": row.expected,
        "counted": row.counted,
        "difference": round(row.counted - row.expected, 2),
        "note": row.note,
        "opening": row.opening,
        "closed": row.closed,
        "closed_by": row.closed_by,
    }


@router.post("/products/{product_id}/in", response_model=ProductRead)
def receive_product(
    product_id: int,
    body: InBody,
    session: SessionDep,
    current_user: ManagerDep,
) -> Product:
    business_id = _business_id(current_user)
    product = session.get(Product, product_id)
    if product is None or product.business_id != business_id or not product.is_active:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Producto no encontrado")
    product.stock += body.qty
    if body.qty:
        product.cost = round(body.cost / body.qty, 2)
    session.add(product)
    session.add(
        StockMove(
            business_id=business_id,
            product_id=product_id,
            product_name=product.name,
            kind="in",
            qty=body.qty,
            amount=body.cost,
            iva=round(body.cost * 0.16, 2) if body.iva else 0,
        )
    )
    session.commit()
    session.refresh(product)
    return product


@router.get("/moves", response_model=list[MoveRead])
def list_moves(session: SessionDep, current_user: ManagerDep) -> list[StockMove]:
    business_id = _business_id(current_user)
    return list(
        session.exec(select(StockMove).where(StockMove.business_id == business_id).order_by(col(StockMove.id).desc())).all()
    )[:30]


class _Owner:
    """Para llamar al reporte desde otro lado (correo mensual, contador) con solo el negocio."""

    def __init__(self, business_id: int) -> None:
        self.business_id = business_id


@router.get("/alerts")
def shop_alerts(session: SessionDep, current_user: ManagerDep) -> list[dict]:
    """Avisos para Inicio: cómo va la semana, el hueco más flojo, faltas por colaboradora y productos por acabarse."""
    business_id = _business_id(current_user)
    business = session.get(Business, business_id)
    now = local_now(business)
    prices = {item.id: item.price for item in session.exec(select(Service).where(Service.business_id == business_id)).all()}
    since = now - timedelta(weeks=8)
    rows = session.exec(
        select(Appointment).where(Appointment.business_id == business_id, Appointment.starts_at >= since, Appointment.starts_at <= now)
    ).all()
    out: list[dict] = []

    def money(rows_in: list) -> float:
        return sum(row.quoted_price if row.quoted_price is not None else prices.get(row.service_id, 0) for row in rows_in)

    done = [row for row in rows if row.status == AppointmentStatus.completed]
    this_week = money([row for row in done if row.starts_at >= now - timedelta(days=7)])
    last_week = money([row for row in done if now - timedelta(days=14) <= row.starts_at < now - timedelta(days=7)])
    if last_week > 0:
        change = round((this_week - last_week) / last_week * 100)
        if change <= -15:
            out.append({"tone": "warn", "text": f"Estos 7 días llevas ${this_week:,.0f}, abajo de los ${last_week:,.0f} de la semana anterior.", "link": "/admin/dashboard"})
        elif change >= 15:
            out.append({"tone": "ok", "text": f"Estos 7 días llevas ${this_week:,.0f}, arriba de los ${last_week:,.0f} de la semana anterior.", "link": "/admin/dashboard"})

    open_days = {item.day_of_week for item in session.exec(select(Schedule).where(Schedule.business_id == business_id, Schedule.is_active == True)).all()}  # noqa: E712
    if len(done) >= 10 and open_days:
        parts = {"en la mañana": range(0, 13), "en la tarde": range(13, 18), "en la noche": range(18, 24)}
        counts = {(day, name): 0 for day in open_days for name in parts}
        for row in done:
            for name, hours in parts.items():
                if row.starts_at.hour in hours and (row.starts_at.weekday(), name) in counts:
                    counts[(row.starts_at.weekday(), name)] += 1
        # Solo franjas en las que sí se ha atendido alguna vez (si no, quizá ni abren a esa hora).
        worked = {name for (_, name), count in counts.items() if count}
        candidates = {key: count for key, count in counts.items() if key[1] in worked}
        if candidates:
            (day, name), count = min(candidates.items(), key=lambda pair: pair[1])
            days = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábados", "domingos"]
            out.append({"tone": "info", "text": f"Los {days[day]} {name} casi no hay citas ({count} en 8 semanas): buen momento para una promoción.", "link": "/admin/settings?sec=promociones"})

    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    names = {item.id: item.full_name for item in session.exec(select(Staff).where(Staff.business_id == business_id)).all()}
    missed: dict[int, int] = {}
    for row in rows:
        if row.status == AppointmentStatus.no_show and row.starts_at >= month_start:
            missed[row.staff_id] = missed.get(row.staff_id, 0) + 1
    for staff_id, count in sorted(missed.items(), key=lambda pair: -pair[1]):
        if count >= 3:
            out.append({"tone": "warn", "text": f"{names.get(staff_id, 'Alguien del equipo')} tiene {count} faltas de clientes este mes.", "link": "/admin/clientes"})

    for item in session.exec(select(Product).where(Product.business_id == business_id, Product.is_active == True)).all():  # noqa: E712
        if item.stock <= 3:
            out.append({"tone": "warn", "text": f"Quedan {item.stock} de {item.name}.", "link": "/admin/caja"})
    return out[:5]


@router.get("/accounting")
def accounting(session: SessionDep, current_user: ManagerDep, year: int) -> list[dict]:
    """Para el contador: por mes, ingresos por método de pago y gastos por categoría."""
    owner = _Owner(_business_id(current_user))
    months = []
    for month in range(1, 13):
        start = f"{year}-{month:02d}-01"
        last = (datetime(year + (month == 12), month % 12 + 1, 1) - timedelta(days=1)).date().isoformat()
        report = sales_report(session, owner, start, last)  # type: ignore[arg-type]
        months.append({
            "month": f"{year}-{month:02d}",
            "by_method": report.by_method,
            "service_income": report.service_income,
            "product_income": report.product_income,
            "total": report.total,
            "by_category": report.by_category,
            "expenses": round(report.expense_fixed + report.expense_variable, 2),
            "commissions": report.commission_total,
            "tips": report.tips_total,
            "product_cost": report.product_cost,
            "profit": report.profit,
        })
    return months
