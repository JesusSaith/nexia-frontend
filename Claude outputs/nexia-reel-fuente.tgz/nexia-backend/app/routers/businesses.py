import json
import uuid
from datetime import date, datetime, time, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from fastapi.responses import RedirectResponse
from sqlalchemy import update
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.core.shop_note import closed_reason
from app.core.clock import local_now, local_today
from app.core.images import image_response
from app.core.throttle import throttle as _throttle
from app.core.booking import lock_staff, ten_digit_phone, as_local_naive, format_timestamp, open_slots, owed_deposit
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.client import Client, phone_key
from app.models.business import Business
from app.models.schedule import Schedule
from app.models.service import Service
from app.models.staff import Staff
from app.models.staff_service import StaffService
from app.models.waitlist import Waitlist
from app.models.user import UserRole
from app.routers.auth import BusinessUserDep
from app.schemas.appointment import AppointmentCreate, AppointmentRead, AvailabilitySlot
from app.schemas.business import BusinessBrandResponse, BusinessProfileUpdate
from app.schemas.service import ServicePublic
from app.schemas.staff import StaffPublic

router = APIRouter(prefix="/businesses", tags=["businesses"])


def _active_business(session: Session, slug: str) -> Business:
    business = session.exec(
        select(Business).where(Business.slug == slug, Business.is_active.is_(True))
    ).first()
    if business is None:
        # Un enlace viejo (antes de cambiarlo) sigue llevando al negocio.
        business = next(
            (row for row in session.exec(select(Business).where(Business.old_slugs.contains(slug), Business.is_active.is_(True))).all()  # type: ignore[union-attr]
             if slug in (row.old_slugs or "").split(",")),
            None,
        )
    if business is None or business.id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    return business


def _active_service(session: Session, business_id: int, service_id: int) -> Service:
    service = session.get(Service, service_id)
    if service is None or service.business_id != business_id or not service.is_active:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Servicio no encontrado")
    return service


def _active_staff(session: Session, business_id: int, staff_id: int) -> Staff:
    member = session.get(Staff, staff_id)
    if member is None or member.business_id != business_id or not member.is_active:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")
    return member


def _ensure_staff_does(session: Session, business_id: int, staff_id: int, service_ids: list[int]) -> None:
    """Solo se reserva con quien de verdad hace el servicio (y sus extras)."""
    if staff_id not in _eligible_staff_ids(session, business_id, service_ids):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa persona no hace este servicio. Elige a alguien más.")


def _staff_schedules(session: Session, business_id: int, staff_id: int) -> list[Schedule]:
    statement = select(Schedule).where(
        Schedule.business_id == business_id,
        Schedule.staff_id == staff_id,
    )
    return list(session.exec(statement).all())


def _remember_client(
    session: Session,
    business_id: int,
    full_name: str,
    phone: str,
    email: str | None,
    notes: str | None,
) -> None:
    key = phone_key(phone)
    existing = next(
        (
            row
            for row in session.exec(select(Client).where(Client.business_id == business_id)).all()
            if phone_key(row.phone) == key
        ),
        None,
    )
    if existing is None:
        session.add(Client(business_id=business_id, full_name=full_name, phone=phone, email=email, notes=notes))
        return
    existing.full_name = full_name
    if email:
        existing.email = email
    if notes:
        existing.notes = notes


def to_appointment_read(appointment: Appointment, service: Service, member: Staff) -> AppointmentRead:
    if appointment.id is None:
        raise RuntimeError("Appointment id is missing")
    return AppointmentRead(
        id=appointment.id,
        client_name=appointment.client_name,
        client_phone=appointment.client_phone,
        client_email=appointment.client_email,
        service_id=appointment.service_id,
        service_name=service.name,
        staff_id=appointment.staff_id,
        staff_name=member.full_name,
        starts_at=format_timestamp(appointment.starts_at),
        status=appointment.status,
        notes=appointment.notes,
        cancel_token=appointment.cancel_token,
        deposit_amount=appointment.deposit_amount,
        payment_proof=appointment.payment_proof,
        quoted_price=appointment.quoted_price,
        client_confirmed=appointment.client_confirmed,
        price_accepted=appointment.price_accepted,
        created_at=format_timestamp(appointment.created_at) if appointment.created_at else None,
        resource_name=appointment.resource_name,
        extra_label=appointment.extra_label,
        answers=appointment.answers,
        payment_method=appointment.payment_method,
        tip=appointment.tip,
        visit_note=appointment.visit_note,
        discount_percent=appointment.discount_percent,
        needs_approval=bool(appointment.needs_approval),
        paid_claim=bool(appointment.paid_claim),
        photo_count=len(reference_photos(appointment)),
    )


MAX_UPCOMING_PER_PHONE = 3
PHOTO_RETENTION_DAYS = 30


def purge_old_photos(session: Session) -> None:
    """Las fotos de referencia solo sirven para cotizar; se borran 30 días después de la cita."""
    limit = local_now() - timedelta(days=PHOTO_RETENTION_DAYS)
    session.exec(  # type: ignore[call-overload]
        update(Appointment)
        .where(Appointment.reference_photos.is_not(None), Appointment.starts_at < limit)  # type: ignore[union-attr]
        .values(reference_photos=None)
    )


def reference_photos(appointment: Appointment) -> list[str]:
    try:
        rows = json.loads(appointment.reference_photos or "[]")
    except ValueError:
        return []
    return [row for row in rows if isinstance(row, str)] if isinstance(rows, list) else []


@router.get("/me", response_model=BusinessBrandResponse)
def read_my_brand(current_user: BusinessUserDep, session: Session = Depends(get_session)) -> Business:
    return _owned_business(session, current_user.business_id)


@router.put("/me", response_model=BusinessBrandResponse)
def update_my_brand(
    body: BusinessProfileUpdate,
    current_user: BusinessUserDep,
    session: Session = Depends(get_session),
) -> Business:
    if current_user.role != UserRole.owner:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Solo el propietario puede configurar el negocio")
    business = _owned_business(session, current_user.business_id)
    changes = body.model_dump(exclude_unset=True)
    for key, value in changes.items():
        if isinstance(value, str):
            value = value.strip()
            if key in {"primary_color", "canvas_color"}:
                value = value.lower()
            if key not in {"name", "phone"} and value == "":
                value = None
        setattr(business, key, value)
    session.add(business)
    session.commit()
    session.refresh(business)
    return business


def _owned_business(session: Session, business_id: int | None) -> Business:
    business = session.get(Business, business_id) if business_id is not None else None
    if business is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    return business


@router.get("/{slug}", response_model=BusinessBrandResponse, response_model_exclude={"message_templates", "uses_commissions"})
def read_business_brand(slug: str, session: Session = Depends(get_session)) -> BusinessBrandResponse:
    from app.core.booking import business_hours

    business = _active_business(session, slug)
    data = BusinessBrandResponse.model_validate(business, from_attributes=True)
    data.hours = business_hours(session, business.id)  # type: ignore[arg-type]
    return data


class PrivacyNotice(BaseModel):
    name: str
    phone: str | None = None
    email: str | None = None
    address: str | None = None
    privacy_notice: str | None = None


@router.get("/{slug}/privacy", response_model=PrivacyNotice)
def read_privacy_notice(slug: str, session: Session = Depends(get_session)) -> PrivacyNotice:
    business = _active_business(session, slug)
    return PrivacyNotice(
        name=business.name,
        phone=business.phone or None,
        email=business.email,
        address=business.address,
        privacy_notice=business.privacy_notice,
    )


@router.get("/{slug}/logo")
def read_logo(slug: str, session: Session = Depends(get_session)) -> Response:
    """Logo como imagen normal, para la vista previa de WhatsApp e Instagram (no leen data URLs)."""
    business = _active_business(session, slug)
    logo = business.logo_url or ""
    if logo.startswith("https://"):
        return RedirectResponse(logo)
    # Solo PNG, JPG, WebP o GIF y con encabezados que impiden ejecutarlo (ver app/core/images.py).
    image = image_response(logo, "public, max-age=3600")
    if image is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sin logo")
    return image


@router.get("/{slug}/services", response_model=list[ServicePublic])
def list_public_services(slug: str, session: Session = Depends(get_session)) -> list[Service]:
    business = _active_business(session, slug)
    statement = (
        select(Service)
        .where(Service.business_id == business.id, Service.is_active.is_(True))
        .order_by(Service.sort_order, Service.name)
    )
    return list(session.exec(statement).all())


@router.get("/{slug}/staff", response_model=list[StaffPublic])
def list_public_staff(slug: str, session: Session = Depends(get_session)) -> list[StaffPublic]:
    business = _active_business(session, slug)
    members = list(
        session.exec(
            select(Staff)
            .where(Staff.business_id == business.id, Staff.is_active.is_(True))
            .order_by(Staff.full_name)
        ).all()
    )
    active_services = set(
        session.exec(
            select(Service.id).where(Service.business_id == business.id, Service.is_active.is_(True))
        ).all()
    )
    staff_ids = [member.id for member in members if member.id is not None]
    links = session.exec(
        select(StaffService).where(
            StaffService.business_id == business.id,
            StaffService.staff_id.in_(staff_ids),  # type: ignore[attr-defined]
        )
    ).all() if staff_ids else []
    grouped: dict[int, list[int]] = {}
    for link in links:
        if link.service_id not in active_services:
            continue
        grouped.setdefault(link.staff_id, []).append(link.service_id)
    for service_ids in grouped.values():
        service_ids.sort()
    return [
        StaffPublic(
            id=member.id,  # type: ignore[arg-type]
            full_name=member.full_name,
            role_title=member.role_title,
            avatar_url=member.avatar_url,
            bio=member.bio,
            service_ids=grouped.get(member.id or 0, []),
        )
        for member in members
    ]


def _extra_services(session: Session, business_id: int, raw: str | None) -> list[Service]:
    if not raw:
        return []
    found: list[Service] = []
    for part in raw.split(","):
        if part.strip().isdigit():
            service = _active_service(session, business_id, int(part))
            found.append(service)
    return found


def _completed_visits(session: Session, business_id: int, phone: str) -> int:
    key = phone_key(phone)
    phones = session.exec(
        select(Appointment.client_phone).where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.completed,
        )
    ).all()
    return sum(1 for item in phones if phone_key(item) == key)


def _loyalty_percent(business: Business, visits: int) -> int | None:
    """Cada `loyalty_every` visitas cobradas, la siguiente lleva `loyalty_percent` de descuento."""
    every = business.loyalty_every or 0
    percent = business.loyalty_percent or 0
    if every < 1 or percent <= 0:
        return None
    return min(percent, 100) if (visits + 1) % every == 0 else None


def _find_coupon(business: Business, code: str) -> dict | None:
    try:
        rows = json.loads(business.coupons or "[]")
    except ValueError:
        return None
    wanted = code.strip().lower()
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and str(row.get("code", "")).strip().lower() == wanted:
            return row
    return None


def _coupon_percent(business: Business, code: str, visits: int) -> int:
    """Porcentaje del cupón o 422 si no existe, no aplica o ya no es primera visita."""
    row = _find_coupon(business, code)
    try:
        percent = int(row.get("percent") or 0) if row else 0
    except (TypeError, ValueError):
        percent = 0
    if row is None or percent <= 0 or (row.get("first_visit") and visits > 0):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Ese cupón no es válido")
    return min(percent, 100)


class LoyaltyInfo(BaseModel):
    percent: int | None = None
    visits: int = 0
    # Solo informativo para la página: el descuento real lo decide la creación de la cita.
    coupon_percent: int | None = None


@router.get("/{slug}/loyalty", response_model=LoyaltyInfo)
def read_loyalty(
    slug: str,
    request: Request,
    phone: str = "",
    coupon: Annotated[str | None, Query(max_length=40)] = None,
    session: Session = Depends(get_session),
) -> LoyaltyInfo:
    business = _active_business(session, slug)
    # Sin límite se podrían adivinar cupones o saber cuántas visitas tiene cualquier teléfono.
    _throttle(request, f"loyalty:{business.id}", limit=60)
    visits = _completed_visits(session, business.id, phone) if phone.strip() else 0  # type: ignore[arg-type]
    coupon_off: int | None = None
    if coupon and coupon.strip():
        try:
            coupon_off = _coupon_percent(business, coupon, visits)
        except HTTPException:
            coupon_off = None
    return LoyaltyInfo(percent=_loyalty_percent(business, visits), visits=visits, coupon_percent=coupon_off)


class PackageLeft(BaseModel):
    label: str
    total: int
    remaining: int


@router.get("/{slug}/package", response_model=PackageLeft | None)
def read_package(slug: str, phone: str, request: Request, session: Session = Depends(get_session)) -> PackageLeft | None:
    business = _active_business(session, slug)
    _throttle(request, f"package:{business.id}", limit=60)
    from app.models.package import find_package

    row = find_package(session, business.id, phone)
    if row is None or row.remaining < 1:
        return None
    return PackageLeft(label=row.label, total=row.total, remaining=row.remaining)


def _eligible_staff_ids(session: Session, business_id: int, service_ids: list[int]) -> list[int]:
    members = session.exec(
        select(Staff.id)
        .where(Staff.business_id == business_id, Staff.is_active.is_(True))
        .order_by(Staff.full_name)
    ).all()
    links = session.exec(select(StaffService).where(StaffService.business_id == business_id)).all()
    offered: dict[int, set[int]] = {}
    for link in links:
        offered.setdefault(link.staff_id, set()).add(link.service_id)
    return [member for member in members if member is not None and set(service_ids) <= offered.get(member, set())]


def _day_slots(
    session: Session,
    business: Business,
    service: Service,
    staff_id: int,
    day: date,
    extras: list[Service],
    resource: str | None,
    variant: str | None = None,
    minutes_override: int | None = None,
    ignore_id: int | None = None,
) -> list[datetime]:
    """Horarios libres de una persona en un día. Al cambiar una cita ya hecha se pasa su duración real y su id."""
    today = local_today(business)
    if day < today or day > today + timedelta(days=business.max_days_ahead or 90) or closed_reason(business, day):
        return []
    option = _variant(service, variant)
    minutes = minutes_override or (option["duration_minutes"] if option else service.duration_minutes) + sum(item.duration_minutes for item in extras)
    slots = open_slots(
        session,
        business.id,
        staff_id,
        day,
        minutes,
        _staff_schedules(session, business.id, staff_id),
        ignore_id=ignore_id,
        service_id=service.id,
        capacity=service.capacity or 1,
    )
    earliest = local_now(business) + timedelta(hours=business.min_notice_hours or 0)
    slots = [slot for slot in slots if slot >= earliest]
    if resource:
        taken = session.exec(
            select(Appointment).where(
                Appointment.business_id == business.id,
                Appointment.resource_name == resource,
                Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
                Appointment.starts_at < datetime.combine(day, time.max),
                Appointment.ends_at > datetime.combine(day, time.min),
            )
        ).all()
        slots = [
            slot
            for slot in slots
            if all(slot >= row.ends_at or slot + timedelta(minutes=minutes) <= row.starts_at for row in taken)
        ]
    return slots


def _variant(service: Service, name: str | None) -> dict | None:
    """La variante elegida (nombre exacto) con su precio y duración, o None."""
    if not name or not service.variants:
        return None
    return next((item for item in json.loads(service.variants) if item.get("name") == name), None)


def _staff_for(session: Session, business: Business, service: Service, staff_id: int | None, extras: list[Service]) -> list[int]:
    """Sin staff_id ("Cualquiera") devuelve a todos los que hacen el servicio y sus extras."""
    if staff_id is not None:
        _active_staff(session, business.id, staff_id)
        return [staff_id]
    return _eligible_staff_ids(session, business.id, [service.id, *(item.id for item in extras)])  # type: ignore[list-item]


@router.get("/{slug}/availability", response_model=list[AvailabilitySlot])
def read_availability(
    slug: str,
    service_id: int,
    day: Annotated[date, Query(alias="date")],
    staff_id: int | None = None,
    extra: str | None = None,
    resource: str | None = None,
    variant: str | None = None,
    session: Session = Depends(get_session),
) -> list[AvailabilitySlot]:
    business = _active_business(session, slug)
    service = _active_service(session, business.id, service_id)
    extras = _extra_services(session, business.id, extra)
    merged: dict[datetime, int] = {}
    for member in _staff_for(session, business, service, staff_id, extras):
        for slot in _day_slots(session, business, service, member, day, extras, resource, variant):
            merged.setdefault(slot, member)
    return [AvailabilitySlot(starts_at=format_timestamp(slot), staff_id=merged[slot]) for slot in sorted(merged)]


@router.get("/{slug}/availability/days", response_model=list[str])
def read_available_days(
    slug: str,
    service_id: int,
    month: Annotated[str, Query(pattern=r"^\d{4}-\d{2}$")],
    staff_id: int | None = None,
    extra: str | None = None,
    resource: str | None = None,
    variant: str | None = None,
    session: Session = Depends(get_session),
) -> list[str]:
    """Días del mes (YYYY-MM) con al menos un horario libre, en una sola llamada."""
    business = _active_business(session, slug)
    service = _active_service(session, business.id, service_id)
    extras = _extra_services(session, business.id, extra)
    members = _staff_for(session, business, service, staff_id, extras)
    year, number = (int(part) for part in month.split("-"))
    if not 1 <= number <= 12:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Mes inválido")
    day = date(year, number, 1)
    found: list[str] = []
    while day.month == number:
        if any(_day_slots(session, business, service, member, day, extras, resource, variant) for member in members):
            found.append(day.isoformat())
        day += timedelta(days=1)
    return found


class WaitlistJoin(BaseModel):
    service_id: int
    staff_id: int
    day: date
    client_name: str = Field(min_length=1, max_length=255)
    client_phone: str = Field(min_length=8, max_length=32)


@router.post("/{slug}/waitlist", status_code=status.HTTP_201_CREATED)
def join_waitlist(
    slug: str,
    body: WaitlistJoin,
    request: Request,
    session: Session = Depends(get_session),
) -> dict[str, bool]:
    from app.routers.notices import add_notice, day_of

    business = _active_business(session, slug)
    _throttle(request, f"waitlist:{business.id}")
    service = _active_service(session, business.id, body.service_id)
    member = _active_staff(session, business.id, body.staff_id)
    _ensure_staff_does(session, business.id, body.staff_id, [service.id])  # type: ignore[list-item]
    phone = ten_digit_phone(body.client_phone)
    if phone is None:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Escribe tu teléfono a 10 dígitos")
    session.add(
        Waitlist(
            business_id=business.id,
            service_id=service.id,  # type: ignore[arg-type]
            staff_id=body.staff_id,
            day=body.day.isoformat(),
            client_name=body.client_name.strip(),
            client_phone=phone,
        )
    )
    add_notice(
        session,
        business.id,  # type: ignore[arg-type]
        f"{body.client_name.strip()} espera un horario de {service.name} con {member.full_name.split()[0]} {day_of(datetime.combine(body.day, datetime.min.time()))}",
        "waitlist",
    )
    session.commit()
    return {"ok": True}


@router.post("/{slug}/appointments", response_model=AppointmentRead, status_code=status.HTTP_201_CREATED)
def create_public_appointment(
    slug: str,
    body: AppointmentCreate,
    request: Request,
    session: Session = Depends(get_session),
) -> AppointmentRead:
    if body.website:
        # Sin pistas para el bot: el mismo error genérico que vería cualquiera.
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No pudimos registrar la cita")
    business = _active_business(session, slug)
    _throttle(request, f"book:{business.id}")
    if ten_digit_phone(body.client_phone) is None:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Escribe tu teléfono a 10 dígitos")
    key = phone_key(body.client_phone)
    upcoming = session.exec(
        select(Appointment.client_phone).where(
            Appointment.business_id == business.id,
            Appointment.starts_at >= local_now(business),
            Appointment.status.in_([AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit]),  # type: ignore[attr-defined]
        )
    ).all()
    if sum(1 for phone in upcoming if phone_key(phone) == key) >= MAX_UPCOMING_PER_PHONE:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Ya tienes {MAX_UPCOMING_PER_PHONE} citas próximas con este teléfono. Para agendar más, escríbenos por WhatsApp.",
        )
    purge_old_photos(session)
    service = _active_service(session, business.id, body.service_id)
    member = _active_staff(session, business.id, body.staff_id)
    extras = [_active_service(session, business.id, item) for item in body.extra_service_ids if item != body.service_id]
    option = _variant(service, body.variant)
    if body.variant and option is None:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Esa opción del servicio ya no existe")
    _ensure_staff_does(session, business.id, body.staff_id, [service.id, *(item.id for item in extras)])  # type: ignore[list-item]
    minutes = (option["duration_minutes"] if option else service.duration_minutes) + sum(item.duration_minutes for item in extras)
    starts_at = as_local_naive(body.starts_at, business)
    if starts_at.date() > local_today(business) + timedelta(days=business.max_days_ahead or 90):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese día está fuera del calendario")
    if reason := closed_reason(business, starts_at.date()):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=reason)
    if starts_at < local_now(business) + timedelta(hours=business.min_notice_hours or 0):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Elige un horario con más anticipación")
    lock_staff(session, body.staff_id)  # dos reservas a la vez por el mismo hueco: la segunda espera y ya lo ve ocupado
    available = open_slots(
        session,
        business.id,
        body.staff_id,
        starts_at.date(),
        minutes,
        _staff_schedules(session, business.id, body.staff_id),
        service_id=service.id,
        capacity=service.capacity or 1,
    )
    if starts_at not in available:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese horario ya no está disponible")
    resource = body.resource_name.strip() if body.resource_name else None
    if resource:
        clash = session.exec(
            select(Appointment.id).where(
                Appointment.business_id == business.id,
                Appointment.resource_name == resource,
                Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
                Appointment.starts_at < starts_at + timedelta(minutes=minutes),
                Appointment.ends_at > starts_at,
            )
        ).first()
        if clash is not None:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese recurso ya está ocupado")
    visits = _completed_visits(session, business.id, body.client_phone)  # type: ignore[arg-type]
    coupon_code = (body.coupon or "").strip()
    coupon_off = _coupon_percent(business, coupon_code, visits) if coupon_code else 0
    loyalty_off = _loyalty_percent(business, visits) or 0
    discount = max(coupon_off, loyalty_off)
    from app.models.package import take_package

    uses_package = bool(body.use_package)
    if uses_package and not take_package(session, business.id, body.client_phone):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="No quedan visitas en el paquete")

    appointment = Appointment(
        source="page",
        business_id=business.id,
        staff_id=body.staff_id,
        service_id=body.service_id,
        starts_at=starts_at,
        ends_at=starts_at + timedelta(minutes=minutes),
        client_name=body.client_name.strip(),
        client_phone=body.client_phone.strip(),
        client_email=str(body.client_email).lower() if body.client_email else None,
        notes=body.notes.strip() if body.notes else None,
        resource_name=resource,
        extra_label=", ".join(item.name for item in extras) or None,
        answers="\n".join(part for part in [f"Opción: {option['name']}" if option else "", body.answers.strip() if body.answers else ""] if part) or None,
        use_package=uses_package,
        reference_photos=json.dumps(body.reference_photos) if body.reference_photos else None,
        status=AppointmentStatus.scheduled,
        cancel_token=str(uuid.uuid4()),
        needs_approval=bool(business.approve_bookings),
    )
    if option and not service.variable_price:
        appointment.quoted_price = option["price"] + sum(item.price for item in extras if not item.variable_price)
    if discount and not uses_package:
        appointment.discount_percent = discount
        if not service.variable_price:
            base = option["price"] if option else service.price
            total = base + sum(item.price for item in extras if not item.variable_price)
            appointment.quoted_price = round(total * (1 - discount / 100), 2)
    owed = owed_deposit(business, service, None)
    if owed or (service.variable_price and business.deposit_percent and business.deposit_account):
        appointment.status = AppointmentStatus.awaiting_deposit
        appointment.deposit_amount = owed
    _remember_client(session, business.id, appointment.client_name, appointment.client_phone, appointment.client_email, appointment.notes)
    from app.routers.notices import add_notice, visit_when

    verb = "pidió" if appointment.needs_approval else "apartó" if appointment.status == AppointmentStatus.awaiting_deposit else "reservó"
    session.add(appointment)
    session.flush()
    add_notice(
        session,
        business.id,  # type: ignore[arg-type]
        f"{appointment.client_name} {verb} {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)}"
        + (f" y mandó {len(body.reference_photos)} foto(s) de referencia" if body.reference_photos else "")
        + (" · falta que la apruebes" if appointment.needs_approval else "")
        + f" #{appointment.id}",
        "new_booking",
    )
    session.commit()
    session.refresh(appointment)
    return to_appointment_read(appointment, service, member)
