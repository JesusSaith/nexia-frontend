from datetime import date, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from sqlmodel import Session, select

from app.core.images import IMAGE_TYPES_HINT, image_response, is_safe_data_image
from app.core.shop_note import closed_reason
from app.core.throttle import throttle
from app.core.clock import local_now, local_today
from app.core.spei import SENDER_CODES, clabe_ok, verify_transfer
from app.core.booking import format_timestamp, lock_staff, open_slots, release_expired_deposits
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.service import Service
from app.models.staff import Staff
from app.routers.businesses import _active_staff, _day_slots, _ensure_staff_does, _staff_schedules, reference_photos
from app.routers.notices import add_notice, visit_when
from pydantic import BaseModel, Field

from app.schemas.appointment import AppointmentReschedule, AvailabilitySlot, PublicAppointmentRead

router = APIRouter(prefix="/public/appointments", tags=["public-appointments"])


def _by_token(session: Session, token: str) -> tuple[Appointment, Business, Service, Staff]:
    appointment = session.exec(select(Appointment).where(Appointment.cancel_token == token)).first()
    if appointment is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    business = session.get(Business, appointment.business_id)
    service = session.get(Service, appointment.service_id)
    member = session.get(Staff, appointment.staff_id)
    if business is None or service is None or member is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    return appointment, business, service, member


def _read(appointment: Appointment, business: Business, service: Service, member: Staff) -> PublicAppointmentRead:
    now = local_now(business)
    return PublicAppointmentRead(
        client_name=appointment.client_name,
        business_name=business.name,
        business_slug=business.slug,
        google_review_url=business.google_review_url,
        address=business.address,
        latitude=business.latitude,
        map_embed=business.map_embed,
        longitude=business.longitude,
        logo_url=business.logo_url,
        primary_color=business.primary_color,
        service_id=appointment.service_id,
        service_name=service.name,
        staff_id=appointment.staff_id,
        staff_name=member.full_name,
        starts_at=format_timestamp(appointment.starts_at),
        ends_at=format_timestamp(appointment.ends_at),
        status=appointment.status,
        is_past=appointment.starts_at < now,
        is_cancelled=appointment.status == AppointmentStatus.cancelled,
        changes_locked=_locked(appointment, business, now),
        deposit_amount=appointment.deposit_amount,
        deposit_account=business.deposit_account,
        payment_proof=appointment.payment_proof,
        client_confirmed=appointment.client_confirmed,
        quoted_price=appointment.quoted_price,
        variable_price=service.variable_price,
        price_accepted=appointment.price_accepted,
        cancel_policy=business.cancel_policy,
        payment_url=business.payment_url,
        needs_approval=bool(appointment.needs_approval),
        spei_check=business.spei_check,
        paid_claim=bool(appointment.paid_claim),
    )


def _locked(appointment: Appointment, business: Business, now: datetime) -> bool:
    if business.cancel_hours is None or appointment.status != AppointmentStatus.scheduled:
        return False
    return appointment.starts_at - now < timedelta(hours=business.cancel_hours)


def _ensure_editable(appointment: Appointment, business: Business) -> None:
    if appointment.status == AppointmentStatus.cancelled:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita ya está cancelada")
    now = local_now(business)
    if appointment.starts_at < now:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita ya pasó")
    if appointment.status != AppointmentStatus.scheduled:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita ya no se puede cambiar")
    if _locked(appointment, business, now):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ya no se puede cambiar esta cita")


@router.get("/{token}", response_model=PublicAppointmentRead)
def read_public_appointment(token: str, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    appointment, business, service, member = _by_token(session, token)
    release_expired_deposits(session, business.id)  # type: ignore[arg-type]
    session.refresh(appointment)
    return _read(appointment, business, service, member)


class PaymentProof(BaseModel):
    image: str = Field(min_length=20, max_length=180000)


@router.post("/{token}/proof", response_model=PublicAppointmentRead)
def upload_payment_proof(token: str, body: PaymentProof, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    throttle(request, "token:proof", limit=10)
    appointment, business, service, member = _by_token(session, token)
    if appointment.status != AppointmentStatus.awaiting_deposit:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita no está esperando un anticipo")
    if not is_safe_data_image(body.image):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Sube una imagen {IMAGE_TYPES_HINT}")
    appointment.payment_proof = body.image
    add_notice(session, business.id, f"{appointment.client_name} envió el comprobante de {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}", "payment")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


class SpeiCheck(BaseModel):
    tracking: str = Field(min_length=6, max_length=30, pattern=r"^[A-Za-z0-9]+$")
    bank: str = Field(pattern=r"^\d{5}$")
    day: date
    amount: float = Field(gt=0, le=1_000_000)


@router.post("/{token}/spei", response_model=PublicAppointmentRead)
def verify_spei(token: str, body: SpeiCheck, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    """La clienta pone la clave de rastreo y Banxico confirma la transferencia: la cita queda pagada sola."""
    throttle(request, "token:spei", limit=6)  # cada intento consulta a Banxico
    appointment, business, service, member = _by_token(session, token)
    if appointment.status != AppointmentStatus.awaiting_deposit or not appointment.deposit_amount:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita no está esperando un anticipo")
    clabe = clabe_ok(business.deposit_account)
    if not business.spei_check or clabe is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Este negocio revisa los pagos a mano. Sube la captura de tu transferencia.")
    if body.bank not in SENDER_CODES:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Elige el banco desde el que transferiste")
    today = local_today(business)
    if body.day > today or body.day < today - timedelta(days=7):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="La fecha de la transferencia debe ser de esta semana")
    tracking = body.tracking.upper()
    reused = session.exec(select(Appointment.id).where(Appointment.business_id == business.id, Appointment.spei_tracking == tracking)).first()
    if reused is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa clave de rastreo ya se usó para otra cita")
    result = verify_transfer(body.day, tracking, body.bank, clabe, body.amount)
    if result.status == "unavailable":
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Banxico no responde ahora. Sube la captura de tu transferencia y el negocio la revisa.")
    if result.status == "not_found":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Banxico aún no encuentra esa transferencia. Revisa la clave, el banco y el monto; a veces tarda unos minutos.")
    if result.account and not result.account.endswith(clabe[-10:]):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa transferencia llegó a otra cuenta")
    if (result.amount or 0) + 0.01 < appointment.deposit_amount:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=f"La transferencia es por menos del anticipo (${appointment.deposit_amount:.2f})")
    appointment.status = AppointmentStatus.scheduled
    appointment.spei_tracking = tracking
    add_notice(session, business.id, f"Banxico confirmó el anticipo de {appointment.client_name} (${result.amount:.2f}) para {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}", "payment")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.post("/{token}/accept-price", response_model=PublicAppointmentRead)
def accept_price(token: str, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    throttle(request, "token:price", limit=20)
    appointment, business, service, member = _by_token(session, token)
    if appointment.quoted_price is None or appointment.status == AppointmentStatus.cancelled:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Aún no hay un precio para aceptar")
    appointment.price_accepted = True
    add_notice(session, business.id, f"{appointment.client_name} aceptó el precio de {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.post("/{token}/paid", response_model=PublicAppointmentRead)
def mark_public_paid(token: str, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    throttle(request, "token:paid", limit=20)
    appointment, business, service, member = _by_token(session, token)
    if appointment.status != AppointmentStatus.awaiting_deposit:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita no está esperando el anticipo")
    # Solo es su palabra: la cita sigue esperando el anticipo hasta que la dueña revise su cuenta y lo acepte.
    if not appointment.paid_claim:
        appointment.paid_claim = True
        add_notice(session, business.id, f"{appointment.client_name} dice que ya pagó el anticipo de {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)}: revisa tu cuenta y acéptala #{appointment.id}", "payment")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.post("/{token}/confirm", response_model=PublicAppointmentRead)
def confirm_public_appointment(token: str, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    throttle(request, "token:confirm", limit=20)
    appointment, business, service, member = _by_token(session, token)
    if appointment.status != AppointmentStatus.scheduled:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esta cita no se puede confirmar")
    appointment.client_confirmed = True
    add_notice(session, business.id, f"{appointment.client_name} confirmó que sí va a {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}", "confirmed")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.post("/{token}/cancel", response_model=PublicAppointmentRead)
def cancel_public_appointment(token: str, request: Request, session: Session = Depends(get_session)) -> PublicAppointmentRead:
    throttle(request, "token:cancel", limit=20)
    appointment, business, service, member = _by_token(session, token)
    _ensure_editable(appointment, business)
    appointment.status = AppointmentStatus.cancelled
    if appointment.use_package:
        from app.models.package import give_package

        give_package(session, business.id, appointment.client_phone)  # type: ignore[arg-type]
    add_notice(session, business.id, f"{appointment.client_name} canceló {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}", "cancelled")  # type: ignore[arg-type]
    from app.models.waitlist import notify_waitlist

    notify_waitlist(session, appointment)
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.get("/{token}/slots", response_model=list[AvailabilitySlot])
def read_reschedule_slots(
    token: str,
    request: Request,
    day: Annotated[date, Query(alias="date")],
    session: Session = Depends(get_session),
) -> list[AvailabilitySlot]:
    """Horarios a los que se puede mover esta cita: con su duración real y sin contar su propio horario."""
    throttle(request, "token:slots", limit=60)
    appointment, business, service, _member = _by_token(session, token)
    if appointment.status not in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit) or appointment.starts_at < local_now(business):
        return []
    minutes = max(int((appointment.ends_at - appointment.starts_at).total_seconds() // 60), 1)
    slots = _day_slots(session, business, service, appointment.staff_id, day, [], None, None, minutes_override=minutes, ignore_id=appointment.id)
    return [AvailabilitySlot(starts_at=format_timestamp(slot), staff_id=appointment.staff_id) for slot in slots]


@router.post("/{token}/reschedule", response_model=PublicAppointmentRead)
def reschedule_public_appointment(
    token: str,
    body: AppointmentReschedule,
    request: Request,
    session: Session = Depends(get_session),
) -> PublicAppointmentRead:
    throttle(request, "token:reschedule", limit=20)
    appointment, business, service, member = _by_token(session, token)
    _ensure_editable(appointment, business)
    staff_id = body.staff_id if body.staff_id is not None else appointment.staff_id
    member = _active_staff(session, appointment.business_id, staff_id)
    # Se conserva la duración real de la cita (opción elegida y extras), no la del servicio base.
    minutes = max(int((appointment.ends_at - appointment.starts_at).total_seconds() // 60), 1)
    if staff_id != appointment.staff_id:
        _ensure_staff_does(session, appointment.business_id, staff_id, [service.id])  # type: ignore[list-item]
    starts_at = datetime.combine(body.new_date, body.new_time).replace(microsecond=0)
    if starts_at.date() > local_today(business) + timedelta(days=business.max_days_ahead or 90):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese día está fuera del calendario")
    if starts_at < local_now(business) + timedelta(hours=business.min_notice_hours or 0):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Elige un horario con más anticipación")
    if reason := closed_reason(business, starts_at.date()):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=reason)
    lock_staff(session, staff_id)
    available = open_slots(
        session,
        appointment.business_id,
        staff_id,
        starts_at.date(),
        minutes,
        _staff_schedules(session, appointment.business_id, staff_id),
        ignore_id=appointment.id,
        service_id=service.id,
        capacity=service.capacity or 1,
    )
    if starts_at not in available:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese horario ya no está disponible")
    appointment.staff_id = staff_id
    appointment.starts_at = starts_at
    appointment.ends_at = starts_at + timedelta(minutes=minutes)
    add_notice(session, business.id, f"{appointment.client_name} cambió {service.name} con {member.full_name.split()[0]} a {visit_when(starts_at)} #{appointment.id}", "rescheduled")  # type: ignore[arg-type]
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(appointment, business, service, member)


@router.get("/{token}/photos/{index}")
def read_reference_photo(token: str, index: int, session: Session = Depends(get_session)) -> Response:
    """Foto de referencia como imagen normal, para abrirla desde el enlace que llega por WhatsApp."""
    appointment = session.exec(select(Appointment).where(Appointment.cancel_token == token)).first()
    photos = reference_photos(appointment) if appointment else []
    if not 0 <= index < len(photos):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Foto no encontrada")
    # Solo PNG, JPG, WebP o GIF y con encabezados que impiden ejecutarlo (ver app/core/images.py).
    image = image_response(photos[index], "private, max-age=86400")
    if image is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Foto no encontrada")
    return image
