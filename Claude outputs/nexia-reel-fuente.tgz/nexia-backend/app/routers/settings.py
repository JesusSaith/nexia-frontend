import json
from typing import Annotated

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.core.alerts import ALERT_KINDS, alerts_of, pack_alerts
from app.core.catalog import STAFF_LABEL_BY_KIND
from app.core.throttle import throttle
from app.core.map_link import read_map_input
from app.core.readiness import readiness
from app.core.clock import DEFAULT_TIMEZONE, local_now
from app.db.database import get_session
from app.models.appointment import Appointment
from app.models.business import Business
from app.models.client import Client
from app.models.product import Expense
from app.models.service import Service
from app.models.staff import Staff
from app.models.business_hour import BusinessHour
from app.models.user import User
from app.routers.auth import ManagerDep
from app.core.whatsapp import whatsapp_ready
from app.core.payment_methods import methods_of, pack_methods
from app.core.shop_note import closures_of, pack_closures
from app.schemas.business import BusinessHourRead, BusinessHourUpdate, BusinessSettingsRead, BusinessSettingsUpdate, gallery_list, templates_dict
from app.utils.storage import save_logo

router = APIRouter()

SessionDep = Annotated[Session, Depends(get_session)]


def _business(session: Session, user: User) -> Business:
    business = session.get(Business, user.business_id)
    if business is None or business.id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    return business


def _hours(session: Session, business_id: int) -> list[BusinessHour]:
    return list(
        session.exec(
            select(BusinessHour)
            .where(BusinessHour.business_id == business_id)
            .order_by(BusinessHour.day_of_week)
        ).all()
    )


def _read(business: Business, hours: list[BusinessHour]) -> BusinessSettingsRead:
    return BusinessSettingsRead(
        id=business.id,  # type: ignore[arg-type]
        name=business.name,
        slug=business.slug,
        description=business.description,
        business_kind=business.business_kind,
        primary_color=business.primary_color,
        canvas_color=business.canvas_color,
        logo_url=business.logo_url,
        phone=business.phone,
        email=business.email,
        address=business.address,
        latitude=business.latitude,
        longitude=business.longitude,
        map_embed=business.map_embed,
        instagram=business.instagram,
        facebook=business.facebook,
        cancel_hours=business.cancel_hours,
        deposit_amount=business.deposit_amount,
        deposit_percent=business.deposit_percent,
        deposit_account=business.deposit_account,
        deposit_hold_hours=business.deposit_hold_hours,
        buffer_minutes=business.buffer_minutes or 0,
        staff_label=business.staff_label or "Colaborador",
        min_notice_hours=business.min_notice_hours or 0,
        max_days_ahead=business.max_days_ahead or 90,
        cancel_policy=business.cancel_policy,
        resources=business.resources,
        payment_url=business.payment_url,
        google_review_url=business.google_review_url,
        accent_color=business.accent_color,
        button_shape=business.button_shape or "pill",
        button_fill=business.button_fill or "solid",
        font_style=business.font_style or "modern",
        header_style=business.header_style or "cover",
        privacy_notice=business.privacy_notice,
        loyalty_every=business.loyalty_every,
        loyalty_percent=business.loyalty_percent,
        coupons=business.coupons,
        timezone=business.timezone or DEFAULT_TIMEZONE,
        email_alerts=[kind for kind in ALERT_KINDS if kind in alerts_of(business)],
        bookings_paused=bool(business.bookings_paused),
        closures=closures_of(business),
        payment_methods=methods_of(business),
        approve_bookings=bool(business.approve_bookings),
        uses_commissions=business.uses_commissions is not False,
        auto_reminders=bool(business.auto_reminders),
        reminder_hours=business.reminder_hours or 24,
        auto_return=bool(business.auto_return),
        whatsapp_ready=whatsapp_ready(),
        spei_check=business.spei_check,
        promo_text=business.promo_text,
        promo_until=business.promo_until,
        gallery=gallery_list(business.gallery),
        message_templates=templates_dict(business.message_templates),
        hours=[
            BusinessHourRead(
                id=row.id,  # type: ignore[arg-type]
                day_of_week=row.day_of_week,
                open_time=row.open_time,
                close_time=row.close_time,
                is_closed=row.is_closed,
            )
            for row in hours
            if row.id is not None
        ],
    )


@router.get("/business", response_model=BusinessSettingsRead)
def read_business_settings(session: SessionDep, current_user: ManagerDep) -> BusinessSettingsRead:
    business = _business(session, current_user)
    return _read(business, _hours(session, business.id))  # type: ignore[arg-type]


@router.get("/readiness")
def read_readiness(session: SessionDep, current_user: ManagerDep) -> dict:
    """Qué le falta al negocio; lo usan Inicio, Mi negocio y Configuración."""
    return readiness(session, _business(session, current_user))


@router.post("/readiness/shared", status_code=status.HTTP_204_NO_CONTENT)
def mark_link_shared(session: SessionDep, current_user: ManagerDep) -> None:
    business = _business(session, current_user)
    if not business.link_shared:
        business.link_shared = True
        session.add(business)
        session.commit()


@router.patch("/business", response_model=BusinessSettingsRead)
def update_business_settings(
    body: BusinessSettingsUpdate,
    session: SessionDep,
    current_user: ManagerDep,
) -> BusinessSettingsRead:
    business = _business(session, current_user)
    changes = body.model_dump(exclude_unset=True)
    if "email_alerts" in changes:
        business.email_alerts = pack_alerts(changes.pop("email_alerts") or [])
    if "message_templates" in changes:
        texts = changes.pop("message_templates") or {}
        business.message_templates = json.dumps(texts, ensure_ascii=False) if texts else None
    if "closures" in changes:
        business.closures = pack_closures([row.model_dump(by_alias=True) for row in body.closures or []])
        changes.pop("closures")
    if "payment_methods" in changes:
        business.payment_methods = pack_methods(changes.pop("payment_methods") or [])
    if "gallery" in changes:
        photos = changes.pop("gallery") or []
        business.gallery = json.dumps(photos) if photos else None
    for key, value in changes.items():
        if isinstance(value, str):
            value = value.strip()
        if key == "phone":
            value = value or ""
        elif key in {"timezone", "name"} and not value:
            continue
        elif value == "":
            value = None
        setattr(business, key, value)
    # Cambiar el giro ajusta cómo se llama al personal, salvo que también venga una etiqueta propia.
    if "business_kind" in changes and "staff_label" not in changes:
        business.staff_label = STAFF_LABEL_BY_KIND.get(business.business_kind or "", "Colaborador")
    session.add(business)
    session.commit()
    session.refresh(business)
    return _read(business, _hours(session, business.id))  # type: ignore[arg-type]


class MapLinkBody(BaseModel):
    text: str = Field(min_length=1, max_length=3000)


class MapLinkRead(BaseModel):
    latitude: float | None = None
    longitude: float | None = None
    # La dirección del mapa incrustado, si pegó el código "Insertar un mapa" de Google.
    embed: str | None = None


@router.post("/map-link", response_model=MapLinkRead)
def read_map_link(body: MapLinkBody, request: Request, current_user: ManagerDep) -> MapLinkRead:
    """Convierte lo que pegó la dueña (iframe de Google Maps o enlace, también los cortos) en el punto del local."""
    throttle(request, "map_link", limit=20)
    found = read_map_input(body.text)
    if found["latitude"] is None and found["embed"] is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No pudimos leer ese enlace. Abre tu local en Google Maps, toca Compartir y copia el enlace, o pega el código de \"Insertar un mapa\".",
        )
    return MapLinkRead(**found)


@router.put("/hours", response_model=list[BusinessHourRead])
def replace_business_hours(
    body: list[BusinessHourUpdate],
    session: SessionDep,
    current_user: ManagerDep,
) -> list[BusinessHourRead]:
    business = _business(session, current_user)
    days = [item.day_of_week for item in body]
    if len(days) != len(set(days)):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Cada día solo puede aparecer una vez")
    for row in _hours(session, business.id):  # type: ignore[arg-type]
        session.delete(row)
    session.flush()
    for item in body:
        session.add(
            BusinessHour(
                business_id=business.id,  # type: ignore[arg-type]
                day_of_week=item.day_of_week,
                open_time=item.open_time,
                close_time=item.close_time,
                is_closed=item.is_closed,
            )
        )
    session.commit()
    saved = _hours(session, business.id)  # type: ignore[arg-type]
    return [
        BusinessHourRead(
            id=row.id,  # type: ignore[arg-type]
            day_of_week=row.day_of_week,
            open_time=row.open_time,
            close_time=row.close_time,
            is_closed=row.is_closed,
        )
        for row in saved
        if row.id is not None
    ]


@router.post("/logo", response_model=BusinessSettingsRead)
async def upload_business_logo(
    session: SessionDep,
    current_user: ManagerDep,
    file: UploadFile = File(...),
) -> BusinessSettingsRead:
    business = _business(session, current_user)
    content = await file.read()
    try:
        business.logo_url = save_logo(content, file.filename or "")
    except ValueError as error:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error)) from None
    session.add(business)
    session.commit()
    session.refresh(business)
    return _read(business, _hours(session, business.id))  # type: ignore[arg-type]


@router.get("/backup")
def download_backup(session: SessionDep, current_user: ManagerDep) -> dict:
    business_id = current_user.business_id
    visits = session.exec(select(Appointment).where(Appointment.business_id == business_id)).all()
    return {
        "exported_at": local_now().isoformat(),
        "appointments": [
            {
                "client_name": item.client_name,
                "client_phone": item.client_phone,
                "starts_at": item.starts_at.isoformat(),
                "status": item.status.value if hasattr(item.status, "value") else item.status,
                "quoted_price": item.quoted_price,
            }
            for item in visits
        ],
        "clients": [
            {"full_name": item.full_name, "phone": item.phone, "email": item.email}
            for item in session.exec(select(Client).where(Client.business_id == business_id)).all()
        ],
        "services": [
            {"name": item.name, "price": item.price, "duration_minutes": item.duration_minutes}
            for item in session.exec(select(Service).where(Service.business_id == business_id)).all()
        ],
        "staff": [
            {"full_name": item.full_name, "phone": item.phone, "commission_percent": item.commission_percent}
            for item in session.exec(select(Staff).where(Staff.business_id == business_id)).all()
        ],
        "expenses": [
            {"name": item.name, "amount": item.amount, "kind": item.kind, "cadence": item.cadence, "pay_day": item.pay_day}
            for item in session.exec(select(Expense).where(Expense.business_id == business_id)).all()
        ],
    }


class SlugBody(BaseModel):
    slug: str = Field(min_length=3, max_length=60, pattern=r"^[a-z0-9]+(-[a-z0-9]+)*$")


@router.put("/slug", response_model=BusinessSettingsRead)
def change_slug(body: SlugBody, session: SessionDep, current_user: ManagerDep) -> BusinessSettingsRead:
    """Cambia el enlace (/salon-ana). El anterior se guarda y sigue funcionando (QR impresos)."""
    from app.routers.auth import RESERVED_SLUGS

    business = _business(session, current_user)
    slug = body.slug
    if slug == business.slug:
        return read_business_settings(session, current_user)
    if slug in RESERVED_SLUGS:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese nombre está reservado. Prueba otro.")
    taken = session.exec(select(Business).where(Business.id != business.id)).all()
    if any(row.slug == slug or slug in (row.old_slugs or "").split(",") for row in taken):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese enlace ya lo usa otro negocio.")
    old = [item for item in (business.old_slugs or "").split(",") if item and item != slug]
    business.old_slugs = ",".join([*old, business.slug])[-1000:]
    business.slug = slug
    session.add(business)
    session.commit()
    return read_business_settings(session, current_user)
