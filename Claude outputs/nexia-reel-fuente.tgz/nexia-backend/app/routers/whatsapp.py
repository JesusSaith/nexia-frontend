"""Webhook de la API oficial de WhatsApp: los botones "Confirmo" y "Cambiar" del recordatorio.

Meta llama GET una vez para verificar (hub.challenge) y POST con cada mensaje que llega.
El payload de cada botón es "confirm:<token>" o "change:<token>" (lo pone auto_messages.py).
"""

import hashlib
import hmac
import json

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from sqlmodel import Session, select

from app.core.alerts import _app
from app.core.config import settings
from app.core.whatsapp import send_text
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.service import Service
from app.routers.notices import add_notice, visit_when

router = APIRouter(prefix="/whatsapp", tags=["whatsapp"])


@router.get("/webhook")
def verify_webhook(
    mode: str = Query(default="", alias="hub.mode"),
    token: str = Query(default="", alias="hub.verify_token"),
    challenge: str = Query(default="", alias="hub.challenge"),
) -> Response:
    if mode == "subscribe" and settings.WHATSAPP_VERIFY_TOKEN and hmac.compare_digest(token, settings.WHATSAPP_VERIFY_TOKEN):
        return Response(content=challenge, media_type="text/plain")
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Token inválido")


@router.post("/webhook")
async def receive_webhook(request: Request, session: Session = Depends(get_session)) -> dict:
    raw = await request.body()
    if settings.WHATSAPP_APP_SECRET:
        expected = "sha256=" + hmac.new(settings.WHATSAPP_APP_SECRET.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, request.headers.get("X-Hub-Signature-256", "")):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Firma inválida")
    try:
        body = json.loads(raw or b"{}")
    except ValueError:
        return {"ok": True}
    for payload in _button_payloads(body):
        handle_button(session, payload)
    return {"ok": True}


def _button_payloads(body: dict) -> list[str]:
    found = []
    for entry in body.get("entry") or []:
        for change in entry.get("changes") or []:
            for message in (change.get("value") or {}).get("messages") or []:
                if message.get("type") == "button":
                    found.append((message.get("button") or {}).get("payload") or "")
                elif message.get("type") == "interactive":
                    found.append(((message.get("interactive") or {}).get("button_reply") or {}).get("id") or "")
    return [item for item in found if ":" in item]


def handle_button(session: Session, payload: str) -> None:
    action, _, token = payload.partition(":")
    appointment = session.exec(select(Appointment).where(Appointment.cancel_token == token)).first()
    if appointment is None:
        return
    business = session.get(Business, appointment.business_id)
    service = session.get(Service, appointment.service_id)
    if business is None:
        return
    manage = f"{_app()}/{business.slug}/manage/{token}"
    if action == "confirm" and appointment.status == AppointmentStatus.scheduled:
        if not appointment.client_confirmed:
            appointment.client_confirmed = True
            session.add(appointment)
            add_notice(session, business.id, f"{appointment.client_name} confirmó por WhatsApp que sí va a {service.name if service else 'su cita'} {visit_when(appointment.starts_at)} #{appointment.id}", "confirmed")  # type: ignore[arg-type]
            session.commit()
        send_text(appointment.client_phone, f"¡Gracias! Tu cita quedó confirmada. Si algo cambia, aquí la puedes mover: {manage}")
    elif action == "change":
        send_text(appointment.client_phone, f"Claro. Aquí eliges otro día u hora, o la cancelas: {manage}")
