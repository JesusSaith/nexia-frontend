from collections import defaultdict
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, select

from app.core.security import hash_password
from app.db.database import get_session
from app.models.service import Service
from app.models.staff import Staff
from app.models.staff_service import StaffService
from app.models.user import User, UserRole
from app.routers.auth import BusinessUserDep, CurrentUserDep, ManagerDep
from app.schemas.staff import (
    StaffAccountCreate,
    StaffCreate,
    StaffProfileUpdate,
    StaffResponse,
    StaffServicesUpdate,
    StaffUpdate,
)

router = APIRouter(prefix="/staff", tags=["staff"])

SessionDep = Annotated[Session, Depends(get_session)]


def _business_id(user: User) -> int:
    if user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return user.business_id


def _owned_staff(session: Session, staff_id: int, business_id: int) -> Staff:
    member = session.get(Staff, staff_id)
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integrante no encontrado")
    return member


def _service_ids_for(session: Session, business_id: int, staff_ids: list[int]) -> dict[int, list[int]]:
    if not staff_ids:
        return {}
    rows = session.exec(
        select(StaffService).where(
            StaffService.business_id == business_id,
            StaffService.staff_id.in_(staff_ids),  # type: ignore[attr-defined]
        )
    ).all()
    grouped: dict[int, list[int]] = defaultdict(list)
    for row in rows:
        grouped[row.staff_id].append(row.service_id)
    for service_ids in grouped.values():
        service_ids.sort()
    return grouped


def _to_response(member: Staff, service_ids: list[int], private: bool = True) -> StaffResponse:
    """`private=False` quita lo que solo debe ver la dueña: comisión, meta, contacto y cuenta."""
    if member.id is None:
        raise RuntimeError("Staff id is missing")
    if not private:
        return StaffResponse(
            id=member.id,
            business_id=member.business_id,
            full_name=member.full_name,
            email=None,
            phone=None,
            role_title=member.role_title,
            is_active=member.is_active,
            user_id=None,
            avatar_url=member.avatar_url,
            bio=member.bio,
            slot_times=member.slot_times,
            commission_percent=0,
            goal=None,
            color=member.color or None,
            tier_amount=None,
            tier_percent=None,
            service_ids=service_ids,
        )
    return StaffResponse(
        id=member.id,
        business_id=member.business_id,
        full_name=member.full_name,
        email=member.email,
        phone=member.phone,
        role_title=member.role_title,
        is_active=member.is_active,
        user_id=member.user_id,
        avatar_url=member.avatar_url,
        bio=member.bio,
        slot_times=member.slot_times,
        commission_percent=member.commission_percent or 0,
        goal=member.goal,
        color=member.color or None,
        tier_amount=member.tier_amount,
        tier_percent=member.tier_percent,
        service_ids=service_ids,
    )


def _respond(session: Session, member: Staff) -> StaffResponse:
    if member.id is None:
        raise RuntimeError("Staff id is missing")
    service_ids = _service_ids_for(session, member.business_id, [member.id]).get(member.id, [])
    return _to_response(member, service_ids)


def _profile_for_user(session: Session, user: User) -> Staff:
    member = session.exec(select(Staff).where(Staff.user_id == user.id)).first()
    if member is None or (user.business_id is not None and member.business_id != user.business_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perfil de colaborador no encontrado")
    return member


@router.get("/", response_model=list[StaffResponse])
def list_staff(session: SessionDep, current_user: BusinessUserDep) -> list[StaffResponse]:
    business_id = _business_id(current_user)
    members = list(
        session.exec(select(Staff).where(Staff.business_id == business_id).order_by(Staff.full_name)).all()
    )
    grouped = _service_ids_for(session, business_id, [member.id for member in members if member.id is not None])
    private = current_user.role in {UserRole.owner, UserRole.admin}
    return [_to_response(member, grouped.get(member.id or 0, []), private) for member in members]


@router.post("/", response_model=StaffResponse, status_code=status.HTTP_201_CREATED)
def create_staff(body: StaffCreate, session: SessionDep, current_user: ManagerDep) -> StaffResponse:
    member = Staff(
        business_id=_business_id(current_user),
        full_name=body.full_name.strip(),
        email=str(body.email).lower() if body.email else None,
        phone=body.phone.strip() if body.phone else None,
        role_title=body.role_title.strip(),
        is_active=body.is_active,
    )
    session.add(member)
    session.commit()
    session.refresh(member)
    return _respond(session, member)


@router.get("/me/profile", response_model=StaffResponse)
def read_my_profile(session: SessionDep, current_user: CurrentUserDep) -> StaffResponse:
    return _respond(session, _profile_for_user(session, current_user))


@router.put("/me/profile", response_model=StaffResponse)
def update_my_profile(
    body: StaffProfileUpdate,
    session: SessionDep,
    current_user: CurrentUserDep,
) -> StaffResponse:
    member = _profile_for_user(session, current_user)
    changes = body.model_dump(exclude_unset=True)
    if "full_name" in changes and isinstance(changes["full_name"], str):
        changes["full_name"] = changes["full_name"].strip()
    if "phone" in changes and isinstance(changes["phone"], str):
        changes["phone"] = changes["phone"].strip() or None
    if "avatar_url" in changes and isinstance(changes["avatar_url"], str):
        changes["avatar_url"] = changes["avatar_url"].strip() or None
    if "bio" in changes and isinstance(changes["bio"], str):
        changes["bio"] = changes["bio"].strip() or None
    member.sqlmodel_update(changes)
    session.add(member)
    session.commit()
    session.refresh(member)
    return _respond(session, member)


@router.post("/{staff_id}/account", response_model=StaffResponse, status_code=status.HTTP_201_CREATED)
def create_staff_account(
    staff_id: int,
    body: StaffAccountCreate,
    session: SessionDep,
    current_user: ManagerDep,
) -> StaffResponse:
    business_id = _business_id(current_user)
    member = _owned_staff(session, staff_id, business_id)
    if member.user_id is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Este colaborador ya tiene cuenta")

    email = str(body.email).lower()
    existing = session.exec(select(User).where(User.email == email)).first()
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="El correo ya está registrado")

    account = User(
        email=email,
        hashed_password=hash_password(body.password),
        role=UserRole.staff,
        business_id=business_id,
        full_name=member.full_name,
    )
    session.add(account)
    try:
        session.flush()
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="El correo ya está registrado") from None

    member.user_id = account.id
    session.add(member)
    session.commit()
    session.refresh(member)
    return _respond(session, member)


@router.put("/{staff_id}/services", response_model=StaffResponse)
def replace_staff_services(
    staff_id: int,
    body: StaffServicesUpdate,
    session: SessionDep,
    current_user: ManagerDep,
) -> StaffResponse:
    business_id = _business_id(current_user)
    member = _owned_staff(session, staff_id, business_id)
    service_ids = list(dict.fromkeys(body.service_ids))
    if service_ids:
        found = session.exec(
            select(Service.id).where(Service.business_id == business_id, Service.id.in_(service_ids))  # type: ignore[attr-defined]
        ).all()
        if len(found) != len(service_ids):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Servicio no encontrado")

    current_links = session.exec(
        select(StaffService).where(StaffService.staff_id == staff_id, StaffService.business_id == business_id)
    ).all()
    for link in current_links:
        session.delete(link)
    for service_id in service_ids:
        session.add(StaffService(staff_id=staff_id, service_id=service_id, business_id=business_id))
    session.commit()
    return _respond(session, member)


@router.put("/{staff_id}", response_model=StaffResponse)
def update_staff(
    staff_id: int,
    body: StaffUpdate,
    session: SessionDep,
    current_user: ManagerDep,
) -> StaffResponse:
    member = _owned_staff(session, staff_id, _business_id(current_user))
    changes = body.model_dump(exclude_unset=True)
    if "full_name" in changes and isinstance(changes["full_name"], str):
        changes["full_name"] = changes["full_name"].strip()
    if "role_title" in changes and isinstance(changes["role_title"], str):
        changes["role_title"] = changes["role_title"].strip()
    if "phone" in changes and isinstance(changes["phone"], str):
        changes["phone"] = changes["phone"].strip() or None
    if "email" in changes and changes["email"] is not None:
        changes["email"] = str(changes["email"]).lower()
    if "avatar_url" in changes and isinstance(changes["avatar_url"], str):
        changes["avatar_url"] = changes["avatar_url"].strip() or None
    if "bio" in changes and isinstance(changes["bio"], str):
        changes["bio"] = changes["bio"].strip() or None
    member.sqlmodel_update(changes)
    session.add(member)
    session.commit()
    session.refresh(member)
    return _respond(session, member)


@router.delete("/{staff_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_staff(staff_id: int, session: SessionDep, current_user: ManagerDep) -> Response:
    member = _owned_staff(session, staff_id, _business_id(current_user))
    member.is_active = False
    session.add(member)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
