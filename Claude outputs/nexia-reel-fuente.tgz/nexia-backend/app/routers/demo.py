"""Datos de ejemplo para demos y para arrancar rápido: servicios del giro, equipo, clientas y citas."""

import json
from datetime import datetime, time, timedelta

from fastapi import APIRouter, HTTPException, status
from sqlmodel import select

from app.core.clock import local_today
from app.core.catalog import CATALOG_BY_KIND, catalog_for
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.client import Client
from app.models.schedule import Schedule
from app.models.service import Service
from app.models.staff import Staff
from app.models.staff_service import StaffService
from app.routers.auth import ManagerDep
from app.routers.settings import SessionDep

router = APIRouter(tags=["demo"])

PEOPLE = [("Ana López", "Especialista"), ("Carla Ruiz", "Especialista")]
CLIENTS = [("María García", "5511112222"), ("Laura Hernández", "5522223333"), ("Sofía Martínez", "5533334444"), ("Daniela Torres", "5544445555"), ("Valeria Ramírez", "5555556666")]


def _business(session: SessionDep, user: ManagerDep) -> Business:
    business = session.get(Business, user.business_id) if user.business_id else None
    if business is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    return business


@router.get("/demo")
def demo_status(session: SessionDep, current_user: ManagerDep) -> dict[str, bool]:
    return {"loaded": bool(_business(session, current_user).demo_ids)}


@router.post("/demo", status_code=status.HTTP_201_CREATED)
def load_demo(session: SessionDep, current_user: ManagerDep) -> dict[str, int]:
    business = _business(session, current_user)
    if business.demo_ids:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ya cargaste los datos de ejemplo")
    bid = business.id
    ids: dict[str, list[int]] = {"services": [], "activated": [], "staff": [], "clients": [], "appointments": []}
    # Si el servicio ya existe (p. ej. los sugeridos al registrarse, apagados) se reutiliza y se enciende
    # en vez de duplicarlo; al quitar el ejemplo se vuelve a apagar.
    existing = {row.name: row for row in session.exec(select(Service).where(Service.business_id == bid)).all()}
    services: list[Service] = []
    created: list[Service] = []
    for n, m, p, c in catalog_for(business) or CATALOG_BY_KIND["belleza"]:
        row = existing.get(n)
        if row is None:
            row = Service(business_id=bid, name=n, duration_minutes=m, price=p, category=c)
            created.append(row)
        elif not row.is_active:
            row.is_active = True
            ids["activated"].append(row.id)  # type: ignore[arg-type]
        services.append(row)
    people = [Staff(business_id=bid, full_name=n, role_title=business.staff_label or r) for n, r in PEOPLE]
    clients = [Client(business_id=bid, full_name=n, phone=ph) for n, ph in CLIENTS]
    session.add_all([*services, *people, *clients])
    session.flush()
    for member in people:
        for service in services:
            session.add(StaffService(staff_id=member.id, service_id=service.id, business_id=bid))
        for day in range(6):  # lunes a sábado, 10 a 19
            session.add(Schedule(business_id=bid, staff_id=member.id, day_of_week=day, start_time="10:00", end_time="19:00"))
    # Citas: pasadas cobradas (alimentan reportes) y próximas (llenan la agenda).
    today = local_today(business)
    plan = [(-14, 11, AppointmentStatus.completed), (-10, 13, AppointmentStatus.completed), (-7, 16, AppointmentStatus.completed),
            (-3, 12, AppointmentStatus.completed), (-2, 17, AppointmentStatus.no_show), (0, 11, AppointmentStatus.scheduled),
            (0, 15, AppointmentStatus.scheduled), (1, 12, AppointmentStatus.scheduled), (1, 16, AppointmentStatus.scheduled),
            (3, 13, AppointmentStatus.scheduled)]
    for index, (offset, hour, state) in enumerate(plan):
        service = services[index % len(services)]
        client = clients[index % len(clients)]
        start = datetime.combine(today + timedelta(days=offset), time(hour))
        session.add(Appointment(
            business_id=bid, staff_id=people[index % 2].id, service_id=service.id, starts_at=start,
            ends_at=start + timedelta(minutes=service.duration_minutes), client_name=client.full_name,
            client_phone=client.phone, status=state, client_confirmed=index % 3 == 0,
            payment_method="efectivo" if state == AppointmentStatus.completed and index % 2 else ("transferencia" if state == AppointmentStatus.completed else None),
        ))
    session.flush()
    ids["services"] = [s.id for s in created]  # type: ignore[misc]
    ids["staff"] = [p.id for p in people]  # type: ignore[misc]
    ids["clients"] = [c.id for c in clients]  # type: ignore[misc]
    ids["appointments"] = [a.id for a in session.exec(select(Appointment).where(
        Appointment.business_id == bid, Appointment.staff_id.in_(ids["staff"]))).all()]  # type: ignore[attr-defined]
    business.demo_ids = json.dumps(ids)
    session.add(business)
    session.commit()
    return {key: len(value) for key, value in ids.items()}


@router.delete("/demo", status_code=status.HTTP_204_NO_CONTENT)
def clear_demo(session: SessionDep, current_user: ManagerDep) -> None:
    business = _business(session, current_user)
    ids = json.loads(business.demo_ids or "{}")
    staff_ids = ids.get("staff", [])
    # Todo lo que quedó en la agenda de las colaboradoras de ejemplo también se va (incluye citas de prueba).
    for row in session.exec(select(Appointment).where(Appointment.business_id == business.id, Appointment.staff_id.in_(staff_ids))).all():  # type: ignore[attr-defined]
        session.delete(row)
    for model, key in ((StaffService, None), (Schedule, None)):
        for row in session.exec(select(model).where(model.business_id == business.id, model.staff_id.in_(staff_ids))).all():  # type: ignore[attr-defined]
            session.delete(row)
    session.flush()
    for model, key in ((Staff, "staff"), (Service, "services"), (Client, "clients")):
        for row_id in ids.get(key, []):
            row = session.get(model, row_id)
            if row is None or row.business_id != business.id:
                continue
            used = model is Service and session.exec(select(Appointment.id).where(Appointment.service_id == row_id)).first()
            if used:
                row.is_active = False  # lo usó una cita real: se oculta en vez de borrarse
                session.add(row)
            else:
                session.delete(row)
    for row_id in ids.get("activated", []):
        row = session.get(Service, row_id)
        if row is not None and row.business_id == business.id:
            row.is_active = False
            session.add(row)
    business.demo_ids = None
    session.add(business)
    session.commit()
