from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlmodel import Session, col, select

from app.core.throttle import throttle
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.review import Review
from app.routers.auth import BusinessUserDep, ManagerDep
from app.schemas.review import ReviewCreate, ReviewRead

router = APIRouter(prefix="/reviews", tags=["reviews"])

SessionDep = Annotated[Session, Depends(get_session)]


def _business_id(current_user: BusinessUserDep) -> int:
    if current_user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return current_user.business_id


def _active_business(session: Session, slug: str) -> Business:
    business = session.exec(
        select(Business).where(Business.slug == slug, Business.is_active.is_(True))
    ).first()
    if business is None:
        # Un enlace viejo (antes de cambiarlo) sigue llevando al negocio.
        business = next(
            (row for row in session.exec(select(Business).where(Business.old_slugs.contains(slug), Business.is_active.is_(True))).all()  # type: ignore[union-attr]
             if slug in (row.old_slugs or "").split(",")),
            None,
        )
    if business is None or business.id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    return business


@router.get("", response_model=list[ReviewRead])
def list_reviews(session: SessionDep, current_user: BusinessUserDep) -> list[Review]:
    business_id = _business_id(current_user)
    statement = (
        select(Review)
        .where(Review.business_id == business_id)
        .order_by(col(Review.created_at).desc())
        .limit(40)
    )
    return list(session.exec(statement).all())


@router.get("/public/{slug}", response_model=list[ReviewRead])
def list_public_reviews(slug: str, session: Session = Depends(get_session)) -> list[Review]:
    business = _active_business(session, slug)
    statement = (
        select(Review)
        .where(Review.business_id == business.id)
        .order_by(col(Review.created_at).desc())
        .limit(8)
    )
    return list(session.exec(statement).all())


class ReviewReply(BaseModel):
    reply: str = Field(min_length=1, max_length=500)


@router.put("/{review_id}", response_model=ReviewRead)
def reply_review(
    review_id: int,
    body: ReviewReply,
    session: SessionDep,
    current_user: ManagerDep,
) -> Review:
    review = session.get(Review, review_id)
    if review is None or review.business_id != _business_id(current_user):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Reseña no encontrada")
    review.reply = body.reply.strip()
    session.add(review)
    session.commit()
    session.refresh(review)
    return review


@router.post("/public/{slug}", response_model=ReviewRead, status_code=status.HTTP_201_CREATED)
def create_public_review(slug: str, body: ReviewCreate, request: Request, session: SessionDep) -> Review:
    throttle(request, "review", limit=10)
    business = _active_business(session, slug)
    if business.id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    # Solo opina quien tuvo la cita (su enlace es el pase), una vez por cita.
    appointment = session.exec(
        select(Appointment).where(Appointment.cancel_token == body.token, Appointment.business_id == business.id)
    ).first()
    if appointment is None or appointment.status != AppointmentStatus.completed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Podrás dejar tu opinión cuando termine tu cita.",
        )
    if session.exec(select(Review.id).where(Review.appointment_id == appointment.id)).first() is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ya dejaste tu opinión sobre esta cita. ¡Gracias!")
    review = Review(
        business_id=business.id,
        appointment_id=appointment.id,
        client_name=body.client_name,
        rating=body.rating,
        comment=body.comment,
        photo_url=body.photo_url,
    )
    session.add(review)
    session.commit()
    session.refresh(review)
    return review
