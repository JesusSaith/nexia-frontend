import uuid
from datetime import date, datetime, time, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.core.agenda_scope import ensure_own_staff, own_staff_id
from app.core.booking import as_local_naive, has_staff_overlap, lock_staff, owed_deposit, release_expired_deposits
from app.db.database import get_session
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.service import Service
from app.models.staff import Staff
from app.routers.auth import BusinessUserDep
from app.routers.businesses import _remember_client, to_appointment_read
from app.schemas.appointment import AdminAppointmentCreate, AppointmentRead, AppointmentStatusUpdate

router = APIRouter(prefix="/appointments", tags=["appointments"])

SessionDep = Annotated[Session, Depends(get_session)]


class WaiterRead(BaseModel):
    client_name: str
    client_phone: str


@router.get("/waiters", response_model=list[WaiterRead])
def list_waiters(
    session: SessionDep,
    current_user: BusinessUserDep,
    day: str,
    service_id: int,
    staff_id: int,
) -> list[WaiterRead]:
    from app.models.waitlist import Waitlist

    business_id = _business_id(current_user)
    mine = own_staff_id(session, current_user)
    if mine is not None:
        staff_id = mine
    rows = session.exec(
        select(Waitlist).where(
            Waitlist.business_id == business_id,
            Waitlist.day == day,
            Waitlist.service_id == service_id,
            Waitlist.staff_id == staff_id,
        )
    ).all()
    return [WaiterRead(client_name=row.client_name, client_phone=row.client_phone) for row in rows]


def _own_appointment(session: Session, user: BusinessUserDep, appointment_id: int, business_id: int) -> Appointment:
    """La cita, si es de este negocio y (para el personal) de su propia agenda; si no, 404 sin dar pistas."""
    appointment = session.get(Appointment, appointment_id)
    if appointment is None or appointment.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    mine = own_staff_id(session, user)
    if mine is not None and appointment.staff_id != mine:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    return appointment


def _business_id(current_user: BusinessUserDep) -> int:
    if current_user.business_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return current_user.business_id


@router.get("", response_model=list[AppointmentRead])
def list_appointments(
    session: SessionDep,
    current_user: BusinessUserDep,
    day: Annotated[date | None, Query(alias="date")] = None,
    start_date: date | None = None,
    end_date: date | None = None,
    staff_id: int | None = None,
    service_id: int | None = None,
    client_phone: str | None = None,
) -> list[AppointmentRead]:
    if start_date is not None and end_date is not None and start_date > end_date:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="start_date no puede ser posterior a end_date",
        )

    business_id = _business_id(current_user)
    release_expired_deposits(session, business_id)
    mine = own_staff_id(session, current_user)
    if mine is not None:
        staff_id = mine  # el personal solo ve su propia agenda, pida lo que pida
    statement = select(Appointment).where(Appointment.business_id == business_id)
    if staff_id is not None:
        statement = statement.where(Appointment.staff_id == staff_id)
    if service_id is not None:
        statement = statement.where(Appointment.service_id == service_id)
    if client_phone:
        statement = statement.where(Appointment.client_phone == client_phone)
    if day is not None:
        day_start = datetime.combine(day, time.min)
        statement = statement.where(
            Appointment.starts_at >= day_start,
            Appointment.starts_at < day_start + timedelta(days=1),
        )
    if start_date is not None:
        statement = statement.where(Appointment.starts_at >= datetime.combine(start_date, time.min))
    if end_date is not None:
        statement = statement.where(
            Appointment.starts_at < datetime.combine(end_date, time.min) + timedelta(days=1)
        )
    appointments = list(session.exec(statement.order_by(Appointment.starts_at)).all())
    return [_read(session, item) for item in appointments]


@router.post("", response_model=AppointmentRead, status_code=status.HTTP_201_CREATED)
def create_appointment(
    body: AdminAppointmentCreate,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> AppointmentRead:
    business_id = _business_id(current_user)
    ensure_own_staff(session, current_user, body.staff_id)
    service = session.get(Service, body.service_id)
    member = session.get(Staff, body.staff_id)
    if service is None or service.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Servicio no encontrado")
    if member is None or member.business_id != business_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")

    starts_at = as_local_naive(body.starts_at)
    ends_at = starts_at + timedelta(minutes=service.duration_minutes)
    lock_staff(session, body.staff_id)
    if has_staff_overlap(session, business_id, body.staff_id, starts_at, ends_at, service_id=service.id, capacity=service.capacity or 1):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese horario ya está ocupado")

    appointment = Appointment(
        source="admin",
        business_id=business_id,
        staff_id=body.staff_id,
        service_id=body.service_id,
        starts_at=starts_at,
        ends_at=ends_at,
        client_name=body.client_name.strip(),
        client_phone=body.client_phone.strip(),
        client_email=str(body.client_email).lower() if body.client_email else None,
        notes=body.notes.strip() if body.notes else None,
        status=AppointmentStatus.scheduled,
        cancel_token=str(uuid.uuid4()),
        quoted_price=body.quoted_price,
    )
    owed = None if body.waive_deposit else owed_deposit(session.get(Business, business_id), service, body.quoted_price)
    if owed:
        appointment.status = AppointmentStatus.awaiting_deposit
        appointment.deposit_amount = owed
    _remember_client(session, business_id, appointment.client_name, appointment.client_phone, appointment.client_email, appointment.notes)
    from app.routers.notices import add_notice, visit_when

    session.add(appointment)
    session.flush()
    verb = "apartó" if appointment.status == AppointmentStatus.awaiting_deposit else "agendó"
    add_notice(
        session,
        business_id,
        f"{appointment.client_name} {verb} {service.name} con {member.full_name.split()[0]} {visit_when(appointment.starts_at)} #{appointment.id}",
    )
    session.commit()
    session.refresh(appointment)
    return to_appointment_read(appointment, service, member)


class QuoteUpdate(BaseModel):
    quoted_price: float = Field(ge=0)


class AppointmentMove(BaseModel):
    starts_at: datetime
    staff_id: int | None = None


@router.put("/{appointment_id}/time", response_model=AppointmentRead)
def move_appointment(
    appointment_id: int,
    body: AppointmentMove,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> AppointmentRead:
    """La dueña cambia día, hora o persona; conserva la duración (incluye extras)."""
    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)
    if appointment.status not in (AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Solo se pueden mover citas pendientes")
    staff_id = body.staff_id or appointment.staff_id
    ensure_own_staff(session, current_user, staff_id)
    member = session.get(Staff, staff_id)
    if member is None or member.business_id != business_id or not member.is_active:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Colaborador no encontrado")
    service = session.get(Service, appointment.service_id)
    starts_at = as_local_naive(body.starts_at).replace(second=0, microsecond=0)
    ends_at = starts_at + (appointment.ends_at - appointment.starts_at)
    lock_staff(session, staff_id)
    if has_staff_overlap(
        session,
        business_id,
        staff_id,
        starts_at,
        ends_at,
        ignore_id=appointment.id,
        service_id=appointment.service_id,
        capacity=(service.capacity if service else 1) or 1,
    ):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=f"{member.full_name.split()[0]} ya tiene una cita a esa hora")
    appointment.staff_id = staff_id
    appointment.starts_at = starts_at
    appointment.ends_at = ends_at
    appointment.client_confirmed = False
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(session, appointment)


@router.put("/{appointment_id}/quote", response_model=AppointmentRead)
def quote_appointment(
    appointment_id: int,
    body: QuoteUpdate,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> AppointmentRead:
    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)
    appointment.quoted_price = body.quoted_price
    appointment.price_accepted = False
    service = session.get(Service, appointment.service_id)
    business = session.get(Business, business_id)
    owed = owed_deposit(business, service, body.quoted_price) if service and business else None
    if owed:
        appointment.deposit_amount = owed
        if appointment.status == AppointmentStatus.scheduled:
            appointment.status = AppointmentStatus.awaiting_deposit
    service_name = service.name if service else "el servicio"
    member = session.get(Staff, appointment.staff_id)
    staff = member.full_name.split()[0] if member else ""
    from app.routers.notices import add_notice, visit_when

    add_notice(
        session,
        business_id,
        f"Ofreciste ${body.quoted_price:g} a {appointment.client_name} por {service_name} con {staff} {visit_when(appointment.starts_at)} #{appointment.id}",
    )
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(session, appointment)


_OPEN = {AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit}
_CLOSED = {AppointmentStatus.cancelled, AppointmentStatus.no_show}
# A qué estado puede pasar cada cita. Las salidas hacia scheduled/awaiting_deposit son "Deshacer" o aceptar el anticipo.
_NEXT: dict[AppointmentStatus, set[AppointmentStatus]] = {
    AppointmentStatus.scheduled: {AppointmentStatus.completed, AppointmentStatus.cancelled, AppointmentStatus.no_show, AppointmentStatus.awaiting_deposit},
    AppointmentStatus.awaiting_deposit: {AppointmentStatus.scheduled, AppointmentStatus.cancelled},
    AppointmentStatus.completed: {AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit},
    AppointmentStatus.cancelled: {AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit},
    AppointmentStatus.no_show: {AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit},
}


@router.put("/{appointment_id}/status", response_model=AppointmentRead)
def update_appointment_status(
    appointment_id: int,
    body: AppointmentStatusUpdate,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> AppointmentRead:
    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)

    previous = appointment.status
    if body.status == previous:
        return _read(session, appointment)
    if body.status not in _NEXT[previous]:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Esa cita no se puede cambiar a ese estado")
    if previous in _CLOSED and body.status in _OPEN:
        # Deshacer una cancelación o una inasistencia: el horario pudo ocuparse mientras tanto.
        service = session.get(Service, appointment.service_id)
        lock_staff(session, appointment.staff_id)
        if has_staff_overlap(
            session,
            business_id,
            appointment.staff_id,
            appointment.starts_at,
            appointment.ends_at,
            ignore_id=appointment.id,
            service_id=appointment.service_id,
            capacity=(service.capacity if service else 1) or 1,
        ):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Ese horario ya lo ocupó otra cita. Muévela a otra hora antes de recuperarla.")
    appointment.status = body.status
    if body.status == AppointmentStatus.completed:
        # Reportes y comisiones usan quoted_price: así cuadran con lo cobrado de verdad.
        if body.final_price is not None:
            appointment.quoted_price = body.final_price
        if body.payment_method:
            appointment.payment_method = body.payment_method
        if body.tip is not None:
            appointment.tip = body.tip or None
        if body.visit_note is not None:
            appointment.visit_note = body.visit_note.strip() or None
    service = session.get(Service, appointment.service_id)
    member = session.get(Staff, appointment.staff_id)
    service_name = service.name if service else "la cita"
    staff = member.full_name.split()[0] if member else ""
    from app.routers.notices import add_notice, visit_when

    detail = f"{service_name} con {staff} {visit_when(appointment.starts_at)} #{appointment.id}"
    if previous == AppointmentStatus.cancelled and body.status != AppointmentStatus.cancelled and appointment.use_package:
        # "Deshacer" una cancelación: la visita vuelve a descontarse del paquete.
        from app.models.package import take_package

        take_package(session, business_id, appointment.client_phone)
    if body.status == AppointmentStatus.scheduled and previous == AppointmentStatus.awaiting_deposit:
        add_notice(session, business_id, f"Aceptaste la cita de {appointment.client_name}: {detail}")
    elif body.status in {AppointmentStatus.cancelled, AppointmentStatus.no_show}:
        from app.models.package import give_package
        from app.models.waitlist import notify_waitlist

        label = "no llegó a" if body.status == AppointmentStatus.no_show else "canceló"
        if body.status == AppointmentStatus.cancelled and appointment.use_package:
            give_package(session, business_id, appointment.client_phone)
        add_notice(session, business_id, f"{appointment.client_name} {label} {detail}")
        notify_waitlist(session, appointment)
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(session, appointment)


@router.post("/{appointment_id}/approve", response_model=AppointmentRead)
def approve_appointment(appointment_id: int, session: SessionDep, current_user: BusinessUserDep) -> AppointmentRead:
    """La dueña acepta una reserva que llegó por aprobar. Rechazarla es cancelarla (PUT /status)."""
    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)
    if appointment.needs_approval:
        appointment.needs_approval = False
        session.add(appointment)
        session.commit()
        session.refresh(appointment)
    return _read(session, appointment)


class LastNoteRead(BaseModel):
    note: str | None = None
    date: str | None = None


def _digits(value: str | None) -> str:
    return "".join(char for char in (value or "") if char.isdigit())


@router.get("/{appointment_id}/last-note", response_model=LastNoteRead)
def last_visit_note(
    appointment_id: int,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> LastNoteRead:
    """Nota privada de la última visita completada de la misma clienta (mismo teléfono)."""
    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)
    phone = _digits(appointment.client_phone)
    if not phone:
        return LastNoteRead()
    rows = session.exec(
        select(Appointment)
        .where(
            Appointment.business_id == business_id,
            Appointment.status == AppointmentStatus.completed,
            Appointment.id != appointment.id,
            Appointment.starts_at < appointment.starts_at,
            Appointment.visit_note.is_not(None),  # type: ignore[union-attr]
        )
        .order_by(Appointment.starts_at.desc())  # type: ignore[attr-defined]
    ).all()
    for row in rows:
        if _digits(row.client_phone) == phone and (row.visit_note or "").strip():
            return LastNoteRead(note=row.visit_note.strip(), date=row.starts_at.date().isoformat())
    return LastNoteRead()


@router.post("/{appointment_id}/another-proof", response_model=AppointmentRead)
def request_another_proof(
    appointment_id: int,
    session: SessionDep,
    current_user: BusinessUserDep,
) -> AppointmentRead:
    from app.routers.notices import add_notice, visit_when

    business_id = _business_id(current_user)
    appointment = _own_appointment(session, current_user, appointment_id, business_id)
    appointment.payment_proof = None
    service = session.get(Service, appointment.service_id)
    add_notice(
        session,
        business_id,
        f"Pediste otra foto del anticipo a {appointment.client_name} por {service.name if service else 'la cita'} {visit_when(appointment.starts_at)} #{appointment.id}",
    )
    session.add(appointment)
    session.commit()
    session.refresh(appointment)
    return _read(session, appointment)


def _read(session: Session, appointment: Appointment) -> AppointmentRead:
    service = session.get(Service, appointment.service_id)
    member = session.get(Staff, appointment.staff_id)
    if service is None or member is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cita no encontrada")
    return to_appointment_read(appointment, service, member)
