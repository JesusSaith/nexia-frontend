from functools import lru_cache
from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, Response, status
from jose import JWTError
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, select

from app.core import emails
from app.core.catalog import STAFF_LABEL_BY_KIND, catalog_for
from app.core.clock import DEFAULT_TIMEZONE, local_now
from app.core.config import settings
from app.core.mailer import send_email
from app.core.origins import app_origin
from app.core.security import (
    create_access_token,
    create_reset_token,
    decode_access_token,
    hash_password,
    read_reset_token,
    reset_token_matches,
    verify_password,
)
from app.core.throttle import client_ip, forget, is_blocked, record, throttle
from app.db.database import get_session
from app.models.business import Business, slugify
from app.models.service import Service
from app.models.user import User, UserRole
from app.schemas.auth import (
    ClientRegisterRequest,
    ForgotPasswordRequest,
    LoginRequest,
    RegisterRequest,
    ResetPasswordRequest,
    UserResponse,
    to_user_response,
)

router = APIRouter(prefix="/auth", tags=["auth"])

SessionDep = Annotated[Session, Depends(get_session)]


def _set_access_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=settings.COOKIE_SECURE,
        samesite=settings.COOKIE_SAMESITE,
        max_age=settings.ACCESS_TOKEN_EXPIRE_SECONDS,
    )


def get_current_user(request: Request, session: SessionDep) -> User:
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="No autenticado")

    try:
        user_id = int(decode_access_token(token))
    except (JWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="No autenticado") from None

    user = session.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="No autenticado")
    return user


CurrentUserDep = Annotated[User, Depends(get_current_user)]


def get_business_user(current_user: CurrentUserDep) -> User:
    """Authenticated member of a business. Clients cannot administer the catalog."""
    if current_user.business_id is None or current_user.role in {UserRole.client, UserRole.super_admin}:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar este negocio",
        )
    return current_user


BusinessUserDep = Annotated[User, Depends(get_business_user)]

_MANAGERS = {UserRole.owner, UserRole.admin}


def require_manager(current_user: CurrentUserDep) -> User:
    """Propietaria o administradora: lo que toca dinero, precios, equipo y datos de clientes."""
    if current_user.business_id is None or current_user.role not in _MANAGERS:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Solo el propietario o un administrador puede hacer esto",
        )
    return current_user


ManagerDep = Annotated[User, Depends(require_manager)]


def _find_user_by_email(session: Session, email: str) -> User | None:
    return session.exec(select(User).where(User.email == email)).first()


def _load_business(session: Session, business_id: int | None) -> Business | None:
    if business_id is None:
        return None
    return session.get(Business, business_id)


# Primeros segmentos de rutas propias de la app; un negocio con ese slug taparía la ruta (o al revés).
RESERVED_SLUGS = {"auth", "admin", "super-admin", "cliente", "api", "s", "terminos", "privacidad", "legal", "ayuda"}


def _unique_slug(session: Session, name: str) -> str:
    base = slugify(name)
    if base in RESERVED_SLUGS:
        base = f"{base}-negocio"
    slug = base
    suffix = 2
    while session.exec(select(Business).where(Business.slug == slug)).first() is not None:
        slug = f"{base}-{suffix}"
        suffix += 1
    return slug


@router.get("/slug-preview")
def slug_preview(name: Annotated[str, Query(min_length=1, max_length=255)], session: SessionDep) -> dict[str, str]:
    """El enlace que recibiría un negocio con este nombre, para mostrarlo mientras se registra."""
    return {"slug": _unique_slug(session, name)}


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(
    body: RegisterRequest,
    request: Request,
    response: Response,
    background: BackgroundTasks,
    session: SessionDep,
) -> UserResponse:
    throttle(request, "register", "Hiciste muchos intentos seguidos. Espera unos minutos y vuelve a intentarlo.")
    email = str(body.email).lower()
    if _find_user_by_email(session, email) is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="El correo ya está registrado")

    business = Business(
        name=body.business_name,
        slug=_unique_slug(session, body.business_name),
        email=email,
        phone=body.phone,
        address=body.address,
        instagram=body.instagram,
        business_kind=body.business_kind,
        timezone=body.timezone or DEFAULT_TIMEZONE,
        staff_label=STAFF_LABEL_BY_KIND.get(body.business_kind or "", "Colaborador"),
        uses_commissions=body.uses_commissions,
    )
    user = User(
        email=email,
        hashed_password=hash_password(body.password),
        role=UserRole.owner,
        full_name=body.full_name,
        business_id=None,
        terms_accepted_at=local_now(),
    )
    session.add(business)
    session.flush()
    user.business_id = business.id
    session.add(user)
    # Servicios típicos del giro, apagados: la dueña ajusta precios y los activa; nada inventado sale al público.
    session.add_all(
        Service(business_id=business.id, name=name, duration_minutes=minutes, price=price, category=category, is_active=False)
        for name, minutes, price, category in catalog_for(business)
    )
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="El correo o el identificador del negocio ya existe",
        ) from None
    session.refresh(user)
    session.refresh(business)

    background.add_task(send_email, user.email, *emails.welcome(app_origin(request), user.full_name, business.name, business.slug))
    _set_access_cookie(response, create_access_token(str(user.id)))
    response.headers["Cache-Control"] = "no-store"
    return to_user_response(user, business)


@router.post("/forgot-password", status_code=status.HTTP_204_NO_CONTENT)
def forgot_password(body: ForgotPasswordRequest, request: Request, background: BackgroundTasks, session: SessionDep) -> None:
    """Siempre responde igual, exista o no la cuenta, para no revelar qué correos están registrados."""
    throttle(request, "forgot", "Pediste varios enlaces seguidos. Revisa tu correo (también en spam) o espera unos minutos.")
    user = _find_user_by_email(session, str(body.email).lower())
    if user is None or user.id is None:
        return
    token = create_reset_token(user.id, user.hashed_password)
    background.add_task(send_email, user.email, *emails.password_reset(app_origin(request), user.full_name, token))


@router.post("/reset-password", response_model=UserResponse)
def reset_password(
    body: ResetPasswordRequest,
    request: Request,
    response: Response,
    background: BackgroundTasks,
    session: SessionDep,
) -> UserResponse:
    throttle(request, "reset")
    invalid = HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="El enlace venció o ya se usó. Pide uno nuevo desde «¿Olvidaste tu contraseña?».",
    )
    try:
        user_id, fingerprint = read_reset_token(body.token)
    except JWTError:
        raise invalid from None
    user = session.get(User, user_id)
    if user is None or not reset_token_matches(fingerprint, user.hashed_password):
        raise invalid
    user.hashed_password = hash_password(body.password)
    session.add(user)
    session.commit()
    session.refresh(user)

    background.add_task(send_email, user.email, *emails.password_changed(app_origin(request), user.full_name))
    # Queda con la sesión abierta: acaba de demostrar que es dueña del correo.
    _set_access_cookie(response, create_access_token(str(user.id)))
    response.headers["Cache-Control"] = "no-store"
    return to_user_response(user, _load_business(session, user.business_id))


# FUTURE_PHASE_2_UNIFIED_PLATFORM: alta de perfil de cliente para cuentas que después cruzan negocios.
# En la fase 1 no se publica. El cliente reserva en /{slug}/book sin esta cuenta.
# @router.post("/register-client", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_client(body: ClientRegisterRequest, response: Response, session: SessionDep) -> UserResponse:
    email = str(body.email).lower()
    if _find_user_by_email(session, email) is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="El correo ya está registrado")
    business = session.exec(select(Business).where(Business.slug == body.slug.strip())).first()
    if business is None or business.id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Negocio no encontrado")
    user = User(
        email=email,
        hashed_password=hash_password(body.password),
        role=UserRole.client,
        full_name=body.full_name.strip(),
        business_id=business.id,
    )
    session.add(user)
    session.commit()
    session.refresh(user)
    _set_access_cookie(response, create_access_token(str(user.id)))
    response.headers["Cache-Control"] = "no-store"
    return to_user_response(user, business)


LOGIN_LIMIT = 10
_LOGIN_BLOCKED = "Hiciste muchos intentos seguidos. Espera unos minutos y vuelve a intentarlo, o usa «¿Olvidaste tu contraseña?»."


@lru_cache(maxsize=1)
def _fake_hash() -> str:
    """Hash de relleno: así tarda lo mismo el correo que existe y el que no."""
    return hash_password("relleno-para-igualar-tiempos")


@router.post("/login", response_model=UserResponse)
def login(body: LoginRequest, request: Request, response: Response, session: SessionDep) -> UserResponse:
    email = str(body.email).lower()
    by_ip = f"login:{client_ip(request)}"
    by_email = f"login-email:{email}"
    # Solo cuentan los intentos fallidos: entrar bien no gasta el límite.
    if is_blocked(by_ip, LOGIN_LIMIT) or is_blocked(by_email, LOGIN_LIMIT):
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=_LOGIN_BLOCKED)
    user = _find_user_by_email(session, email)
    valid = verify_password(body.password, user.hashed_password if user else _fake_hash())
    if user is None or not valid:
        record(by_ip)
        record(by_email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Correo o contraseña incorrectos",
        )
    forget(by_email)

    _set_access_cookie(response, create_access_token(str(user.id)))
    response.headers["Cache-Control"] = "no-store"
    return to_user_response(user, _load_business(session, user.business_id))


@router.get("/me", response_model=UserResponse)
def read_me(response: Response, current_user: CurrentUserDep, session: SessionDep) -> UserResponse:
    response.headers["Cache-Control"] = "no-store"
    return to_user_response(current_user, _load_business(session, current_user.business_id))


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(response: Response) -> None:
    response.delete_cookie(
        key="access_token",
        httponly=True,
        secure=settings.COOKIE_SECURE,
        samesite=settings.COOKIE_SAMESITE,
    )
