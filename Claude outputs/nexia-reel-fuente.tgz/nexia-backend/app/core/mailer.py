"""Correos transaccionales con Resend (https://resend.com/docs/api-reference/emails/send-email).

Sin RESEND_API_KEY (desarrollo) no se envía nada: el correo se escribe en el log, con sus enlaces,
para poder probar los flujos en local.
"""

import json
import logging
import urllib.error
import urllib.request
from html import escape

from app.core.config import settings

logger = logging.getLogger("nexia.mail")

RESEND_URL = "https://api.resend.com/emails"


def send_email(to: str, subject: str, html: str, text: str) -> None:
    """Pensado para BackgroundTasks: nunca lanza; un correo que falla no debe tumbar la petición."""
    if not settings.RESEND_API_KEY:
        logger.warning("Correo sin enviar (falta RESEND_API_KEY) → %s · %s\n%s", to, subject, text)
        return
    body = json.dumps({"from": settings.MAIL_FROM, "to": [to], "subject": subject, "html": html, "text": text}).encode()
    request = urllib.request.Request(
        RESEND_URL,
        data=body,
        method="POST",
        headers={"Authorization": f"Bearer {settings.RESEND_API_KEY}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            response.read()
    except (urllib.error.URLError, TimeoutError) as error:
        logger.error("No se pudo enviar el correo a %s (%s): %s", to, subject, error)


def layout(title: str, paragraphs: list[str], button: tuple[str, str] | None = None, footer: str = "") -> str:
    """HTML sencillo y compatible con clientes de correo (tablas y estilos en línea)."""
    rows = "".join(f'<p style="margin:0 0 14px;font-size:15px;line-height:22px;color:#4a4542">{p}</p>' for p in paragraphs)
    cta = ""
    if button:
        label, url = button
        cta = (
            f'<p style="margin:22px 0"><a href="{escape(url)}" style="display:inline-block;background:#1c1a19;color:#ffffff;'
            f'text-decoration:none;font-weight:600;font-size:15px;padding:12px 22px;border-radius:8px">{escape(label)}</a></p>'
            f'<p style="margin:0 0 14px;font-size:12px;line-height:18px;color:#7a736d">Si el botón no abre, copia este enlace:<br>'
            f'<a href="{escape(url)}" style="color:#7a736d;word-break:break-all">{escape(url)}</a></p>'
        )
    note = f'<p style="margin:18px 0 0;font-size:12px;line-height:18px;color:#7a736d">{footer}</p>' if footer else ""
    return (
        '<!doctype html><html><body style="margin:0;background:#f6f5f3;font-family:Helvetica,Arial,sans-serif">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:480px;background:#ffffff;'
        'border:1px solid #e7e4df;border-radius:12px;padding:28px">'
        f'<tr><td><p style="margin:0 0 18px;font-size:13px;font-weight:700;letter-spacing:.04em;color:#e11d48">NEXIA</p>'
        f'<h1 style="margin:0 0 16px;font-size:20px;line-height:26px;color:#1c1a19">{escape(title)}</h1>'
        f"{rows}{cta}{note}</td></tr></table></td></tr></table></body></html>"
    )
