import time as clock
from collections import defaultdict, deque

from fastapi import HTTPException, Request, status

from app.core.config import settings

# Límite en memoria por IP para las rutas públicas. Basta con un proceso; con varios servidores
# habría que moverlo a Redis.
_PUBLIC_HITS: dict[str, deque[float]] = defaultdict(deque)
PUBLIC_LIMIT = 6
PUBLIC_WINDOW_SECONDS = 600
_SWEEP_AT = 5000


def client_ip(request: Request) -> str:
    """La IP real de quien llama.

    El primer valor de X-Forwarded-For lo escribe el propio cliente y se puede inventar; solo los
    últimos TRUSTED_PROXY_HOPS los agregan proxies nuestros. Por eso se cuenta desde la derecha.
    """
    peer = request.client.host if request.client else "desconocida"
    hops = settings.TRUSTED_PROXY_HOPS
    if hops <= 0:
        return peer
    chain = [part.strip() for part in request.headers.get("x-forwarded-for", "").split(",") if part.strip()]
    if not chain:
        return peer
    # Menos saltos de los esperados: no pasó por todos los proxies; el más cercano es el confiable.
    return chain[-hops] if len(chain) >= hops else chain[-1]


def _sweep(now: float) -> None:
    """Quita las claves vencidas para que la memoria no crezca con IPs que no vuelven."""
    for key in [key for key, hits in _PUBLIC_HITS.items() if not hits or now - hits[-1] > PUBLIC_WINDOW_SECONDS]:
        del _PUBLIC_HITS[key]


def _recent(key: str, now: float) -> deque[float]:
    if len(_PUBLIC_HITS) > _SWEEP_AT:
        _sweep(now)
    hits = _PUBLIC_HITS[key]
    while hits and now - hits[0] > PUBLIC_WINDOW_SECONDS:
        hits.popleft()
    return hits


def throttle(
    request: Request,
    action: str,
    detail: str = "Hiciste muchos intentos seguidos. Espera unos minutos o escríbenos por WhatsApp.",
    limit: int = PUBLIC_LIMIT,
) -> None:
    """Cuenta esta llamada y rechaza con 429 si la IP ya llegó al límite de la ventana."""
    now = clock.monotonic()
    hits = _recent(f"{action}:{client_ip(request)}", now)
    if len(hits) >= limit:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=detail)
    hits.append(now)


def is_blocked(key: str, limit: int) -> bool:
    """Solo consulta: ¿esta clave ya llegó al límite? No cuenta la llamada."""
    return len(_recent(key, clock.monotonic())) >= limit


def record(key: str) -> None:
    """Cuenta un intento fallido en esta clave."""
    _recent(key, clock.monotonic()).append(clock.monotonic())


def forget(key: str) -> None:
    _PUBLIC_HITS.pop(key, None)
