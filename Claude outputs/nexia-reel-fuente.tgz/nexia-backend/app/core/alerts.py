"""Avisos por correo a la dueña: lo mismo que ve en Inicio, pero le llega aunque no tenga el panel abierto.

Cada aviso del panel (`add_notice`) puede llevar un tipo. Si la dueña tiene ese tipo encendido en
Configuración → Avisos por correo, el correo se encola en la sesión y sale solo cuando el commit se
confirma: si la reserva falla y se hace rollback, no llega un correo de una cita que no existe.
"""

import re
import threading
from contextvars import ContextVar
from datetime import timedelta
from html import escape

from sqlalchemy import event
from sqlalchemy.orm import Session as OrmSession
from sqlmodel import Session, select

from app.core.clock import local_now
from app.core.config import settings
from app.core.mailer import layout, send_email

# Tipo → nombre que ve la dueña en Configuración.
ALERT_KINDS: dict[str, str] = {
    "new_booking": "Citas nuevas",
    "cancelled": "Cancelaciones",
    "rescheduled": "Cambios de horario",
    "payment": "Comprobantes y pagos de anticipo",
    "deposit_expired": "Anticipos vencidos y horarios liberados",
    "waitlist": "Lista de espera",
    "confirmed": "Confirmaciones de asistencia",
    "daily_summary": "Resumen de las citas de mañana (8 p. m.)",
}
# Las confirmaciones son muchas y poco urgentes: apagadas mientras la dueña no las pida.
DEFAULT_ALERTS = frozenset(ALERT_KINDS) - {"confirmed"}
SUMMARY_HOUR = 20

_SUBJECTS = {
    "new_booking": "Cita nueva",
    "cancelled": "Cancelaron una cita",
    "rescheduled": "Cambiaron una cita",
    "payment": "Anticipo por revisar",
    "deposit_expired": "Anticipo vencido",
    "waitlist": "Lista de espera",
    "confirmed": "Confirmaron su cita",
}

# Dirección de la app desde la que llegó la petición (la pone un middleware en main.py) para que los
# enlaces del correo abran el panel correcto, también en local con cualquier puerto.
current_app_origin: ContextVar[str | None] = ContextVar("current_app_origin", default=None)

_QUEUE_KEY = "nexia_alert_mail"


def alerts_of(business: object) -> set[str]:
    raw = getattr(business, "email_alerts", None)
    if raw is None:
        return set(DEFAULT_ALERTS)
    return {kind for kind in raw.split(",") if kind in ALERT_KINDS}


def pack_alerts(kinds: list[str]) -> str:
    return ",".join(kind for kind in ALERT_KINDS if kind in set(kinds))


def _app() -> str:
    return (current_app_origin.get() or settings.FRONTEND_URL).rstrip("/")


def queue_alert(session: Session, business_id: int, kind: str, message: str) -> None:
    from app.models.business import Business

    business = session.get(Business, business_id)
    if business is None or not business.email or kind not in alerts_of(business):
        return
    found = re.search(r"#(\d+)", message)
    text = re.sub(r"\s*#\d+\s*$", "", message).strip()
    link = f"{_app()}/admin/agenda" + (f"?cita={found.group(1)}" if found else "")
    subject = f"{_SUBJECTS.get(kind, 'Aviso')}: {business.name}"
    html = layout(
        _SUBJECTS.get(kind, "Aviso"),
        [escape(text)],
        button=("Ver en mi agenda", link),
        footer=f"Eliges qué avisos te llegan en Configuración → Avisos por correo: {escape(_app())}/admin/settings",
    )
    session.info.setdefault(_QUEUE_KEY, []).append((business.email, subject, html, f"{text}\n\nVer en tu agenda: {link}\n"))


@event.listens_for(OrmSession, "after_commit")
def _send_queued(session: OrmSession) -> None:
    for mail in session.info.pop(_QUEUE_KEY, []):
        # Hilo aparte: el correo no debe hacer esperar a la clienta que acaba de reservar.
        threading.Thread(target=send_email, args=mail, daemon=True).start()


@event.listens_for(OrmSession, "after_rollback")
def _drop_queued(session: OrmSession) -> None:
    session.info.pop(_QUEUE_KEY, None)


def send_daily_summaries(session: Session) -> int:
    """Una vez al día, desde las 8 p. m. hora del negocio, manda las citas de mañana. Devuelve cuántos envió."""
    from app.models.appointment import Appointment, AppointmentStatus
    from app.models.business import Business
    from app.models.service import Service

    sent = 0
    for business in session.exec(select(Business).where(Business.is_active == True)).all():  # noqa: E712
        now = local_now(business)
        today = now.date().isoformat()
        if now.hour < SUMMARY_HOUR or business.summary_sent_on == today:
            continue
        business.summary_sent_on = today
        session.add(business)
        if not business.email or "daily_summary" not in alerts_of(business):
            continue
        start = now.replace(hour=0, minute=0, second=0) + timedelta(days=1)
        rows = session.exec(
            select(Appointment, Service)
            .join(Service, Service.id == Appointment.service_id)
            .where(
                Appointment.business_id == business.id,
                Appointment.starts_at >= start,
                Appointment.starts_at < start + timedelta(days=1),
                Appointment.status.in_([AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit]),  # type: ignore[attr-defined]
            )
            .order_by(Appointment.starts_at)
        ).all()
        if not rows:
            continue
        pending = sum(1 for appointment, _ in rows if not appointment.client_confirmed)
        lines = [f"{appointment.starts_at.strftime('%H:%M')} · {appointment.client_name} · {service.name}" for appointment, service in rows]
        intro = f"Mañana tienes {len(rows)} cita{'s' if len(rows) != 1 else ''}" + (f", {pending} sin confirmar." if pending else ", todas confirmadas.")
        link = f"{_app()}/admin/home"
        html = layout(
            "Tus citas de mañana",
            [escape(intro), "<br>".join(escape(line) for line in lines)],
            button=("Enviar recordatorios", link),
            footer="Desde Inicio mandas los recordatorios por WhatsApp, uno por uno.",
        )
        text = f"{intro}\n\n" + "\n".join(lines) + f"\n\nEnviar recordatorios: {link}\n"
        session.info.setdefault(_QUEUE_KEY, []).append((business.email, f"Mañana: {len(rows)} citas en {business.name}", html, text))
        sent += 1
    session.commit()
    return sent


def send_monthly_reports(session: Session) -> int:
    """Desde el día 1 a las 8 a. m., un correo con lo importante del mes anterior. Devuelve cuántos envió."""
    from app.models.business import Business
    from app.routers.shop import _Owner, sales_report

    names = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    sent = 0
    for business in session.exec(select(Business).where(Business.is_active == True)).all():  # noqa: E712
        now = local_now(business)
        last_day = now.replace(day=1) - timedelta(days=1)
        key = last_day.strftime("%Y-%m")
        if now.hour < 8 or business.monthly_sent_on == key or not business.email:
            continue
        business.monthly_sent_on = key
        session.add(business)
        report = sales_report(session, _Owner(business.id), f"{key}-01", last_day.date().isoformat())  # type: ignore[arg-type]
        if report.completed_count == 0:
            continue
        label = f"{names[last_day.month - 1]} {last_day.year}"
        money = lambda value: f"${value:,.0f}"  # noqa: E731
        lines = [
            f"Ingresos: {money(report.total)} en {report.completed_count} citas (ticket {money(report.average_ticket)}).",
            f"Gastos: {money(report.expense_fixed + report.expense_variable)}"
            + (f" · Comisiones: {money(report.commission_total)}." if business.uses_commissions is not False else "."),
            f"Te quedaron {money(report.profit)}.",
            f"Clientes nuevos: {report.new_clients} · Regresaron: {report.returning_clients}.",
            f"No se hicieron {report.missed_count} citas ({money(report.missed_amount)}).",
        ]
        link = f"{_app()}/admin/dashboard"
        html = layout(f"Tu resumen de {label}", [escape(line) for line in lines], button=("Ver reportes", link))
        text = "\n".join(lines) + f"\n\nVer reportes: {link}\n"
        session.info.setdefault(_QUEUE_KEY, []).append((business.email, f"Resumen de {label} · {business.name}", html, text))
        sent += 1
    session.commit()
    return sent
