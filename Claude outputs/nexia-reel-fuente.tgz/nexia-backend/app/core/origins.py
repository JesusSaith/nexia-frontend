"""Dirección de la app web para armar enlaces (correos, enlace para compartir).

Se usa la dirección desde la que se abrió la app, para que en local funcione con cualquier puerto
que tome Angular. Solo se acepta si es de confianza: en producción, únicamente FRONTEND_URL; si se
aceptara cualquiera, alguien podría pedir un enlace de recuperación para otra persona con un
Origin falso y quedarse con el token.
"""

import re
from urllib.parse import urlsplit

from fastapi import Request

from app.core.config import settings

# En desarrollo Angular puede tomar cualquier puerto local (también lo usa CORS en main.py).
LOCAL_ORIGIN = re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$")


def _frontend_url() -> str:
    return settings.FRONTEND_URL.rstrip("/")


def is_trusted_origin(origin: str) -> bool:
    if origin == _frontend_url():
        return True
    return settings.ENVIRONMENT != "production" and bool(LOCAL_ORIGIN.match(origin))


def _origin_of(url: str | None) -> str | None:
    if not url:
        return None
    parts = urlsplit(url)
    return f"{parts.scheme}://{parts.netloc}" if parts.scheme and parts.netloc else None


def app_origin(request: Request, hint: str | None = None) -> str:
    """La primera de confianza entre: la pista explícita, el Origin y el Referer. Si ninguna, FRONTEND_URL."""
    for candidate in (_origin_of(hint), _origin_of(request.headers.get("origin")), _origin_of(request.headers.get("referer"))):
        if candidate and is_trusted_origin(candidate):
            return candidate
    return _frontend_url()
