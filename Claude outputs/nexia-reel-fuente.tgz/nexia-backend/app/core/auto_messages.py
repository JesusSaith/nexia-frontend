"""Mensajes automáticos por WhatsApp: recordatorio con botones y "Te toca".

Los corre el ciclo de la API cada 10 minutos (app/main.py). Solo trabajan los negocios que los
encendieron en Configuración y solo si el servidor tiene la API de WhatsApp conectada.
"""

import logging
from datetime import timedelta

from sqlmodel import Session, select

from app.core.alerts import _app
from app.core.clock import local_now
from app.core.config import settings
from app.core.returns import due_clients, long_day, suggested_label
from app.core.whatsapp import send_template, whatsapp_ready
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.service import Service
from app.models.staff import Staff

logger = logging.getLogger("nexia.auto")

# Una cita agendada hace muy poco no necesita recordatorio: la clienta la tiene fresca.
FRESH_HOURS = 2
RETURNS_PER_RUN = 20


def send_auto_messages(session: Session) -> int:
    if not whatsapp_ready():
        return 0
    sent = 0
    for business in session.exec(select(Business).where((Business.auto_reminders == True) | (Business.auto_return == True))).all():  # noqa: E712
        try:
            if business.auto_reminders:
                sent += send_reminders(session, business)
            if business.auto_return:
                sent += send_return_invites(session, business)
        except Exception:  # noqa: BLE001 — un negocio con datos raros no detiene a los demás
            logger.exception("Falló el envío automático del negocio %s", business.id)
            session.rollback()
    return sent


def send_reminders(session: Session, business: Business) -> int:
    now = local_now(business)
    limit = now + timedelta(hours=business.reminder_hours or 24)
    rows = session.exec(
        select(Appointment).where(
            Appointment.business_id == business.id,
            Appointment.status == AppointmentStatus.scheduled,
            Appointment.needs_approval == False,  # noqa: E712
            Appointment.reminder_sent_at == None,  # noqa: E711
            Appointment.starts_at > now,
            Appointment.starts_at <= limit,
        )
    ).all()
    sent = 0
    for appointment in rows:
        if appointment.created_at and appointment.created_at > now - timedelta(hours=FRESH_HOURS):
            continue
        service = session.get(Service, appointment.service_id)
        member = session.get(Staff, appointment.staff_id)
        params = [
            appointment.client_name.split()[0],
            business.name,
            service.name if service else "tu cita",
            long_day(appointment.starts_at.date()),
            appointment.starts_at.strftime("%H:%M"),
            member.full_name.split()[0] if member else "",
        ]
        token = appointment.cancel_token
        if send_template(appointment.client_phone, settings.WHATSAPP_REMINDER_TEMPLATE, params, [f"confirm:{token}", f"change:{token}"]):
            appointment.reminder_sent_at = now
            session.add(appointment)
            sent += 1
    session.commit()
    return sent


def send_return_invites(session: Session, business: Business) -> int:
    sent = 0
    for row in due_clients(session, business, limit=RETURNS_PER_RUN, only_new=True):
        if row["days_late"] < 0 or row["due_on"] > local_now(business).date().isoformat():
            continue  # automático: solo el día que le toca o después
        link = f"{_app()}/{business.slug}/book"
        params = [row["client_name"].split()[0], business.name, row["service_name"], suggested_label(row["suggested"]) or "cuando gustes", link]
        if send_template(row["client_phone"], settings.WHATSAPP_RETURN_TEMPLATE, params):
            appointment = session.get(Appointment, row["appointment_id"])
            if appointment:
                appointment.return_invited = True
                session.add(appointment)
                sent += 1
    session.commit()
    return sent
