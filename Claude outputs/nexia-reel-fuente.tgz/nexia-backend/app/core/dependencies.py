from typing import Annotated

from fastapi import Depends, HTTPException, status

from app.models.user import User, UserRole
from app.routers.auth import get_current_user

def get_current_super_admin(current_user: Annotated[User, Depends(get_current_user)]) -> User:
    """Cookie session whose role is the platform super admin."""
    if current_user.role != UserRole.super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para administrar la plataforma",
        )
    return current_user
