"""Hora de pared de cada negocio.

Las citas se guardan como hora local del negocio, sin zona. El servidor puede correr en UTC
(Render, Railway), así que "ahora" y "hoy" siempre se calculan en la zona del negocio, nunca
con datetime.now() a secas.
"""

from datetime import date, datetime
from functools import cache
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError, available_timezones

DEFAULT_TIMEZONE = "America/Mexico_City"


@cache
def _known_timezones() -> frozenset[str]:
    return frozenset(available_timezones())


def is_valid_timezone(name: str) -> bool:
    return name in _known_timezones()


def zone(name: str | None) -> ZoneInfo:
    try:
        return ZoneInfo(name or DEFAULT_TIMEZONE)
    except (ZoneInfoNotFoundError, ValueError):
        return ZoneInfo(DEFAULT_TIMEZONE)


def local_now(business: object | None = None) -> datetime:
    """Ahora, en la hora local del negocio (o de la Ciudad de México si no se sabe), sin zona."""
    tz = zone(getattr(business, "timezone", None))
    return datetime.now(tz).replace(tzinfo=None, microsecond=0)


def local_today(business: object | None = None) -> date:
    return local_now(business).date()


def to_local_naive(value: datetime, business: object | None = None) -> datetime:
    """Una hora con zona (p. ej. "…Z" desde el navegador) pasada a la hora local del negocio."""
    if value.tzinfo is not None:
        value = value.astimezone(zone(getattr(business, "timezone", None))).replace(tzinfo=None)
    return value.replace(microsecond=0)
