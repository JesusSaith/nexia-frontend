"""Métodos de pago que acepta cada negocio.

"paquete" no se elige aquí: es pagar con visitas de un paquete y siempre está disponible al cobrar.
"""

import json

PAYMENT_METHODS = ("efectivo", "transferencia", "tarjeta")


def methods_of(business: object) -> list[str]:
    """Los que acepta, en orden fijo; si no eligió ninguno, los tres."""
    return parse_methods(getattr(business, "payment_methods", None))


def parse_methods(raw: object) -> list[str]:
    try:
        chosen = raw if isinstance(raw, list) else json.loads(raw) if isinstance(raw, str) and raw else []
    except ValueError:
        chosen = []
    picked = [method for method in PAYMENT_METHODS if isinstance(chosen, list) and method in chosen]
    return picked or list(PAYMENT_METHODS)


def pack_methods(methods: list[str]) -> str | None:
    picked = [method for method in PAYMENT_METHODS if method in methods]
    return None if not picked or len(picked) == len(PAYMENT_METHODS) else json.dumps(picked)
