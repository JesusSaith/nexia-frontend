"""Verificar transferencias SPEI con el CEP de Banxico (https://www.banxico.org.mx/cep/).

El CEP (Comprobante Electrónico de Pago) confirma que una transferencia existe con su clave de
rastreo, fecha, banco que envía, banco y cuenta que reciben, y monto. Es el mismo formulario
público de Banxico: primero `valida.do` y, con la misma sesión, `descarga.do?formato=XML`.
Si Banxico no responde, se dice "no disponible" y el anticipo se revisa a mano con la captura.
"""

import logging
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date
from http.cookiejar import CookieJar
from xml.etree import ElementTree

logger = logging.getLogger("nexia.spei")

CEP_URL = "https://www.banxico.org.mx/cep"

# Prefijo de la CLABE → (clave del participante en SPEI, nombre). Lista en src/app/core/spei-banks.ts.
BANKS: dict[str, tuple[str, str]] = {
    "002": ("40002", "Banamex"),
    "012": ("40012", "BBVA"),
    "014": ("40014", "Santander"),
    "021": ("40021", "HSBC"),
    "030": ("40030", "BanBajío"),
    "036": ("40036", "Inbursa"),
    "042": ("40042", "Mifel"),
    "044": ("40044", "Scotiabank"),
    "058": ("40058", "Banregio"),
    "059": ("40059", "Invex"),
    "062": ("40062", "Afirme"),
    "072": ("40072", "Banorte"),
    "127": ("40127", "Banco Azteca"),
    "130": ("40130", "Compartamos"),
    "132": ("40132", "Multiva"),
    "133": ("40133", "Actinver"),
    "136": ("40136", "Intercam"),
    "137": ("40137", "BanCoppel"),
    "138": ("40138", "ABC Capital (Ualá)"),
    "140": ("40140", "Consubanco"),
    "147": ("40147", "Bankaool"),
    "152": ("40152", "Bancrea"),
    "156": ("40156", "Sabadell"),
    "166": ("37166", "Banco del Bienestar"),
    "167": ("40167", "Hey Banco"),
    "638": ("90638", "Nu México"),
    "646": ("90646", "STP"),
    "722": ("90722", "Mercado Pago"),
    "728": ("90728", "Spin by OXXO"),
}
SENDER_CODES = {code for code, _ in BANKS.values()}


@dataclass
class Transfer:
    status: str  # ok | not_found | unavailable
    amount: float | None = None
    account: str | None = None


def clabe_ok(value: str | None) -> str | None:
    """La CLABE limpia si tiene 18 dígitos, el dígito verificador cuadra y su banco está en la lista."""
    digits = "".join(char for char in value or "" if char.isdigit())
    if len(digits) != 18 or digits[:3] not in BANKS:
        return None
    weights = [3, 7, 1] * 6
    check = (10 - sum(int(digit) * weights[index] % 10 for index, digit in enumerate(digits[:17])) % 10) % 10
    return digits if check == int(digits[17]) else None


def verify_transfer(day: date, tracking: str, sender: str, clabe: str, amount: float) -> Transfer:
    receiver = BANKS[clabe[:3]][0]
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))
    form = urllib.parse.urlencode({
        "tipoCriterio": "T",
        "fecha": day.strftime("%d-%m-%Y"),
        "criterio": tracking,
        "emisor": sender,
        "receptor": receiver,
        "cuenta": clabe,
        "receptorParticipante": "0",
        "monto": f"{amount:.2f}",
        "captcha": "c",
        "tipoConsulta": "1",
    }).encode()
    try:
        page = opener.open(urllib.request.Request(f"{CEP_URL}/valida.do", data=form), timeout=12).read().decode("latin-1", "ignore")
        if "no encontr" in page.lower() or "no se encontr" in page.lower():
            return Transfer("not_found")
        xml = opener.open(f"{CEP_URL}/descarga.do?formato=XML", timeout=12).read()
    except (urllib.error.URLError, TimeoutError, ValueError) as error:
        logger.warning("CEP de Banxico no disponible: %s", error)
        return Transfer("unavailable")
    return parse_cep(xml)


def parse_cep(xml: bytes) -> Transfer:
    """Del XML del CEP solo importa a qué cuenta llegó y cuánto."""
    try:
        root = ElementTree.fromstring(xml)
    except ElementTree.ParseError:
        return Transfer("not_found")
    receiver = root.find(".//Beneficiario")
    if receiver is None:
        return Transfer("not_found")
    try:
        amount = float(receiver.get("MontoPago") or root.get("MontoPago") or "")
    except ValueError:
        amount = None
    return Transfer("ok", amount, "".join(char for char in receiver.get("Cuenta") or "" if char.isdigit()))
