"""Plantillas de WhatsApp que la dueña puede reescribir en Configuración → Mensajes.

Los textos por defecto y las variables viven en el frontend (src/app/core/message-templates.ts),
que es quien arma los mensajes; aquí solo se valida qué claves existen y se guardan los cambios.
"""

MESSAGE_KEYS = frozenset({
    "reminder", "booked", "deposit_ok", "proof_retry", "quote", "chat", "repeat",
    "review", "birthday", "miss_you", "opening", "waitlist", "share_link", "approved", "declined", "due",
})
MAX_TEMPLATE_LENGTH = 1000
