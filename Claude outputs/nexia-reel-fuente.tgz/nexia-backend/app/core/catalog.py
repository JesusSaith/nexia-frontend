"""Lo que cambia según el giro elegido al registrarse: cómo se llama el personal y qué servicios se sugieren."""

from app.models.business import Business

# Etiqueta del personal por giro.
STAFF_LABEL_BY_KIND = {
    "belleza": "Estilista",
    "unas": "Manicurista",
    "barberia": "Barbero",
    "spa": "Terapeuta",
    "veterinaria": "Veterinario",
    "consultorio": "Especialista",
    "dental": "Dentista",
    "estudio": "Profesional",
    # Ya no se ofrece al registrarse; se queda para los negocios que lo eligieron antes.
    "clases": "Instructor",
}

# (nombre, minutos, precio, categoría) por giro. Los precios son una referencia para que la dueña los ajuste.
CATALOG_BY_KIND: dict[str, list[tuple[str, int, float, str]]] = {
    "belleza": [("Corte de cabello", 45, 250, "Cabello"), ("Tinte", 120, 900, "Color"), ("Manicure", 45, 220, "Uñas"), ("Uñas acrílicas", 90, 450, "Uñas"), ("Peinado", 60, 350, "Cabello")],
    "unas": [("Manicure", 45, 220, "Manos"), ("Gelish en manos", 60, 300, "Manos"), ("Uñas acrílicas", 90, 450, "Uñas"), ("Pedicure", 60, 320, "Pies"), ("Retiro de acrílico o gel", 30, 120, "Uñas")],
    "barberia": [("Corte clásico", 40, 180, "Cortes"), ("Corte y barba", 60, 260, "Cortes"), ("Arreglo de barba", 30, 120, "Barba"), ("Afeitado con navaja", 40, 200, "Barba")],
    "spa": [("Masaje relajante", 60, 650, "Masajes"), ("Masaje descontracturante", 60, 750, "Masajes"), ("Facial hidratante", 50, 600, "Faciales"), ("Exfoliación corporal", 45, 550, "Corporales")],
    "veterinaria": [("Consulta general", 30, 400, "Consultas"), ("Vacuna", 20, 350, "Prevención"), ("Baño y corte", 90, 450, "Estética"), ("Desparasitación", 20, 250, "Prevención")],
    "consultorio": [("Consulta de primera vez", 60, 800, "Consultas"), ("Consulta de seguimiento", 45, 600, "Consultas"), ("Valoración", 30, 400, "Consultas")],
    "dental": [("Consulta y diagnóstico", 30, 400, "Consultas"), ("Limpieza dental", 45, 700, "Prevención"), ("Resina", 60, 900, "Tratamientos"), ("Blanqueamiento", 90, 2500, "Estética")],
    "estudio": [("Sesión", 60, 600, "Sesiones"), ("Sesión corta", 30, 350, "Sesiones"), ("Asesoría", 30, 300, "Asesorías")],
    "clases": [("Clase individual", 60, 350, "Clases"), ("Clase grupal", 60, 150, "Clases"), ("Evaluación física", 45, 300, "Evaluación")],
}

# Negocios creados antes de guardar el giro: se deduce de la etiqueta del personal.
_KIND_BY_STAFF_LABEL = {label: kind for kind, label in STAFF_LABEL_BY_KIND.items()}


def business_kind_of(business: Business) -> str | None:
    return business.business_kind or _KIND_BY_STAFF_LABEL.get(business.staff_label or "")


def catalog_for(business: Business) -> list[tuple[str, int, float, str]]:
    """Servicios típicos del giro; vacío si eligió "Otro"."""
    return CATALOG_BY_KIND.get(business_kind_of(business) or "", [])
