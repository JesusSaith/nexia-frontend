"""Quién puede ver y tocar qué agenda: dueña y administradora, toda; el personal (`staff`), solo la suya."""

from fastapi import HTTPException, status
from sqlmodel import Session, select

from app.models.staff import Staff
from app.models.user import User, UserRole

NO_ONE = -1  # un `staff` sin persona ligada no ve nada: ningún registro tiene este id


def own_staff_id(session: Session, user: User) -> int | None:
    """None si la cuenta ve toda la agenda; si es de personal, el id de su persona en el equipo."""
    if user.role != UserRole.staff:
        return None
    member = session.exec(select(Staff).where(Staff.user_id == user.id, Staff.business_id == user.business_id)).first()
    return member.id if member is not None and member.id is not None else NO_ONE


def ensure_own_staff(session: Session, user: User, staff_id: int) -> None:
    """Quien es de personal solo puede agendar, mover o bloquear en su propia agenda."""
    mine = own_staff_id(session, user)
    if mine is not None and staff_id != mine:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Solo puedes hacer cambios en tu propia agenda")
