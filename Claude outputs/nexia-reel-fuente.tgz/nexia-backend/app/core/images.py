"""Imágenes que llegan como data URL desde páginas públicas.

Solo se aceptan formatos de mapa de bits. SVG y cualquier otro tipo pueden llevar scripts: las rutas
que sirven estas imágenes viven en el mismo origen que el panel, así que un SVG abierto ahí podría
actuar con la sesión de la dueña.
"""

import base64
import binascii

from fastapi import Response

SAFE_IMAGE_TYPES = frozenset({"image/png", "image/jpeg", "image/webp", "image/gif"})
IMAGE_TYPES_HINT = "PNG, JPG, WebP o GIF"

# El navegador no debe adivinar el tipo ni ejecutar nada de lo que se sirve.
_SAFE_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "default-src 'none'; sandbox",
}


def _split(value: str) -> tuple[str, str] | None:
    header, sep, data = value.partition(",")
    if not sep or not header.startswith("data:") or not header.endswith(";base64"):
        return None
    media_type = header.removeprefix("data:").removesuffix(";base64").lower()
    return (media_type, data) if media_type in SAFE_IMAGE_TYPES else None


def is_safe_data_image(value: str) -> bool:
    """¿Es un data URL base64 de PNG, JPG, WebP o GIF?"""
    return _split(value) is not None


def is_valid_logo(value: str) -> bool:
    """Logo: imagen segura en data URL, enlace https o archivo propio (/uploads/...)."""
    return is_safe_data_image(value) or value.startswith(("https://", "/uploads/"))


def image_response(value: str, cache_control: str) -> Response | None:
    """La imagen lista para servir, o None si no es un data URL de un formato permitido."""
    parts = _split(value)
    if parts is None:
        return None
    media_type, data = parts
    try:
        content = base64.b64decode(data, validate=True)
    except (binascii.Error, ValueError):
        return None
    return Response(
        content=content,
        media_type=media_type,
        headers={"Cache-Control": cache_control, **_SAFE_HEADERS},
    )
