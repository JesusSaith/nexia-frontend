"""'Te toca': a quién le toca volver según cada cuánto viene por cada servicio.

Cada servicio puede decir cada cuántos días suelen volver (`Service.return_days`). Si no lo dice,
se calcula con el historial del negocio: la mediana de días entre visitas de la misma clienta a ese
servicio (con al menos 3 casos). Se toma la última visita completada de cada clienta por servicio.
"""

from datetime import date, datetime, timedelta
from statistics import median

from sqlmodel import Session, select

from app.core.booking import format_timestamp, open_slots
from app.core.clock import local_now, local_today
from app.models.appointment import Appointment, AppointmentStatus
from app.models.business import Business
from app.models.client import phone_key
from app.models.schedule import Schedule
from app.models.service import Service
from app.models.staff import Staff

MIN_DAYS, MAX_DAYS = 7, 180
# Se avisa unos días antes de que le toque, y deja de aparecer si ya pasó mucho (eso es "Dejaron de venir").
EARLY_DAYS, STALE_DAYS = 3, 60
SUGGEST_FOR = 20  # buscar horario sugerido solo para los primeros: cada búsqueda revisa la agenda


def return_days_by_service(services: list[Service], visits: list[Appointment]) -> dict[int, int]:
    """Días entre visitas por servicio: el que puso la dueña o la mediana del historial."""
    by_client: dict[tuple[str, int], list[date]] = {}
    for visit in visits:
        by_client.setdefault((phone_key(visit.client_phone), visit.service_id), []).append(visit.starts_at.date())
    gaps: dict[int, list[int]] = {}
    for (_, service_id), days in by_client.items():
        days.sort()
        gaps.setdefault(service_id, []).extend((later - earlier).days for earlier, later in zip(days, days[1:]) if (later - earlier).days > 0)
    result: dict[int, int] = {}
    for service in services:
        if service.id is None:
            continue
        if service.return_days:
            result[service.id] = service.return_days
        elif len(gaps.get(service.id, [])) >= 3:
            result[service.id] = min(max(round(median(gaps[service.id])), MIN_DAYS), MAX_DAYS)
    return result


def due_clients(session: Session, business: Business, limit: int = 50, only_new: bool = False) -> list[dict]:
    """Clientas a las que les toca volver, la más atrasada primero. only_new: sin invitación previa."""
    bid = business.id
    today = local_today(business)
    services = list(session.exec(select(Service).where(Service.business_id == bid)).all())
    names = {service.id: service for service in services}
    visits = list(session.exec(
        select(Appointment).where(Appointment.business_id == bid, Appointment.status == AppointmentStatus.completed).order_by(Appointment.starts_at)  # type: ignore[arg-type]
    ).all())
    every = return_days_by_service(services, visits)
    upcoming = {
        phone_key(row.client_phone)
        for row in session.exec(
            select(Appointment).where(
                Appointment.business_id == bid,
                Appointment.starts_at >= local_now(business),
                Appointment.status.in_([AppointmentStatus.scheduled, AppointmentStatus.awaiting_deposit]),  # type: ignore[attr-defined]
            )
        ).all()
    }
    latest: dict[tuple[str, int], Appointment] = {}
    for visit in visits:
        latest[(phone_key(visit.client_phone), visit.service_id)] = visit
    rows = []
    for (key, service_id), visit in latest.items():
        days = every.get(service_id)
        service = names.get(service_id)
        if not days or service is None or not service.is_active or key in upcoming:
            continue
        if only_new and visit.return_invited:
            continue
        due_on = visit.starts_at.date() + timedelta(days=days)
        if not (today - timedelta(days=STALE_DAYS) <= due_on <= today + timedelta(days=EARLY_DAYS)):
            continue
        rows.append({
            "appointment_id": visit.id,
            "client_name": visit.client_name,
            "client_phone": visit.client_phone,
            "service_id": service_id,
            "service_name": service.name,
            "staff_id": visit.staff_id,
            "last_visit": visit.starts_at.date().isoformat(),
            "every_days": days,
            "due_on": due_on.isoformat(),
            "days_late": max((today - due_on).days, 0),
            "invited": visit.return_invited,
            "suggested": None,
        })
    rows.sort(key=lambda row: row["due_on"])
    rows = rows[:limit]
    for row in rows[:SUGGEST_FOR]:
        row["suggested"] = _first_slot(session, business, row, names[row["service_id"]], today)
    return rows


def _first_slot(session: Session, business: Business, row: dict, service: Service, today: date) -> str | None:
    """El primer horario libre con la misma colaboradora desde el día que le toca (hasta 14 días)."""
    member = session.get(Staff, row["staff_id"])
    if member is None or not member.is_active:
        return None
    schedules = list(session.exec(select(Schedule).where(Schedule.business_id == business.id, Schedule.staff_id == member.id)).all())
    start = max(date.fromisoformat(row["due_on"]), today + timedelta(days=1))
    for offset in range(14):
        day = start + timedelta(days=offset)
        slots = open_slots(session, business.id, member.id, day, service.duration_minutes, schedules, service_id=service.id, capacity=service.capacity)  # type: ignore[arg-type]
        if slots:
            return format_timestamp(slots[0])
    return None


def suggested_label(value: str | None) -> str:
    """"jueves 23 de octubre a las 11:00" para el mensaje."""
    if not value:
        return ""
    moment = datetime.fromisoformat(value)
    return f"{long_day(moment.date())} a las {moment.strftime('%H:%M')}"


_DAYS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
_MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def long_day(day: date) -> str:
    return f"{_DAYS[day.weekday()]} {day.day} de {_MONTHS[day.month - 1]}"
