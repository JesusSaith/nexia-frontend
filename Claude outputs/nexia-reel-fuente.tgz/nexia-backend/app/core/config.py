from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration loaded from the environment and an optional .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    DATABASE_URL: str = "sqlite:///./nexia_dev.db"
    JWT_SECRET: str = "replace-with-a-random-string-of-at-least-32-characters"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_SECONDS: int = 86_400
    COOKIE_NAME: str = "access_token"
    # False while the API is served over HTTP on localhost.
    COOKIE_SECURE: bool = False
    COOKIE_SAMESITE: str = "lax"
    # Cuántos proxies de confianza agregan su salto a X-Forwarded-For antes de llegar a la API.
    # 0 = ignorar el encabezado (local). Detrás de Vercel → Render son 2: "clienta, vercel".
    TRUSTED_PROXY_HOPS: int = 0
    # Dónde vive la app web; la ruta /s/{slug} redirige ahí después de dar la vista previa.
    FRONTEND_URL: str = "http://localhost:4200"
    # "production" activa las revisiones de seguridad al arrancar.
    ENVIRONMENT: str = "development"
    # Correos (recuperar contraseña, bienvenida). Sin clave, los correos solo se escriben en el log.
    RESEND_API_KEY: str = ""
    # Remitente; el dominio debe estar verificado en Resend. Para probar sirve "onboarding@resend.dev".
    MAIL_FROM: str = "Nexia <onboarding@resend.dev>"
    # API oficial de WhatsApp (Meta Cloud API). Sin token, los mensajes automáticos no salen y se escriben en el log.
    WHATSAPP_TOKEN: str = ""
    WHATSAPP_PHONE_ID: str = ""
    # Lo que se escribe en Meta al registrar el webhook (/api/whatsapp/webhook).
    WHATSAPP_VERIFY_TOKEN: str = ""
    # Secreto de la app de Meta: valida que los avisos del webhook vienen de Meta.
    WHATSAPP_APP_SECRET: str = ""
    # Plantillas aprobadas en Meta (los mensajes que inicia el negocio deben ser plantillas).
    WHATSAPP_REMINDER_TEMPLATE: str = "nexia_recordatorio"
    WHATSAPP_RETURN_TEMPLATE: str = "nexia_te_toca"
    WHATSAPP_LANG: str = "es_MX"
    # FUTURE_PHASE_SPEI: verificar transferencias SPEI con el CEP de Banxico. Apagado hasta probarlo
    # con transferencias reales; con False la API responde spei_check=false y la página no lo ofrece.
    SPEI_CHECK: bool = False
    # Opcional: errores a Sentry (requiere instalar sentry-sdk).
    SENTRY_DSN: str = ""
    # Cuenta de plataforma (super admin). Solo se crea si se definen las dos; no hay una por defecto.
    SUPERADMIN_EMAIL: str = ""
    SUPERADMIN_PASSWORD: str = ""


def production_problems(config: "Settings") -> list[str]:
    """Lo que no puede salir a producción tal cual; el servidor se niega a arrancar si hay algo."""
    problems = []
    if config.JWT_SECRET.startswith("replace-with") or len(config.JWT_SECRET) < 32:
        problems.append("JWT_SECRET: usa una cadena aleatoria de 32+ caracteres (python -c 'import secrets; print(secrets.token_urlsafe(48))')")
    if not config.COOKIE_SECURE:
        problems.append("COOKIE_SECURE debe ser true (la API va por HTTPS)")
    if config.DATABASE_URL.startswith("sqlite"):
        problems.append("DATABASE_URL: usa PostgreSQL en producción")
    if not config.FRONTEND_URL.startswith("https://"):
        problems.append("FRONTEND_URL debe ser el dominio https de la app")
    return problems


settings = Settings()
# Render/Heroku entregan "postgres://", que SQLAlchemy ya no acepta.
if settings.DATABASE_URL.startswith("postgres://"):
    settings.DATABASE_URL = "postgresql://" + settings.DATABASE_URL.removeprefix("postgres://")
