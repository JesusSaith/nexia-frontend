from datetime import date, datetime, time, timedelta

from sqlmodel import Session, select

from app.core.clock import local_now, to_local_naive
from app.models.service import Service
from app.models.appointment import Appointment, AppointmentStatus
from app.models.schedule import Schedule
from app.models.staff import Staff
from app.models.time_block import TimeBlock

DEFAULT_START = time(9, 0)
DEFAULT_END = time(18, 0)


def owed_deposit(business: object, service: object, quoted_price: float | None) -> float | None:
    account = getattr(business, "deposit_account", None)
    if not account:
        return None
    percent = getattr(business, "deposit_percent", None)
    if getattr(service, "variable_price", False) and percent:
        if quoted_price is None:
            return None
        amount = round(float(quoted_price) * int(percent) / 100, 2)
        return amount or None
    fixed = getattr(service, "deposit_amount", None)
    if fixed is None:
        fixed = getattr(business, "deposit_amount", None)
    return float(fixed) if fixed else None


def format_timestamp(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H:%M:%S")


def as_local_naive(value: datetime, business: object | None = None) -> datetime:
    return to_local_naive(value, business)


def working_windows(schedules: list[Schedule], day_of_week: int) -> list[tuple[time, time]]:
    active = [row for row in schedules if row.is_active]
    if not active:
        return [(DEFAULT_START, DEFAULT_END)]

    windows: list[tuple[time, time]] = []
    for row in active:
        if row.day_of_week != day_of_week:
            continue
        start = _parse_clock(row.start_time)
        end = _parse_clock(row.end_time)
        if start < end:
            windows.append((start, end))
    return windows


def special_for(session: Session, business_id: int, staff_id: int, day: date) -> "SpecialHours | None":
    """El horario especial de ese día: el de la persona gana sobre el de todo el equipo."""
    from app.models.special_hours import SpecialHours

    rows = session.exec(
        select(SpecialHours).where(
            SpecialHours.business_id == business_id,
            SpecialHours.date_from <= day,
            SpecialHours.date_to >= day,
        )
    ).all()
    mine = [item for item in rows if item.staff_id == staff_id]
    everyone = [item for item in rows if item.staff_id is None]
    return (mine or everyone or [None])[-1]


def business_hours(session: Session, business_id: int) -> list[str]:
    """Horario general del negocio, de lo que trabaja el equipo activo: ["Lun a vie · 09:00–18:00", "Sáb · 10:00–14:00"]."""
    staff_ids = [item.id for item in session.exec(select(Staff).where(Staff.business_id == business_id, Staff.is_active == True)).all()]  # noqa: E712
    days: dict[int, tuple[str, str]] = {}
    for row in session.exec(select(Schedule).where(Schedule.business_id == business_id, Schedule.is_active == True)).all():  # noqa: E712
        if row.staff_id not in staff_ids:
            continue
        start, end = row.start_time[:5], row.end_time[:5]
        old = days.get(row.day_of_week)
        days[row.day_of_week] = (min(start, old[0]), max(end, old[1])) if old else (start, end)
    names = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
    out: list[str] = []
    run: list[int] = []
    for day in range(8):
        if run and (day == 7 or days.get(day) != days.get(run[0]) or day != run[-1] + 1):
            hours = days[run[0]]
            label = names[run[0]] if len(run) == 1 else f"{names[run[0]]} a {names[run[-1]].lower()}"
            out.append(f"{label} · {hours[0]}–{hours[1]}")
            run = []
        if day < 7 and day in days:
            run.append(day)
    return out


def generate_slots(day: date, windows: list[tuple[time, time]], duration_minutes: int) -> list[datetime]:
    step = timedelta(minutes=duration_minutes)
    slots: list[datetime] = []
    for start_clock, end_clock in windows:
        cursor = datetime.combine(day, start_clock)
        limit = datetime.combine(day, end_clock)
        while cursor + step <= limit:
            slots.append(cursor)
            cursor += step
    return sorted(set(slots))


def busy_appointments(
    session: Session,
    business_id: int,
    staff_id: int,
    day: date,
    ignore_id: int | None = None,
) -> list[Appointment]:
    day_start = datetime.combine(day, time.min)
    day_end = day_start + timedelta(days=1)
    statement = select(Appointment).where(
        Appointment.business_id == business_id,
        Appointment.staff_id == staff_id,
        Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
        Appointment.starts_at < day_end,
        Appointment.ends_at > day_start,
    )
    if ignore_id is not None:
        statement = statement.where(Appointment.id != ignore_id)
    return list(session.exec(statement).all())


def _gap(session: Session, business_id: int) -> timedelta:
    from app.models.business import Business

    business = session.get(Business, business_id)
    return timedelta(minutes=(business.buffer_minutes or 0) if business else 0)


def busy_spans(start: datetime, end: datetime, service: object | None) -> list[tuple[datetime, datetime]]:
    """
    Tramos en los que la colaboradora está ocupada por una cita: toda la cita más la limpieza, menos la
    espera del servicio (por ejemplo, mientras actúa un tinte puede atender a otra clienta).
    """
    cleanup = timedelta(minutes=getattr(service, "cleanup_minutes", 0) or 0)
    wait_start = getattr(service, "wait_start", None)
    wait = getattr(service, "wait_minutes", 0) or 0
    if wait and wait_start and start + timedelta(minutes=wait_start + wait) < end:
        pause = start + timedelta(minutes=wait_start)
        return [(start, pause), (pause + timedelta(minutes=wait), end + cleanup)]
    return [(start, end + cleanup)]


def _spans_clash(left: list[tuple[datetime, datetime]], right: list[tuple[datetime, datetime]], gap: timedelta) -> bool:
    return any(a < d + gap and c < b + gap for a, b in left for c, d in right)


def has_staff_overlap(
    session: Session,
    business_id: int,
    staff_id: int,
    start: datetime,
    end: datetime,
    ignore_id: int | None = None,
    service_id: int | None = None,
    capacity: int = 1,
) -> bool:
    gap = _gap(session, business_id)
    services = {item.id: item for item in session.exec(select(Service).where(Service.business_id == business_id)).all()}
    mine = busy_spans(start, end, services.get(service_id))
    # Margen amplio por la limpieza; el choque exacto lo deciden los tramos.
    statement = select(Appointment).where(
        Appointment.business_id == business_id,
        Appointment.staff_id == staff_id,
        Appointment.status.notin_([AppointmentStatus.cancelled, AppointmentStatus.no_show]),
        Appointment.starts_at < mine[-1][1] + gap,
        Appointment.ends_at > start - gap - timedelta(hours=4),
    )
    if ignore_id is not None:
        statement = statement.where(Appointment.id != ignore_id)
    rows = [row for row in session.exec(statement).all() if _spans_clash(mine, busy_spans(row.starts_at, row.ends_at, services.get(row.service_id)), gap)]
    if capacity > 1 and service_id:
        same = [row for row in rows if row.service_id == service_id and row.starts_at == start]
        if [row for row in rows if row not in same] or len(same) >= capacity:
            return True
    elif rows:
        return True
    if _standing_hits(session, business_id, staff_id, start, end):
        return True
    blocked = select(TimeBlock.id).where(
        TimeBlock.business_id == business_id,
        TimeBlock.staff_id == staff_id,
        TimeBlock.starts_at < end,
        TimeBlock.ends_at > start,
    )
    return session.exec(blocked).first() is not None


def slot_is_free(start: datetime, end: datetime, appointments: list[Appointment]) -> bool:
    return all(start >= item.ends_at or end <= item.starts_at for item in appointments)


def release_expired_deposits(session: Session, business_id: int) -> None:
    from app.models.business import Business
    from app.routers.notices import add_notice, visit_when

    business = session.get(Business, business_id)
    if business is None:
        return
    hours = business.deposit_hold_hours or 3
    limit = local_now(business) - timedelta(hours=hours)
    rows = list(
        session.exec(
            select(Appointment).where(
                Appointment.business_id == business_id,
                Appointment.status == AppointmentStatus.awaiting_deposit,
                Appointment.created_at < limit,
                # Si ya mandó comprobante o dijo que pagó, espera a que la dueña lo revise: no se libera.
                Appointment.payment_proof == None,  # noqa: E711
                Appointment.paid_claim == False,  # noqa: E712
            )
        ).all()
    )
    if not rows:
        return
    for row in rows:
        row.status = AppointmentStatus.cancelled
        if row.use_package:
            from app.models.package import give_package

            give_package(session, business_id, row.client_phone)
        session.add(row)
        add_notice(session, business_id, f"Se liberó el horario de {row.client_name} {visit_when(row.starts_at)} #{row.id}", "deposit_expired")
    session.commit()


def open_slots(
    session: Session,
    business_id: int,
    staff_id: int,
    day: date,
    duration_minutes: int,
    schedules: list[Schedule],
    ignore_id: int | None = None,
    service_id: int | None = None,
    capacity: int = 1,
) -> list[datetime]:
    release_expired_deposits(session, business_id)
    windows = working_windows(schedules, day.weekday())
    member = session.get(Staff, staff_id)
    row = next((item for item in schedules if item.day_of_week == day.weekday() and item.is_active), None)
    special = special_for(session, business_id, staff_id, day)
    if special is not None:
        # Un horario especial manda sobre el turno normal (sin su descanso).
        windows = [] if special.closed else [(_parse_clock(special.start_time), _parse_clock(special.end_time))]
        row = None
    raw = (row.slot_times if row and row.slot_times else None) or (member.slot_times if member else None)
    fixed = _fixed_clocks(raw)
    if fixed:
        candidates: list[datetime] = []
        for start_clock, end_clock in windows:
            for clock in fixed:
                if start_clock <= clock <= end_clock:
                    candidates.append(datetime.combine(day, clock))
        candidates = sorted(set(candidates))
    else:
        candidates = generate_slots(day, windows, duration_minutes)
    taken = busy_appointments(session, business_id, staff_id, day, ignore_id)
    gap = _gap(session, business_id)
    day_start = datetime.combine(day, time.min)
    blocked = session.exec(
        select(TimeBlock).where(
            TimeBlock.business_id == business_id,
            TimeBlock.staff_id == staff_id,
            TimeBlock.starts_at < day_start + timedelta(days=1),
            TimeBlock.ends_at > day_start,
        )
    ).all()
    services = {item.id: item for item in session.exec(select(Service).where(Service.business_id == business_id)).all()}
    busy = [
        Appointment(
            business_id=business_id,
            staff_id=staff_id,
            service_id=item.service_id,
            starts_at=span_start,
            ends_at=span_end + gap,
            client_name=item.client_name,
            client_phone=item.client_phone,
        )
        for item in taken
        for span_start, span_end in busy_spans(item.starts_at, item.ends_at, services.get(item.service_id))
    ] + [
        Appointment(
            business_id=business_id,
            staff_id=staff_id,
            service_id=0,
            starts_at=block.starts_at,
            ends_at=block.ends_at,
            client_name="",
            client_phone="",
        )
        for block in blocked
    ]
    for start_at, end_at in standing_span(session, business_id, staff_id, day):
        busy.append(
            Appointment(
                business_id=business_id,
                staff_id=staff_id,
                service_id=0,
                starts_at=start_at,
                ends_at=end_at,
                client_name="",
                client_phone="",
            )
        )
    if row and row.break_start and row.break_end:
        pause_start = datetime.combine(day, _parse_clock(row.break_start))
        pause_end = datetime.combine(day, _parse_clock(row.break_end))
        candidates = [
            start
            for start in candidates
            if start >= pause_end or start + timedelta(minutes=duration_minutes) <= pause_start
        ]
    free: list[datetime] = []
    for start in candidates:
        end = start + timedelta(minutes=duration_minutes)
        same = [item for item in taken if capacity > 1 and service_id and item.service_id == service_id and item.starts_at == start]
        others = [item for item in busy if not (capacity > 1 and service_id and item.service_id == service_id and item.starts_at == start)]
        spans = busy_spans(start, end, services.get(service_id))
        if len(same) < max(capacity, 1) and all(slot_is_free(a, b, others) for a, b in spans):
            free.append(start)
    return free


def standing_span(session: Session, business_id: int, staff_id: int, day: date) -> list[tuple[datetime, datetime]]:
    from app.models.standing_block import StandingBlock

    weekday = str(day.weekday())
    rows = session.exec(
        select(StandingBlock).where(StandingBlock.business_id == business_id, StandingBlock.staff_id == staff_id)
    ).all()
    spans: list[tuple[datetime, datetime]] = []
    for row in rows:
        if weekday not in row.weekdays.split(","):
            continue
        spans.append((datetime.combine(day, _parse_clock(row.start_time)), datetime.combine(day, _parse_clock(row.end_time))))
    return spans


def _standing_hits(session: Session, business_id: int, staff_id: int, start: datetime, end: datetime) -> bool:
    for block_start, block_end in standing_span(session, business_id, staff_id, start.date()):
        if block_start < end and block_end > start:
            return True
    return False


def _parse_clock(value: str) -> time:
    hour, minute, *_rest = value.split(":")
    return time(int(hour), int(minute))


def _fixed_clocks(raw: str | None) -> list[time]:
    if not raw or not raw.strip():
        return []
    clocks: list[time] = []
    for part in raw.split(","):
        part = part.strip()
        if part:
            clocks.append(_parse_clock(part[:5]))
    return clocks


def ten_digit_phone(phone: str) -> str | None:
    """Los 10 dígitos del teléfono (acepta espacios, guiones y lada 52/+52), o None si no son 10."""
    digits = "".join(char for char in phone if char.isdigit())
    if len(digits) == 12 and digits.startswith("52"):
        digits = digits[2:]
    elif len(digits) == 13 and digits.startswith("521"):
        digits = digits[3:]
    return digits if len(digits) == 10 else None


def lock_staff(session: Session, staff_id: int) -> None:
    """Fila de la persona bloqueada hasta el commit: dos reservas a la vez no ven el mismo hueco libre.

    En PostgreSQL es un FOR UPDATE; SQLite (desarrollo) ya serializa las escrituras y lo ignora.
    """
    session.exec(select(Staff).where(Staff.id == staff_id).with_for_update())  # type: ignore[arg-type]


def sweep_deposits(session: Session) -> None:
    """Revisión periódica de anticipos de todos los negocios: libera horarios vencidos y avisa de los que siguen sin pago.

    Corre en segundo plano (app/main.py), para que las consultas de Inicio no escriban en la base.
    """
    from app.models.business import Business
    from app.routers.notices import warn_deposits

    for business_id in session.exec(select(Business.id).where(Business.is_active.is_(True))).all():  # type: ignore[attr-defined]
        if business_id is None:
            continue
        release_expired_deposits(session, business_id)
        warn_deposits(session, business_id)
