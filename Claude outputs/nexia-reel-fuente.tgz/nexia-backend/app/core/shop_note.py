"""Pausa, cierres (vacaciones y días festivos), fotos y promoción del negocio.

Antes el panel los guardaba empaquetados al final de `Business.resources` (texto + "\\n#nx" + JSON).
Ahora tienen columnas propias; `unpack_resources` solo existe para migrar lo que quedó con el
formato viejo (lo llama init_db al arrancar).
"""

import json
from datetime import date

MARK = "\n#nx"


def unpack_resources(resources: str | None) -> tuple[str | None, dict]:
    """("Sala 1, Sala 2", {"pause": 1, "from": …}) a partir del texto empaquetado; (texto, {}) si no trae paquete."""
    source = resources or ""
    cut = source.find(MARK)
    if cut < 0:
        return resources, {}
    try:
        parsed = json.loads(source[cut + len(MARK):])
    except ValueError:
        parsed = {}
    text = source[:cut].strip() or None
    return text, parsed if isinstance(parsed, dict) else {}


MAX_CLOSURES = 40


def closures_of(business: object) -> list[dict]:
    """Lista de cierres guardada en `Business.closures`, ordenada por fecha; [] si no hay o está mal."""
    return parse_closures(getattr(business, "closures", None))


def parse_closures(raw: object) -> list[dict]:
    if isinstance(raw, list):
        return clean_closures(raw)
    try:
        rows = json.loads(raw) if isinstance(raw, str) and raw else []
    except ValueError:
        return []
    return clean_closures(rows)


def clean_closures(rows: object) -> list[dict]:
    if not isinstance(rows, list):
        return []
    clean = [
        {"from": row["from"], "to": row["to"], "label": str(row.get("label") or "").strip()[:60]}
        for row in rows
        if isinstance(row, dict) and isinstance(row.get("from"), str) and isinstance(row.get("to"), str)
    ]
    return sorted(clean, key=lambda row: row["from"])


def pack_closures(rows: list[dict]) -> str | None:
    clean = clean_closures(rows)
    return json.dumps(clean, ensure_ascii=False) if clean else None


def closed_reason(business: object, day: date) -> str | None:
    """Por qué no se puede reservar ese día en la página pública, o None si sí se puede."""
    if getattr(business, "bookings_paused", False):
        return "Por ahora no estamos tomando citas en línea. Escríbenos por WhatsApp."
    iso = day.isoformat()
    for row in closures_of(business):
        if row["from"] <= iso <= row["to"]:
            if row["from"] == row["to"]:
                return f"Ese día ({row['label'] or iso}) no abrimos. Elige otro día."
            return f"Cerramos del {row['from']} al {row['to']}. Elige otro día."
    return None
