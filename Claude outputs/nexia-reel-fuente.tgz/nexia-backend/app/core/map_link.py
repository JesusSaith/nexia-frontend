"""Lo que la dueña pega en Configuración → Ubicación: el código "Insertar un mapa" de Google (un <iframe>) o un enlace.

De cualquiera de los dos sale el punto del local (latitud y longitud) y, si pegó el iframe, la dirección del mapa para
mostrarlo tal cual en "Cómo llegar". Los enlaces cortos (maps.app.goo.gl) se siguen en el servidor porque el navegador no
puede leerlos; solo se visitan dominios de Google, por https y con pocos saltos, para que no sirva para llegar a otros sitios.
"""

import re
import urllib.error
import urllib.parse
import urllib.request

EMBED_PREFIX = "https://www.google.com/maps/embed?pb="
EMBED_MAX = 800
_EMBED_CHARS = re.compile(r"^[A-Za-z0-9!%._~\-+=&:,;/@*()'?]+$")
_IFRAME_SRC = re.compile(r"""<iframe[^>]*?\ssrc\s*=\s*["']([^"']+)["']""", re.IGNORECASE)
SHORT_HOSTS = {"maps.app.goo.gl", "goo.gl"}
_GOOGLE_HOST = re.compile(r"^(?:www\.|maps\.)?google\.(?:com|com\.mx)$")
MAX_HOPS = 5
TIMEOUT_SECONDS = 5

_POINT_PATTERNS = [
    # Lugar dentro de un enlace largo: ...!3d19.43!4d-99.13
    re.compile(r"!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)"),
    # Centro del mapa incrustado: ...!2d-99.13!3d19.43 (primero la longitud)
    re.compile(r"!2d(-?\d+(?:\.\d+)?)!3d(-?\d+(?:\.\d+)?)"),
    re.compile(r"@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)"),
    re.compile(r"[?&](?:q|query|ll|destination)=(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)"),
]


def embed_src(text: str) -> str | None:
    """La dirección del mapa incrustado, solo si es de Google Maps; si no, None."""
    text = text.strip()
    found = _IFRAME_SRC.search(text)
    candidate = (found.group(1) if found else text).replace("&amp;", "&").strip()
    if candidate.startswith(EMBED_PREFIX) and len(candidate) <= EMBED_MAX and _EMBED_CHARS.match(candidate):
        return candidate
    return None


def point_from_text(text: str) -> tuple[float, float] | None:
    """(latitud, longitud) leídas de un enlace o del src de un mapa incrustado."""
    decoded = urllib.parse.unquote(text)
    for index, pattern in enumerate(_POINT_PATTERNS):
        match = pattern.search(decoded)
        if not match:
            continue
        first, second = float(match.group(1)), float(match.group(2))
        lat, lng = (second, first) if index == 1 else (first, second)
        if abs(lat) <= 90 and abs(lng) <= 180:
            return lat, lng
    return None


def _trusted(url: str) -> bool:
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    return parts.scheme == "https" and (host in SHORT_HOSTS or bool(_GOOGLE_HOST.match(host)))


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):  # noqa: ANN002, ANN003
        return None


def _next_hop(url: str) -> str | None:
    """Pide la página sin seguir el salto y devuelve a dónde manda (None si ya no manda a ningún lado)."""
    opener = urllib.request.build_opener(_NoRedirect)
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; Nexia/1.0)", "Accept-Language": "es-MX"})
    try:
        response = opener.open(request, timeout=TIMEOUT_SECONDS)
        response.close()
        return None
    except urllib.error.HTTPError as error:
        location = error.headers.get("Location") if error.code in (301, 302, 303, 307, 308) else None
        return urllib.parse.urljoin(url, location) if location else None
    except (urllib.error.URLError, TimeoutError, OSError):
        return None


def resolve_point(url: str, hop=_next_hop) -> tuple[float, float] | None:
    """Sigue un enlace corto de Google Maps hasta encontrar el punto. `hop` se cambia en las pruebas."""
    current = url.strip()
    for _ in range(MAX_HOPS):
        if not _trusted(current):
            return None
        point = point_from_text(current)
        if point:
            return point
        following = hop(current)
        if not following:
            return None
        current = following
    return point_from_text(current) if _trusted(current) else None


def read_map_input(text: str, hop=_next_hop) -> dict:
    """Lo que se guarda: {"latitude", "longitude", "embed"}; cualquier dato que no salga queda en None."""
    text = text.strip()
    embed = embed_src(text)
    point = point_from_text(embed) if embed else None
    if point is None and embed is None:
        found = _IFRAME_SRC.search(text)
        link = (found.group(1) if found else text).replace("&amp;", "&")
        if re.match(r"^https?://", link):
            point = resolve_point(link, hop)
    return {"latitude": point[0] if point else None, "longitude": point[1] if point else None, "embed": embed}
