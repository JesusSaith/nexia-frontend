import hashlib
from datetime import datetime, timedelta, timezone

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
_ALLOWED_ALGORITHMS = {"HS256", "HS384", "HS512"}


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except (ValueError, TypeError):
        return False


def create_access_token(subject: str) -> str:
    if settings.ALGORITHM not in _ALLOWED_ALGORITHMS:
        raise RuntimeError("ALGORITHM must be HS256, HS384, or HS512")

    expires_at = datetime.now(timezone.utc) + timedelta(
        seconds=settings.ACCESS_TOKEN_EXPIRE_SECONDS
    )
    payload = {"sub": subject, "exp": expires_at}
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> str:
    if settings.ALGORITHM not in _ALLOWED_ALGORITHMS:
        raise JWTError("Unsupported algorithm")

    payload = jwt.decode(
        token,
        settings.JWT_SECRET,
        algorithms=[settings.ALGORITHM],
    )
    if payload.get("purpose"):
        # Un enlace de recuperación no sirve como sesión.
        raise JWTError("Not a session token")
    subject = payload.get("sub")
    if not isinstance(subject, str) or not subject:
        raise JWTError("Missing subject")
    return subject


RESET_TOKEN_MINUTES = 60


def _password_fingerprint(hashed_password: str) -> str:
    return hashlib.sha256(hashed_password.encode()).hexdigest()[:16]


def create_reset_token(user_id: int, hashed_password: str) -> str:
    """Enlace de un solo uso: lleva la huella de la contraseña actual; al cambiarla deja de valer."""
    payload = {
        "sub": str(user_id),
        "purpose": "reset",
        "pwd": _password_fingerprint(hashed_password),
        "exp": datetime.now(timezone.utc) + timedelta(minutes=RESET_TOKEN_MINUTES),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.ALGORITHM)


def read_reset_token(token: str) -> tuple[int, str]:
    """(id del usuario, huella de contraseña) o JWTError si venció o no es de recuperación."""
    payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.ALGORITHM])
    if payload.get("purpose") != "reset" or not isinstance(payload.get("pwd"), str):
        raise JWTError("Not a reset token")
    try:
        return int(payload["sub"]), payload["pwd"]
    except (KeyError, TypeError, ValueError):
        raise JWTError("Missing subject") from None


def reset_token_matches(fingerprint: str, hashed_password: str) -> bool:
    return fingerprint == _password_fingerprint(hashed_password)
