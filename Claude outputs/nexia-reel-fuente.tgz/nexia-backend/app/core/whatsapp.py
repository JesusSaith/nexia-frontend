"""Mensajes por la API oficial de WhatsApp (Meta Cloud API).

Los mensajes que inicia el negocio (recordatorios, "te toca") deben ser plantillas aprobadas en Meta;
las respuestas dentro de las 24 h después de que la clienta escribe pueden ser texto libre.
Sin WHATSAPP_TOKEN (desarrollo) nada sale: el mensaje se escribe en el log y se responde False.
"""

import json
import logging
import urllib.error
import urllib.request

from app.core.config import settings

logger = logging.getLogger("nexia.whatsapp")

GRAPH_URL = "https://graph.facebook.com/v21.0"


def whatsapp_ready() -> bool:
    return bool(settings.WHATSAPP_TOKEN and settings.WHATSAPP_PHONE_ID)


def to_e164(phone: str) -> str:
    """Los teléfonos se guardan con 10 dígitos; WhatsApp los quiere con el 52 de México."""
    digits = "".join(char for char in phone if char.isdigit())
    return f"52{digits}" if len(digits) == 10 else digits


def send_template(phone: str, template: str, params: list[str], buttons: list[str] | None = None) -> bool:
    """Plantilla con variables {{1}}, {{2}}… y botones de respuesta rápida (su payload vuelve por el webhook)."""
    components: list[dict] = [{"type": "body", "parameters": [{"type": "text", "text": value or "-"} for value in params]}]
    for index, payload in enumerate(buttons or []):
        components.append({"type": "button", "sub_type": "quick_reply", "index": str(index), "parameters": [{"type": "payload", "payload": payload}]})
    return _post({
        "messaging_product": "whatsapp",
        "to": to_e164(phone),
        "type": "template",
        "template": {"name": template, "language": {"code": settings.WHATSAPP_LANG}, "components": components},
    }, f"plantilla {template} {params}")


def send_text(phone: str, text: str) -> bool:
    return _post({"messaging_product": "whatsapp", "to": to_e164(phone), "type": "text", "text": {"body": text[:4096]}}, text)


def _post(body: dict, summary: str) -> bool:
    if not whatsapp_ready():
        logger.warning("WhatsApp sin enviar (falta WHATSAPP_TOKEN) → %s · %s", body.get("to"), summary)
        return False
    request = urllib.request.Request(
        f"{GRAPH_URL}/{settings.WHATSAPP_PHONE_ID}/messages",
        data=json.dumps(body).encode(),
        method="POST",
        headers={"Authorization": f"Bearer {settings.WHATSAPP_TOKEN}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            response.read()
        return True
    except (urllib.error.URLError, TimeoutError) as error:
        logger.error("No se pudo enviar el WhatsApp a %s: %s", body.get("to"), error)
        return False
