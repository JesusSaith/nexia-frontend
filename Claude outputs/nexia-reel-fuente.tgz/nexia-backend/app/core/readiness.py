"""Qué le falta al negocio: una sola lista para Inicio, Mi negocio y Configuración.

Antes cada pantalla armaba la suya con varias peticiones y no coincidían. Aquí se calcula todo con
la base a la vista, y "Comparte tu enlace" se guarda en el negocio en vez de en un navegador.
"""

from sqlmodel import Session, select

from app.models.business import Business
from app.models.schedule import Schedule
from app.models.service import Service
from app.models.staff import Staff

# group: "arranque" = sin esto no se puede reservar; "perfil" = da confianza; "aviso" = algo está mal configurado.


def readiness(session: Session, business: Business) -> dict:
    bid = business.id
    services = session.exec(select(Service).where(Service.business_id == bid, Service.is_active == True)).all()  # noqa: E712
    staff_ids = [row.id for row in session.exec(select(Staff).where(Staff.business_id == bid, Staff.is_active == True)).all()]  # noqa: E712
    has_hours = bool(staff_ids) and session.exec(
        select(Schedule.id).where(Schedule.business_id == bid, Schedule.staff_id.in_(staff_ids), Schedule.is_active == True)  # type: ignore[attr-defined]  # noqa: E712
    ).first() is not None

    steps = [
        _step("services", "Activa tus servicios", bool(services), "/admin/services", "arranque"),
        _step("staff", "Agrega a tu equipo", bool(staff_ids), "/admin/staff", "arranque"),
        _step("schedules", "Pon los horarios de trabajo", has_hours, "/admin/schedules", "arranque"),
        _step("share", "Comparte tu enlace de reservas", bool(business.link_shared), "/admin/negocio", "arranque"),
        _step("logo", "Sube el logo de tu marca", bool(business.logo_url), "/admin/settings", "perfil", "apariencia"),
        _step("description", "Cuenta qué hace tu negocio", bool((business.description or "").strip()), "/admin/settings", "perfil", "negocio"),
        _step("address", "Agrega la dirección del local", bool((business.address or "").strip()), "/admin/settings", "perfil", "negocio"),
        _step("location", "Marca tu local en el mapa", business.latitude is not None, "/admin/settings", "perfil", "negocio"),
        _step("instagram", "Agrega tu Instagram", bool((business.instagram or "").strip()), "/admin/settings", "perfil", "negocio"),
    ]
    # Avisos: solo aparecen cuando aplican, y nunca como "hechos".
    asks_deposit = bool(business.deposit_amount or business.deposit_percent) or any(row.deposit_amount for row in services)
    if asks_deposit and not (business.deposit_account or "").strip():
        steps.append(_step("deposit_account", "Pon tu cuenta o CLABE: sin ella no se cobra el anticipo", False, "/admin/settings", "aviso", "anticipo"))
    if business.bookings_paused:
        steps.append(_step("paused", "Tu página está en pausa: no está tomando citas", False, "/admin/settings", "aviso", "pausa"))

    essentials = [step for step in steps if step["group"] == "arranque" and step["key"] != "share"]
    return {"can_book": all(step["done"] for step in essentials), "steps": steps}


def _step(key: str, label: str, done: bool, path: str, group: str, section: str | None = None) -> dict:
    # section: la sección de Configuración que se abre (/admin/settings?sec=…).
    return {"key": key, "label": label, "done": done, "path": path, "group": group, "section": section}
