"""Los textos de cada correo. Se arman aquí y se envían con send_email en segundo plano."""

from html import escape

from app.core.mailer import layout
from app.core.security import RESET_TOKEN_MINUTES


# Cada función recibe `app`: la dirección de la app web (ver app/core/origins.py).


def welcome(app: str, full_name: str, business_name: str, slug: str) -> tuple[str, str, str]:
    booking = f"{app}/{slug}/book"
    first = full_name.split()[0] if full_name.strip() else ""
    subject = f"{business_name} ya tiene página de reservas"
    steps = ["Revisa y activa tus servicios.", "Agrega a tu equipo.", "Pon los horarios de trabajo."]
    html = layout(
        f"¡Listo, {first}!" if first else "¡Listo!",
        [
            f"<strong>{escape(business_name)}</strong> ya tiene su página de reservas:",
            f'<a href="{escape(booking)}" style="color:#1c1a19;font-weight:600">{escape(booking)}</a>',
            "Para empezar a recibir citas te faltan tres pasos:<br>"
            + "<br>".join(f"{n}. {escape(step)}" for n, step in enumerate(steps, 1)),
            "Cuando estén listos, comparte el enlace en tu WhatsApp e Instagram.",
        ],
        button=("Entrar a mi panel", f"{app}/admin"),
    )
    text = (
        f"¡Listo{', ' + first if first else ''}!\n\n{business_name} ya tiene su página de reservas: {booking}\n\n"
        "Para empezar a recibir citas:\n" + "\n".join(f"{n}. {step}" for n, step in enumerate(steps, 1))
        + f"\n\nEntra a tu panel: {app}/admin\n"
    )
    return subject, html, text


def password_reset(app: str, full_name: str, token: str) -> tuple[str, str, str]:
    link = f"{app}/auth/restablecer?token={token}"
    first = full_name.split()[0] if full_name.strip() else ""
    subject = "Restablece tu contraseña de Nexia"
    footer = "Si no lo pediste tú, ignora este correo: tu contraseña no cambia."
    html = layout(
        f"Hola{', ' + first if first else ''}",
        [
            "Recibimos una solicitud para cambiar la contraseña de tu cuenta.",
            f"El enlace sirve una sola vez y vence en {RESET_TOKEN_MINUTES} minutos.",
        ],
        button=("Elegir nueva contraseña", link),
        footer=footer,
    )
    text = (
        f"Hola{', ' + first if first else ''}\n\nPara elegir una nueva contraseña abre este enlace "
        f"(sirve una vez y vence en {RESET_TOKEN_MINUTES} minutos):\n{link}\n\n{footer}\n"
    )
    return subject, html, text


def password_changed(app: str, full_name: str) -> tuple[str, str, str]:
    first = full_name.split()[0] if full_name.strip() else ""
    subject = "Tu contraseña de Nexia cambió"
    body = "Te avisamos que la contraseña de tu cuenta se acaba de cambiar."
    warning = "Si no fuiste tú, pide un nuevo enlace desde «¿Olvidaste tu contraseña?» y escríbenos."
    html = layout(f"Hola{', ' + first if first else ''}", [body, warning], button=("Ir a iniciar sesión", f"{app}/auth/login"))
    return subject, html, f"{body}\n\n{warning}\n{app}/auth/login\n"
