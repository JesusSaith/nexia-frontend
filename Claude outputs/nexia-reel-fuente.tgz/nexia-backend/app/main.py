import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from sqlmodel import Session

from app.core.booking import sweep_deposits
from app.db.database import engine
from app.db.init_db import init_db
from app.routers.businesses import purge_old_photos
from app.routers.appointments import router as appointments_router
from app.routers.auth import router as auth_router
from app.routers.blocks import agenda_router, router as blocks_router
from app.routers.businesses import router as businesses_router
from app.routers.clients import router as clients_router
from app.routers.dashboard import router as dashboard_router
from app.routers.public_appointments import router as public_appointments_router
from app.routers.notices import router as notices_router
from app.routers.packages import router as packages_router
from app.routers.shop import router as shop_router
from app.routers.reviews import router as reviews_router
from app.routers.settings import router as settings_router
from app.routers.share import router as share_router
from app.routers.demo import router as demo_router
from app.routers.schedules import router as schedules_router
from app.routers.services import router as services_router
from app.routers.staff import router as staff_router
# FUTURE_PHASE_WHATSAPP: from app.routers.whatsapp import router as whatsapp_router
from app.routers.super_admin import router as super_admin_router


from app.core.config import production_problems, settings
from app.core.alerts import current_app_origin, send_daily_summaries, send_monthly_reports
# FUTURE_PHASE_WHATSAPP: from app.core.auto_messages import send_auto_messages
from app.core.origins import LOCAL_ORIGIN, app_origin

if settings.ENVIRONMENT == "production":
    _problems = production_problems(settings)
    if _problems:
        raise RuntimeError("Configuración insegura para producción:\n- " + "\n- ".join(_problems))
    if not settings.RESEND_API_KEY:
        logging.getLogger("nexia").warning("Falta RESEND_API_KEY: no saldrán correos de bienvenida ni de recuperar contraseña.")

if settings.SENTRY_DSN:
    import sentry_sdk

    sentry_sdk.init(dsn=settings.SENTRY_DSN, environment=settings.ENVIRONMENT, traces_sample_rate=0.1)


async def _summary_loop() -> None:
    """Cada 10 minutos: resúmenes que ya toca mandar (8 p. m. de cada zona) y anticipos vencidos."""
    while True:
        try:
            with Session(engine) as session:
                await asyncio.to_thread(sweep_deposits, session)
            with Session(engine) as session:
                await asyncio.to_thread(send_daily_summaries, session)
            with Session(engine) as session:
                await asyncio.to_thread(send_monthly_reports, session)
            # FUTURE_PHASE_WHATSAPP: recordatorios y "Te toca" automáticos por la API oficial de WhatsApp.
            # with Session(engine) as session:
            #     await asyncio.to_thread(send_auto_messages, session)
        except Exception:  # noqa: BLE001 — un error aquí no debe tumbar la API
            logging.getLogger("nexia").exception("Falló el resumen diario")
        await asyncio.sleep(600)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    with Session(engine) as session:
        purge_old_photos(session)
        session.commit()
    # En pruebas no corre: se llama directo a send_daily_summaries.
    summaries = asyncio.create_task(_summary_loop()) if settings.ENVIRONMENT != "test" else None
    yield
    if summaries:
        summaries.cancel()


app = FastAPI(title="Nexia API", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def remember_app_origin(request: Request, call_next):
    """Los correos que salen de esta petición enlazan a la app desde la que se abrió (ver app/core/alerts.py)."""
    token = current_app_origin.set(app_origin(request))
    try:
        return await call_next(request)
    finally:
        current_app_origin.reset(token)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL.rstrip("/")],
    # En desarrollo Angular puede tomar cualquier puerto local.
    allow_origin_regex=LOCAL_ORIGIN.pattern if settings.ENVIRONMENT != "production" else None,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(appointments_router, prefix="/api")
app.include_router(auth_router, prefix="/api")
app.include_router(blocks_router, prefix="/api")
app.include_router(agenda_router, prefix="/api")
app.include_router(businesses_router, prefix="/api")
app.include_router(clients_router, prefix="/api")
app.include_router(dashboard_router, prefix="/api")
app.include_router(public_appointments_router, prefix="/api")
app.include_router(notices_router, prefix="/api")
app.include_router(packages_router, prefix="/api")
app.include_router(shop_router, prefix="/api")
app.include_router(reviews_router, prefix="/api")
app.include_router(settings_router, prefix="/api/settings", tags=["Settings"])
app.include_router(schedules_router, prefix="/api")
app.include_router(services_router, prefix="/api")
app.include_router(staff_router, prefix="/api")
app.include_router(super_admin_router, prefix="/api")
# FUTURE_PHASE_WHATSAPP: webhook de los botones "Confirmo / Cambiar".
# app.include_router(whatsapp_router, prefix="/api")
app.include_router(share_router)
app.include_router(demo_router, prefix="/api/settings")


@app.get("/api/health", include_in_schema=False)
def health() -> dict[str, bool]:
    """Para el monitoreo de Render: responde solo si la base de datos contesta."""
    from sqlalchemy import text

    with Session(engine) as session:
        session.exec(text("SELECT 1"))  # type: ignore[call-overload]
    return {"ok": True}
