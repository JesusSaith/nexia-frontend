from sqlmodel import Field, SQLModel


class Schedule(SQLModel, table=True):
    """Weekly working window for one staff member. Day 0 is Monday."""

    __tablename__ = "schedules"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int = Field(foreign_key="staff_members.id", index=True)
    day_of_week: int = Field(ge=0, le=6)
    start_time: str = Field(max_length=5)
    end_time: str = Field(max_length=5)
    is_active: bool = Field(default=True)
    slot_times: str | None = Field(default=None, max_length=120)
    break_start: str | None = Field(default=None, max_length=5)
    break_end: str | None = Field(default=None, max_length=5)
