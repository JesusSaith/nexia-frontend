import uuid
from datetime import datetime
from enum import Enum
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel

from app.core.clock import local_now


class AppointmentStatus(str, Enum):
    scheduled = "scheduled"
    completed = "completed"
    cancelled = "cancelled"
    no_show = "no_show"
    awaiting_deposit = "awaiting_deposit"


class Appointment(SQLModel, table=True):
    """Booking isolated by business_id. Times are local wall-clock values, without a timezone."""

    __tablename__ = "appointments"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int = Field(foreign_key="staff_members.id", index=True)
    service_id: int = Field(foreign_key="services.id", index=True)
    starts_at: Annotated[datetime, NaiveDatetime] = Field(index=True)
    ends_at: Annotated[datetime, NaiveDatetime]
    client_name: str = Field(max_length=255)
    client_phone: str = Field(max_length=32)
    client_email: str | None = Field(default=None, max_length=255)
    notes: str | None = Field(default=None, max_length=2000)
    status: AppointmentStatus = Field(default=AppointmentStatus.scheduled, max_length=32)
    cancel_token: str = Field(default_factory=lambda: str(uuid.uuid4()), unique=True, index=True, max_length=36)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
    deposit_amount: float | None = Field(default=None)
    quoted_price: float | None = Field(default=None)
    client_confirmed: bool = Field(default=False)
    price_accepted: bool = Field(default=False)
    payment_proof: str | None = Field(default=None, max_length=180000)
    resource_name: str | None = Field(default=None, max_length=80)
    extra_label: str | None = Field(default=None, max_length=255)
    answers: str | None = Field(default=None, max_length=2000)
    use_package: bool = Field(default=False)
    # Lista JSON de imágenes (data URL) que la clienta sube para cotizar.
    reference_photos: str | None = Field(default=None, max_length=600000)
    payment_method: str | None = Field(default=None, max_length=20)
    tip: float | None = Field(default=None)  # propina; suma a la comisión de la colaboradora
    visit_note: str | None = Field(default=None, max_length=2000)  # nota privada de la visita (fórmula, alergias)
    discount_percent: int | None = Field(default=None)  # cupón o lealtad aplicados al reservar
    # De dónde salió: "page" (la clienta en la página) o "admin" (la dueña en la Agenda). Vacío en citas viejas.
    source: str | None = Field(default=None, max_length=10)
    # Reservada en la página con "aprobar citas a mano": el horario se aparta, pero falta el sí de la dueña.
    needs_approval: bool = Field(default=False)
    # Cuándo salió el recordatorio automático; evita mandarlo dos veces.
    reminder_sent_at: Annotated[datetime, NaiveDatetime] | None = Field(default=None)
    # En la última visita completada: ya se le invitó a volver ("Te toca").
    return_invited: bool = Field(default=False)
    # La clienta dijo "Ya pagué" (enlace de pago): falta que la dueña lo revise; no confirma la cita sola.
    paid_claim: bool = Field(default=False)
    # Clave de rastreo SPEI con la que Banxico confirmó el anticipo; no se puede usar dos veces.
    spei_tracking: str | None = Field(default=None, max_length=30, index=True)
