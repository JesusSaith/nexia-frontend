from sqlmodel import Field, Session, SQLModel, select


class ClientPackage(SQLModel, table=True):
    __tablename__ = "client_packages"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    client_name: str = Field(max_length=255)
    client_phone: str = Field(max_length=32, index=True)
    label: str = Field(max_length=80)
    total: int = Field(ge=1)
    remaining: int = Field(ge=0)


def find_package(session: Session, business_id: int, phone: str) -> ClientPackage | None:
    return session.exec(
        select(ClientPackage)
        .where(ClientPackage.business_id == business_id, ClientPackage.client_phone == phone.strip())
        .order_by(ClientPackage.id.desc())
    ).first()


def take_package(session: Session, business_id: int, phone: str) -> bool:
    row = find_package(session, business_id, phone)
    if row is None or row.remaining < 1:
        return False
    row.remaining -= 1
    session.add(row)
    return True


def give_package(session: Session, business_id: int, phone: str) -> None:
    row = find_package(session, business_id, phone)
    if row is None or row.remaining >= row.total:
        return
    row.remaining += 1
    session.add(row)
