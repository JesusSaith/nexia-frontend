from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel

from app.core.clock import local_now


class Notice(SQLModel, table=True):
    """A short event the business sees on Home."""

    __tablename__ = "notices"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    message: str = Field(max_length=255)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
