from sqlmodel import Field, SQLModel


class ServiceCategory(SQLModel, table=True):
    """A name the business creates first. Services are filed under it."""

    __tablename__ = "service_categories"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    name: str = Field(max_length=80)
