from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel


class Review(SQLModel, table=True):
    """A client comment about a business. photo_url is an optional compressed data URL."""

    __tablename__ = "reviews"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    client_name: str = Field(max_length=255)
    rating: int = Field(ge=1, le=5)
    comment: str = Field(max_length=1000)
    photo_url: str | None = Field(default=None, max_length=180000)
    reply: str | None = Field(default=None, max_length=500)
    # Cita a la que responde (una opinión por cita); las anteriores quedan sin dato.
    appointment_id: int | None = Field(default=None, index=True)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=datetime.now, index=True)
