from datetime import time

from sqlmodel import Field, SQLModel, UniqueConstraint


class BusinessHour(SQLModel, table=True):
    """Opening hours of the business. Day 0 is Monday."""

    __tablename__ = "business_hours"
    __table_args__ = (UniqueConstraint("business_id", "day_of_week"),)

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    day_of_week: int = Field(ge=0, le=6)
    open_time: time
    close_time: time
    is_closed: bool = Field(default=False)
