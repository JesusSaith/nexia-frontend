from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, Session, SQLModel, select

from app.core.clock import local_now


def phone_key(phone: str) -> str:
    """Same person if the digits match, even with spaces, dashes, or a 52 prefix."""
    digits = "".join(char for char in phone if char.isdigit())
    if len(digits) > 10 and digits.startswith("52"):
        digits = digits[2:]
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    return digits or phone.strip().lower()


class Client(SQLModel, table=True):
    """Guest who booked with one business. There is no Nexia password on this row."""

    __tablename__ = "clients"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    full_name: str = Field(max_length=255)
    phone: str = Field(max_length=32, index=True)
    email: str | None = Field(default=None, max_length=255)
    notes: str | None = Field(default=None, max_length=2000)
    birthday: str | None = Field(default=None, max_length=10)  # AAAA-MM-DD, opcional
    internal_notes: str | None = Field(default=None, max_length=2000)
    # Etiquetas propias de la dueña ("VIP", "Alergia"), separadas por coma.
    tags: str | None = Field(default=None, max_length=500)


class ClientContact(SQLModel, table=True):
    """Una vez que la dueña le escribió a un cliente (invitarlo, felicitarlo…): sirve para no repetir y para medir si regresó."""

    __tablename__ = "client_contacts"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    # El teléfono normalizado (phone_key): sobrevive a fichas repetidas.
    phone_key: str = Field(max_length=32, index=True)
    kind: str = Field(max_length=10)  # invitar | volver | felicitar | otro
    created_by: str | None = Field(default=None, max_length=255)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)


def merge_duplicates(session: Session) -> int:
    """
    Une las fichas con el mismo teléfono (por phone_key) en la más antigua: conserva notas, correo
    y cumpleaños que solo tenía la otra y borra la repetida. Devuelve cuántas se borraron.
    """
    groups: dict[tuple[int, str], list[Client]] = {}
    for row in session.exec(select(Client).order_by(Client.id)).all():
        groups.setdefault((row.business_id, phone_key(row.phone)), []).append(row)
    removed = 0
    for rows in groups.values():
        keep, *extras = rows
        for extra in extras:
            for field in ("email", "birthday", "internal_notes", "notes", "tags"):
                if getattr(extra, field) and not getattr(keep, field):
                    setattr(keep, field, getattr(extra, field))
            session.delete(extra)
            removed += 1
        if extras:
            session.add(keep)
    if removed:
        session.commit()
    return removed
