from sqlmodel import Field, SQLModel


class StaffService(SQLModel, table=True):
    """Services a staff member can perform, kept inside one business."""

    __tablename__ = "staff_services"

    staff_id: int = Field(foreign_key="staff_members.id", primary_key=True)
    service_id: int = Field(foreign_key="services.id", primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
