import enum
from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel


class UserRole(str, enum.Enum):
    owner = "owner"
    admin = "admin"
    staff = "staff"
    client = "client"
    super_admin = "super_admin"


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: int | None = Field(default=None, primary_key=True)
    email: str = Field(unique=True, index=True, max_length=255)
    hashed_password: str
    role: UserRole = Field(default=UserRole.owner)
    business_id: int | None = Field(default=None, foreign_key="businesses.id", index=True)
    full_name: str = Field(max_length=255)
    # Cuándo aceptó los términos y el aviso de privacidad de Nexia (solo cuentas creadas desde el registro).
    terms_accepted_at: Annotated[datetime, NaiveDatetime] | None = Field(default=None)
