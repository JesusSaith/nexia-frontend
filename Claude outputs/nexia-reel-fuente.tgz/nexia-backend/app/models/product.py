from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel

from app.core.clock import local_now


class Product(SQLModel, table=True):
    __tablename__ = "products"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    name: str = Field(max_length=255)
    price: float = Field(ge=0)
    cost: float = Field(default=0)
    stock: int = Field(default=0)
    is_active: bool = Field(default=True)


class Sale(SQLModel, table=True):
    __tablename__ = "sales"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    product_id: int = Field(foreign_key="products.id", index=True)
    product_name: str = Field(max_length=255)
    qty: int = Field(ge=1)
    total: float = Field(ge=0)
    # Cómo se cobró (efectivo | transferencia | tarjeta). Vacío en ventas viejas: se cuentan como efectivo.
    method: str | None = Field(default=None, max_length=20)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)


class StockMove(SQLModel, table=True):
    __tablename__ = "stock_moves"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    product_id: int = Field(foreign_key="products.id", index=True)
    product_name: str = Field(max_length=255)
    kind: str = Field(max_length=8)
    qty: int = Field(ge=1)
    amount: float = Field(default=0)
    iva: float = Field(default=0)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)


class ExpensePayment(SQLModel, table=True):
    """Un pago de un gasto fijo que la dueña ya hizo ("Ya pagué"): cuenta el día que se pagó, no el que tocaba."""

    __tablename__ = "expense_payments"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    expense_id: int = Field(foreign_key="expenses.id", index=True)
    due: str = Field(max_length=10)  # AAAA-MM-DD: la fecha de pago que tocaba
    paid_on: str = Field(max_length=10)  # AAAA-MM-DD: el día que de verdad se pagó


class CommissionPay(SQLModel, table=True):
    """Commission the owner already handed to one collaborator for a report window."""

    __tablename__ = "commission_pays"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int = Field(foreign_key="staff_members.id", index=True)
    period_start: str = Field(max_length=10)
    period_end: str = Field(max_length=10)
    amount: float = Field(ge=0)


class Expense(SQLModel, table=True):
    __tablename__ = "expenses"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    name: str = Field(max_length=255)
    amount: float = Field(ge=0)
    kind: str = Field(max_length=16)
    cadence: str | None = Field(default=None, max_length=8)
    # Día de pago de un gasto fijo: del 1 al 31 si es mensual, 0 (lunes) a 6 (domingo) si es semanal. Vacío = el día en que se registró.
    pay_day: int | None = Field(default=None)
    # renta | nomina | insumos | servicios | publicidad | otros (vacío = otros).
    category: str | None = Field(default=None, max_length=24)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
