from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel


class TimeBlock(SQLModel, table=True):
    """A break or day off. Public booking skips this window."""

    __tablename__ = "time_blocks"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int = Field(foreign_key="staff_members.id", index=True)
    starts_at: Annotated[datetime, NaiveDatetime] = Field(index=True)
    ends_at: Annotated[datetime, NaiveDatetime]
    note: str | None = Field(default=None, max_length=255)
