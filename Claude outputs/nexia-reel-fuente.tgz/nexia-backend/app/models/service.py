from sqlmodel import Field, SQLModel


class Service(SQLModel, table=True):
    """Bookable offering. Every row belongs to exactly one business."""

    __tablename__ = "services"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    name: str = Field(max_length=255)
    category: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=2000)
    price: float = Field(ge=0)
    deposit_amount: float | None = Field(default=None)
    duration_minutes: int = Field(gt=0, le=1440)
    is_active: bool = Field(default=True)
    variable_price: bool = Field(default=False)
    image_url: str | None = Field(default=None, max_length=180000)
    questions: str | None = Field(default=None, max_length=1000)
    capacity: int = Field(default=1)
    # Cada cuántos días suele volver la clienta por este servicio ("Te toca"); vacío = se calcula del historial.
    # Lo que gasta en material cada vez (tinte, cera…), para la ganancia real por servicio.
    supply_cost: float | None = Field(default=None)
    # Orden en la página de reservas (menor primero) y servicio destacado ("El más pedido").
    sort_order: int = Field(default=0)
    featured: bool = Field(default=False)
    # Minutos de limpieza al terminar (la colaboradora sigue ocupada) y espera dentro del servicio
    # (desde `wait_start` durante `wait_minutes` la colaboradora puede atender a otra clienta).
    cleanup_minutes: int = Field(default=0)
    wait_start: int | None = Field(default=None)
    wait_minutes: int = Field(default=0)
    # Variantes con su precio y duración, en JSON: [{"name": "Largo", "price": 600, "duration_minutes": 120}].
    variants: str | None = Field(default=None, max_length=4000)
    return_days: int | None = Field(default=None)
