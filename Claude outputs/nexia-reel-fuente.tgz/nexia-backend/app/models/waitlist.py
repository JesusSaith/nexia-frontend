from sqlmodel import Field, SQLModel


class Waitlist(SQLModel, table=True):
    __tablename__ = "waitlist"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    service_id: int = Field(index=True)
    staff_id: int = Field(index=True)
    day: str = Field(max_length=10, index=True)
    client_name: str = Field(max_length=255)
    client_phone: str = Field(max_length=32)


def notify_waitlist(session, appointment) -> None:
    from sqlmodel import select

    from app.routers.notices import add_notice, visit_when

    day = appointment.starts_at.strftime("%Y-%m-%d")
    rows = session.exec(
        select(Waitlist).where(
            Waitlist.business_id == appointment.business_id,
            Waitlist.service_id == appointment.service_id,
            Waitlist.staff_id == appointment.staff_id,
            Waitlist.day == day,
        )
    ).all()
    if not rows:
        return
    clock = appointment.starts_at.strftime("%H:%M")
    names = ", ".join(f"{row.client_name} {row.client_phone}" for row in rows[:3])
    add_notice(session, appointment.business_id, f"Horario libre {clock}. Avisar a {names}. Quedó libre {visit_when(appointment.starts_at)}"[:255], "waitlist")
