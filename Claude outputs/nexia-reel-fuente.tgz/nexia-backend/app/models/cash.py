from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel

from app.core.clock import local_now


class CashCount(SQLModel, table=True):
    """Corte de caja de un día: el efectivo que debía haber contra el que la dueña contó."""

    __tablename__ = "cash_counts"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    day: str = Field(max_length=10, index=True)  # AAAA-MM-DD, uno por día
    expected: float = Field(default=0)
    counted: float = Field(default=0)
    note: str | None = Field(default=None, max_length=500)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
    # Fondo con el que abrió la caja ese día (cambio que ya estaba en el cajón).
    opening: float = Field(default=0)
    # Un corte cerrado ya no se edita ni acepta movimientos hasta que alguien lo reabre.
    closed: bool = Field(default=False)
    closed_by: str | None = Field(default=None, max_length=255)
    closed_at: Annotated[datetime, NaiveDatetime] | None = Field(default=None)


class CashMove(SQLModel, table=True):
    """Dinero que entra o sale del cajón fuera de una cita: compras con la caja, retiros, cambio que se mete."""

    __tablename__ = "cash_moves"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    day: str = Field(max_length=10, index=True)  # AAAA-MM-DD
    kind: str = Field(max_length=4)  # in | out
    amount: float = Field(ge=0)
    reason: str = Field(max_length=255)
    # Si salió como gasto, el gasto que se creó en Reportes (se borra junto con el movimiento).
    expense_id: int | None = Field(default=None, foreign_key="expenses.id")
    created_by: str | None = Field(default=None, max_length=255)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
