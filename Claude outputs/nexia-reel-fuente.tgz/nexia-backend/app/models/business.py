import re
import unicodedata
from datetime import datetime
from typing import Annotated

from pydantic import NaiveDatetime
from sqlmodel import Field, SQLModel

from app.core.clock import local_now


def slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", normalized.lower()).strip("-")
    return slug or "negocio"


class Business(SQLModel, table=True):
    """White-label tenant. Every business-owned row points back here."""

    __tablename__ = "businesses"

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(max_length=255)
    slug: str = Field(unique=True, index=True, max_length=255)
    logo_url: str | None = Field(default=None, max_length=180000)
    primary_color: str = Field(default="#1769FF", max_length=16)
    canvas_color: str | None = Field(default=None, max_length=16)
    phone: str = Field(default="", max_length=32)
    email: str = Field(max_length=255)
    description: str | None = Field(default=None, max_length=500)
    address: str | None = Field(default=None, max_length=255)
    # Punto del local en el mapa (grados); van juntos o ninguno. La página de reservas muestra el mapa y "Cómo llegar".
    latitude: float | None = Field(default=None)
    longitude: float | None = Field(default=None)
    # Mapa incrustado de Google ("Insertar un mapa"): solo la dirección https://www.google.com/maps/embed?pb=… (ver app/core/map_link.py).
    map_embed: str | None = Field(default=None, max_length=800)
    instagram: str | None = Field(default=None, max_length=255)
    facebook: str | None = Field(default=None, max_length=255)
    website: str | None = Field(default=None, max_length=255)
    is_active: bool = Field(default=True)
    cancel_hours: int | None = Field(default=None)
    deposit_amount: float | None = Field(default=None)
    deposit_percent: int | None = Field(default=None)
    deposit_account: str | None = Field(default=None, max_length=120)
    deposit_hold_hours: int | None = Field(default=3)
    buffer_minutes: int = Field(default=0)
    staff_label: str = Field(default="Colaborador", max_length=40)
    # Giro elegido al registrarse (belleza, barberia, spa…); sirve para sugerir servicios.
    business_kind: str | None = Field(default=None, max_length=40)
    # Zona IANA del negocio; "ahora" y "hoy" se calculan aquí (ver app/core/clock.py).
    timezone: str = Field(default="America/Mexico_City", max_length=64)
    # Avisos por correo encendidos (tipos separados por coma; None = los de siempre). Ver app/core/alerts.py.
    email_alerts: str | None = Field(default=None, max_length=255)
    # Último día (hora del negocio) en que se revisó el resumen de mañana, para mandarlo una sola vez.
    summary_sent_on: str | None = Field(default=None, max_length=10)
    # Mes (AAAA-MM) del último resumen mensual enviado por correo.
    monthly_sent_on: str | None = Field(default=None, max_length=7)
    # Enlace para dejar reseña en Google; se ofrece a quien califica con 4 o 5 estrellas.
    google_review_url: str | None = Field(default=None, max_length=500)
    # Tema de la página de reservas: color de detalles, forma y relleno de botones, letra y encabezado.
    accent_color: str | None = Field(default=None, max_length=9)
    button_shape: str = Field(default="pill", max_length=10)  # pill | rounded | square
    button_fill: str = Field(default="solid", max_length=10)  # solid | outline
    font_style: str = Field(default="modern", max_length=10)  # modern | elegant | warm
    header_style: str = Field(default="cover", max_length=10)  # cover | color | plain
    # Enlaces anteriores (separados por coma): siguen funcionando después de cambiar el enlace.
    old_slugs: str | None = Field(default=None, max_length=1000)
    # Ya copió o mandó su enlace de reservas al menos una vez (paso de "qué te falta").
    link_shared: bool = Field(default=False)
    min_notice_hours: int = Field(default=0)
    max_days_ahead: int = Field(default=90)
    cancel_policy: str | None = Field(default=None, max_length=500)
    # Salas o equipos que la clienta elige al reservar, separados por coma.
    resources: str | None = Field(default=None, max_length=1_000_000)
    # Pausa y cierre por vacaciones (fechas YYYY-MM-DD, ambas incluidas). Los respeta la API.
    bookings_paused: bool = Field(default=False)
    # Obsoletos: el cierre único pasó a `closures`; init_db mueve lo que quede aquí.
    closed_from: str | None = Field(default=None, max_length=10)
    closed_to: str | None = Field(default=None, max_length=10)
    # Cierres y días festivos: JSON [{"from": "YYYY-MM-DD", "to": "YYYY-MM-DD", "label": "Navidad"}].
    closures: str | None = Field(default=None, max_length=10_000)
    # Métodos de pago que acepta (JSON ["efectivo", "transferencia", "tarjeta"]); vacío = los tres.
    payment_methods: str | None = Field(default=None, max_length=120)
    # Si está encendido, las reservas de la página quedan por aprobar hasta que la dueña las acepta.
    approve_bookings: bool = Field(default=False)
    # Si le paga comisión a su equipo. Apagado, el panel esconde comisiones y los reportes no las restan.
    uses_commissions: bool = Field(default=True)
    # Mensajes automáticos por la API oficial de WhatsApp (requieren WHATSAPP_TOKEN en el servidor).
    auto_reminders: bool = Field(default=False)
    reminder_hours: int = Field(default=24)
    auto_return: bool = Field(default=False)

    @property
    def spei_check(self) -> bool:
        """El anticipo se puede confirmar solo con Banxico: hay CLABE válida y el servidor lo permite."""
        from app.core.config import settings
        from app.core.spei import clabe_ok

        return settings.SPEI_CHECK and clabe_ok(self.deposit_account) is not None
    # Anuncio arriba de la página de reservas y hasta cuándo se ve.
    promo_text: str | None = Field(default=None, max_length=80)
    promo_until: str | None = Field(default=None, max_length=10)
    # Hasta 3 fotos del trabajo (JSON con data URLs ya comprimidas en el navegador).
    gallery: str | None = Field(default=None, max_length=200_000)
    # Mensajes de WhatsApp reescritos por la dueña (JSON {clave: texto}); los demás usan el texto por defecto.
    message_templates: str | None = Field(default=None, max_length=20_000)
    payment_url: str | None = Field(default=None, max_length=255)
    # Aviso de privacidad propio; si está vacío la página pública muestra uno genérico.
    privacy_notice: str | None = Field(default=None, max_length=10000)
    # Ids de lo creado con "Cargar datos de ejemplo" (JSON), para poder borrarlo sin tocar lo real.
    demo_ids: str | None = Field(default=None, max_length=20000)
    # Lealtad: cada N visitas cobradas, la siguiente tiene X% de descuento.
    loyalty_every: int | None = Field(default=None)
    loyalty_percent: int | None = Field(default=None)
    # Cupones (JSON): [{"code": "BIENVENIDA", "percent": 10, "first_visit": true}]
    coupons: str | None = Field(default=None, max_length=5000)
    created_at: Annotated[datetime, NaiveDatetime] = Field(default_factory=local_now)
