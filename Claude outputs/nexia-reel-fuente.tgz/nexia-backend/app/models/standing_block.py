from sqlmodel import Field, SQLModel


class StandingBlock(SQLModel, table=True):
    """A weekly break, such as lunch, applied on every matching weekday."""

    __tablename__ = "standing_blocks"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int = Field(foreign_key="staff_members.id", index=True)
    weekdays: str = Field(default="0,1,2,3,4", max_length=20)
    start_time: str = Field(max_length=8)
    end_time: str = Field(max_length=8)
    note: str | None = Field(default=None, max_length=255)
