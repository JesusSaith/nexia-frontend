from sqlmodel import Field, SQLModel


class Staff(SQLModel, table=True):
    """Team member shown in the booking catalog. Isolated by business_id."""

    __tablename__ = "staff_members"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    full_name: str = Field(max_length=255)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=32)
    role_title: str = Field(max_length=255)
    is_active: bool = Field(default=True)
    user_id: int | None = Field(default=None, foreign_key="users.id", index=True)
    avatar_url: str | None = Field(default=None, max_length=180000)
    bio: str | None = Field(default=None, max_length=2000)
    slot_times: str | None = Field(default=None, max_length=80)
    commission_percent: int = Field(default=0)
    # Meta de venta del mes y comisión escalonada: desde `tier_amount` vendido en el periodo, cobra `tier_percent`.
    goal: float | None = Field(default=None)
    # Color en la agenda (#rrggbb); vacío usa uno de la paleta según su orden.
    color: str | None = Field(default=None, max_length=9)
    tier_amount: float | None = Field(default=None)
    tier_percent: int | None = Field(default=None)
