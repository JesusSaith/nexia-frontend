from datetime import date

from sqlmodel import Field, SQLModel


class SpecialHours(SQLModel, table=True):
    """
    Horario distinto en una fecha o un periodo (24 de diciembre, temporada): reemplaza el turno normal.
    Sin `staff_id` aplica a todo el equipo. `closed` cierra esos días.
    """

    __tablename__ = "special_hours"

    id: int | None = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="businesses.id", index=True)
    staff_id: int | None = Field(default=None, foreign_key="staff_members.id", index=True)
    date_from: date
    date_to: date
    start_time: str = Field(default="09:00", max_length=5)
    end_time: str = Field(default="18:00", max_length=5)
    closed: bool = Field(default=False)
    note: str | None = Field(default=None, max_length=80)
